package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.*;

public class AddClassForm extends JDialog implements ActionListener{

	LinkedList<Class> classes = new LinkedList<Class>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Course> courses = new LinkedList<Course>();

	private Container container;
	private JLabel lblHeader, lblClassCode, lblCode, lblModule, lblClassName, lblCourse;
	private JTextField tfName;
	private JComboBox cmbModules, cmbCourses;
	private JButton btnExit, btnReset, btnAddClass;
	
	/**
	 * loads in relevant lists for the form, creates gui elements such as lables, etc. Adds them to the container and adds action listeners to them
	 * @param classList
	 * @param moduleList
	 * @param courseList
	 */
	public AddClassForm(LinkedList classList, LinkedList moduleList, LinkedList courseList)
	{	
		
		classes = classList;
		modules = moduleList;
		courses = courseList;
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Add Class", JLabel.CENTER);
		lblClassCode = new JLabel("Class Code:", JLabel.RIGHT);
		lblCode = new JLabel(getClassCode());
		lblClassName = new JLabel("Class Name:", JLabel.RIGHT);
		lblModule = new JLabel("Module:", JLabel.RIGHT);
		lblCourse = new JLabel("Course:", JLabel.RIGHT);
		tfName = new JTextField();
		
		cmbModules = new JComboBox();
		cmbCourses = new JComboBox();
		
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnAddClass = new JButton("Add Class");
		
		addComp(lblHeader,0,0,3,1,0,0);
		addComp(lblClassCode,0,1,1,1,0,0);
		addComp(lblCode,1,1,1,1,0,0);
		addComp(lblClassName,0,2,1,1,0,0);
		addComp(tfName,1,2,1,1,0,0);
		addComp(lblCourse,0,3,1,1,0,0);
		addComp(cmbCourses,1,3,1,1,1,0);
		addComp(lblModule,0,4,1,1,0,0);
		addComp(cmbModules,1,4,1,1,1,0);
		addComp(btnExit,0,5,1,1,1,0);
		addComp(btnReset,1,5,1,1,1,0);
		addComp(btnAddClass,2,5,1,1,1,0);
		
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnAddClass.addActionListener(this);
		cmbCourses.addActionListener(this);
		loadCourses();
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * loads the actions from each button, as well as when the combo box for course changes index
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
			loadModules();
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm Reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnAddClass)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to add class: "+tfName.getText()+"?","Confirm Add", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	addClass();
            }
		}
	}

	/**
	 * Gets the class code for the new class being added. If there are none it is simply CLA1001
	 * But if there are classes already existing, it finds the last class code and adds one to it.
	 * E.g. CLA1015 being last would mean that the new code is CLA1016
	 * @return
	 */
	public String getClassCode()
	{
		String code = "";
		if(classes.size() > 0)
		{
		int id = 0;	
		id = Integer.parseInt(classes.getLast().getClassCode().substring(3));
		code = "CLA" + (id + 1); 
		}
		else
		{
			code = "CLA1001";
		}
		return code;
	}
	
	/**
	 * Load courses adds each course into the course combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i = 0; i < courses.size(); i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " + courses.get(i).getCourseName());
	}
	
	/**
	 * load modules activates when a course is selected from the course combo box
	 * it loads modules for the selected course into the module combo box
	 */
	public void loadModules()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		if(cmbCourses.getSelectedIndex() > 0)
		{
			for(int i = 0; i < modules.size(); i++)
			{
				if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
				{
					cmbModules.addItem(modules.get(i).getModuleCode() + ": " +modules.get(i).getModuleName());
				}
			}
		}
	}
	
	/**
	 * sets the form to the default as if it was just opened
	 */
	public void resetForm()
	{
		tfName.setText("");
		cmbCourses.setSelectedIndex(0);
		cmbModules.setSelectedIndex(0);
		lblCode.setText(getClassCode());
	}
	
	/**
	 * Add class first makes sure all information entered is valid
	 * then if it is valid, it adds the class to the list of classes and offers the user the ability to add another or exit
	 */
	public void addClass()
	{
		boolean val = true;
		
		if(tfName.getText().length() == 0)
		{
			JOptionPane.showMessageDialog(container, "Class must have a name/letter.");
			val = false;
		}
		
		if(cmbModules.getSelectedItem().toString().equals("..."))
		{
			JOptionPane.showMessageDialog(container, "You must choose a module");
			val = false;
		}
		
		if(val)
		{
			Class newC = new Class(lblCode.getText(), cmbModules.getSelectedItem().toString().substring(0,7), tfName.getText());
			classes.add(newC);
			JOptionPane.showMessageDialog(container, "Class Added!");
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Would you like to add another class?","Add another", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
            else
            {
            	dispose();
            }
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
