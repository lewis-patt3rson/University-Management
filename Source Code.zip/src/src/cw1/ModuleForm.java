package cw1;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Map.Entry;

import javax.swing.*;

public class ModuleForm extends JDialog implements ActionListener{

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	
	private JLabel lblHeader, lblModuleCode, lblModuleName, lblCourse, lblModuleLeader, lblModuleModerator, lblModuleCodeAutoFill;
	private JTextField tfName;
	private Container container;
	private JComboBox cmbCourses, cmbTutors, cmbAcademics;
	private JButton btnAddModule, btnReset, btnExit;
	
	/**
	 * loads in the relevant lists and maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param CourseList
	 * @param ModuleList
	 * @param tutorMap
	 * @param academicMap
	 */
	public ModuleForm(LinkedList CourseList, LinkedList ModuleList, HashMap tutorMap, HashMap academicMap)
	{
			//Declaring lists
			courses = CourseList;
			modules = ModuleList;
			tutors = tutorMap;
			academics = academicMap;
		
			///Background/Window
			container = getContentPane();
			container.setLayout(new GridBagLayout());
			container.setBackground(new Color(250,128,114));
			
			
			
			//Filling Combo boxes
			cmbCourses = new JComboBox();
			cmbTutors = new JComboBox();
			cmbAcademics = new JComboBox();
			
			loadCourses();
			loadTutors();
			loadAcademics();
			
			
			//Labels
			lblHeader = new JLabel("Add Module", JLabel.CENTER);
			lblModuleCode = new JLabel("Module Code:");
			lblModuleName = new JLabel("Name:");
			lblCourse = new JLabel("Course:");
			lblModuleLeader = new JLabel("Leader:");
			lblModuleModerator = new JLabel("Moderator:");
			lblModuleCodeAutoFill = new JLabel(loadNewID());
			//Text fields
			tfName = new JTextField();
			
			//Buttons
			btnAddModule = new JButton("Add Module");
			btnReset = new JButton("Reset");
			btnExit = new JButton("Exit");
			
			
			//Adding to the GUI
			addComp(lblHeader,0,0,3,1,1,1);
			addComp(lblModuleCode,0,1,1,1,1,1);
			addComp(lblModuleCodeAutoFill,1,1,1,1,1,1);
			addComp(lblModuleName,0,2,1,1,1,1);
			addComp(tfName,1,2,2,1,1,1);
			addComp(lblCourse,0,3,1,1,1,1);
			addComp(cmbCourses,1,3,2,1,1,1);
			addComp(lblModuleLeader,0,4,1,1,1,1);
			addComp(cmbTutors,1,4,2,1,1,1);
			addComp(lblModuleModerator,0,5,1,1,1,1);
			addComp(cmbAcademics,1,5,2,1,1,1);
			addComp(btnExit,0,6,1,1,1,1);
			addComp(btnReset,1,6,1,1,1,1);
			addComp(btnAddModule,2,6,1,1,1,1);
			
			
			
			btnAddModule.addActionListener(this);
			btnReset.addActionListener(this);
			btnExit.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * loads events from buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnAddModule)
		{
			addModule();
		}
		else if(e.getSource() == btnReset)
		{
			resetForm();
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	dispose();
	        }
		}
	}

	/**
	 * confirms input validation and if its valid, creates a module with the information
	 */
	public void addModule()
	{
		String courseCode = "", tutorName = "", academicName = "", moduleName = "", tutorID = "", academicID = "";
		
		boolean val = true;
		//Making sure a course is chosen
		if(cmbCourses.getSelectedIndex() >= 1)
		{
			courseCode = getCourseCode();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a course for the module to be added to.");
			val = false;
		}
		
		//Making sure a tutor is chosen as the leader
		if(cmbTutors.getSelectedIndex() >= 1)
		{
			tutorName = cmbTutors.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a tutor as the leader of the module.");
			val = false;
		}
		
		//Making sure an academic is chosen as the moderator
		if(cmbAcademics.getSelectedIndex() >= 1)
		{
			academicName = cmbAcademics.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose an academic as the module moderator.");
			val = false;
		}
		
		//Making sure the name is more than 3 letters/exists
		if(tfName.getText().length() >= 3 && val == true)
		{
			moduleName = tfName.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Module Names must be more than 3 characters");
			val = false;
		}
		
		if(val)
		{
			Module newM = new Module();
			tutorID = findTutorID(tutorName);
			academicID = findAcademicID(academicName);
			
			newM.setCourseCode(courseCode);
			newM.setModuleCode(lblModuleCodeAutoFill.getText().toString());
			newM.setModuleName(tfName.getText());
			newM.setModuleModerator(academicID);
			newM.setModuleLeader(tutorID);
			
			
			
			int dialogButton2 = JOptionPane.YES_NO_OPTION;
            int dialogResult2 = JOptionPane.showConfirmDialog (null, "Are you sure you would like to add this module?","Confirm addition.", dialogButton2);
            if(dialogResult2 == JOptionPane.YES_OPTION)
            {
            	modules.add(newM);
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Would you like to add another module?","Module Added!", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	lblModuleCodeAutoFill.setText(loadNewID());
            	tfName.setText("");
            	cmbCourses.setSelectedIndex(0);
            	cmbTutors.setSelectedIndex(0);
            	cmbAcademics.setSelectedIndex(0);
            }
            else
            {
            	dispose();
            }           
            }
		}
	}
	
	/**
	 * loads courses into a combo box
	 */
	public void loadCourses()
	{
			cmbCourses.addItem("...");
		for(int i = 0; i < courses.size(); i++)
			cmbCourses.addItem(courses.get(i).getCourseName());
	}

	/**
	 * loads tutors into a combo box
	 */
	public void loadTutors()
	{
		cmbTutors.addItem("...");
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			String tutorName = tutors.get(me.getKey()).getSurname() + ", " + tutors.get(me.getKey()).getForname();
			cmbTutors.addItem(tutorName);
		}

	}
	
	/**
	 * loads academics into a combo box
	 */
	public void loadAcademics()
	{
		cmbAcademics.addItem("...");
		Iterator it = academics.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			String academicName = academics.get(me.getKey()).getSurname() + ", " + academics.get(me.getKey()).getForname();
			cmbAcademics.addItem(academicName);
		}

	}
	
	/**
	 * gets the course code of the selected course
	 * @return
	 */
	public String getCourseCode()
	{
		String courseCode = "";
		for(int i = 0; i < courses.size(); i++)
		{
			if(courses.get(i).getCourseName() == cmbCourses.getSelectedItem())
			{
				courseCode = courses.get(i).getCourseCode();
				break;
			}
		}
		return courseCode;
	}
	
	/**
	 * finds the last module id and adds 1 to it
	 * @return
	 */
	public String loadNewID()
	{
		String id = modules.getLast().getModuleCode().substring(modules.getLast().getModuleCode().length() - 4);
		int update = Integer.parseInt(id) + 1;
		id = "MOD" + update;
		return id;
	}
	
	/**
	 * finds the tutor id from the name
	 * @param id
	 * @return
	 */
	public String findTutorID(String id)
	{

		String forName = "", surName = "";
		surName = id.substring( 0, id.indexOf(","));
		forName = id.substring(id.indexOf(",") + 2);
		String tutorCode = "";
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(tutors.get(me.getKey()).getForname().equals(forName) && tutors.get(me.getKey()).getSurname().equals(surName))
			{
				tutorCode = tutors.get(me.getKey()).getTutorCode();
				break;
			}
		}
		
		
		return tutorCode;
	}
	
	/**
	 * finds the academic id from the name
	 * @param id
	 * @return
	 */
	public String findAcademicID(String id)
	{
		String forName = "", surName = "";
		surName = id.substring( 0, id.indexOf(","));
		forName = id.substring(id.indexOf(",") + 2);
		String academicCode = "";
		Iterator it = academics.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(academics.get(me.getKey()).getForname().equals(forName) && academics.get(me.getKey()).getSurname().equals(surName))
			{
				academicCode = academics.get(me.getKey()).getAcademicCode();
				break;
			}
		}
		
		
		return academicCode;
	}
	
	/**
	 * finds course id from the course name
	 * @param id
	 * @return
	 */
	public String findCourseID(String id)
	{
		String code = "";
		
		for(int i = 0; i < courses.size(); i++)
		{
			if(courses.get(i).getCourseName() == id)
				code = id;
		}
		
		return code;
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm reset", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	lblModuleCodeAutoFill.setText(loadNewID());
        	tfName.setText("");
        	cmbCourses.setSelectedIndex(0);
        	cmbTutors.setSelectedIndex(0);
        	cmbAcademics.setSelectedIndex(0);
        }
	}
	
	
}
