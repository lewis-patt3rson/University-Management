package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class StaffModuleForm extends JDialog{

	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	
	//Lists
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	
	private Container container;
	/**
	 * loads in the relevant listd, map and staff id for the form, creates and adds gui elements to container
	 * lists all modules a staff member leads/moderated and adds them to the gui
	 * @param id
	 * @param tutorMap
	 * @param academicMap
	 * @param moduleList
	 * @param classList
	 */
	public StaffModuleForm(String id, HashMap tutorMap, HashMap academicMap, LinkedList moduleList, LinkedList classList)
	{
		tutors = tutorMap;
		academics = academicMap;
		modules = moduleList;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> stuResList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(stuResList);
	
		if(id.substring(0,3).equals("TUT"))
			dlm.addElement("Modules lead by tutor: " + tutors.get(id).getTutorCode() + " - " + tutors.get(id).getForname() + ", " + tutors.get(id).getSurname());
		else
			dlm.addElement("Modules moderated by academic: " + academics.get(id).getAcademicCode() + " - " + academics.get(id).getForname() + ", " + academics.get(id).getSurname());
		
		int count = 0;
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getModuleLeader().equals(id) || modules.get(i).getModuleModerator().equals(id))
			{
				dlm.addElement("Module: " + modules.get(i).getModuleCode() + " - " + modules.get(i).getModuleName());
				dlm.addElement("Classes In Module: " + getClassNumbers(modules.get(i).getModuleCode()));
				count++;
			}
		}
		
		if(count > 0)
			dlm.addElement("Total Modules: " + count);
		else
			dlm.addElement("This staff member has no modules.");
		
		addComp(listScroller, 0,0,1,1,1,1);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * returns the number of classes for a module
	 * @param moduleCode
	 * @return
	 */
	public int getClassNumbers(String moduleCode)
	{
		int num = 0;
		for(int i = 0; i < classes.size(); i++)
			if(classes.get(i).getModuleCode().equals(moduleCode))
				num++;
		return num;
	}
}
