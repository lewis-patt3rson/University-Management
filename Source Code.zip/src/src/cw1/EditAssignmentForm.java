package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import javax.swing.*;

public class EditAssignmentForm extends JDialog implements ActionListener{

	
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	
	private Container container;
	private JLabel lblHeader, lblMessage, lblCourse, lblModule, lblAssignment, lblAssignmentCode, lblCode, lblAssignmentName, lblAssignmentSummary, lblEditCourse, lblEditModule;
	private JPanel jpSearch, jpDetails;
	private JComboBox cmbCourses, cmbModules, cmbAssignments, cmbEditCourses, cmbEditModules, cmbYear, cmbMonth, cmbDay;
	private JButton btnEdit, btnDelete, btnExit, btnReset, btnConfirmEdit;
	private JTextField tfName, tfSummary;
	private JCheckBox todaysDate;

	/**
	 * loads in the relevant lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param modulesList
	 * @param courseList
	 * @param assignmentList
	 * @param resultList
	 */
	public EditAssignmentForm(LinkedList modulesList,LinkedList courseList, LinkedList assignmentList, LinkedList resultList)
	{
		courses = courseList;
		modules = modulesList;
		assignments = assignmentList;
		results = resultList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
		
		tfName = new JTextField("");
		tfSummary = new JTextField("");
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		cmbAssignments = new JComboBox();
		cmbEditCourses = new JComboBox();
		cmbEditModules = new JComboBox();
		
		btnEdit = new JButton("Edit");
		btnDelete = new JButton("Delete");
		btnExit = new JButton("Exit");
		btnReset = new JButton("Cancel");
		btnConfirmEdit = new JButton("Confirm Edit");
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,0,0);
		
		lblHeader = new JLabel("Edit assignment", JLabel.CENTER);
		lblMessage = new JLabel("Choose an assignment to edit/delete");
		lblCourse = new JLabel("Course:");
		lblModule = new JLabel("Module:");
		lblAssignment = new JLabel("Assignment:");
		lblAssignmentCode = new JLabel("Assignment Code:", JLabel.RIGHT);
		lblCode = new JLabel("ASSXXXX");
		lblAssignmentName = new JLabel("Name:", JLabel.RIGHT);
		lblAssignmentSummary = new JLabel("Summary:", JLabel.RIGHT);
		lblEditCourse = new JLabel("Course:", JLabel.RIGHT);
		lblEditModule = new JLabel("Module:", JLabel.RIGHT);
		
		String[] years = new String[]{
				"2000","2001","2002","2003","2004","2005",
				"2006","2007","2008","2009","2010","2011",
				"2012","2013","2014","2015","2016","2017",
				"2018","2019","2020",
			};
			
			String[] months = new String[] {
					"Jan", "Feb", "Mar",
					"Apr","May","Jun",
					"Jul","Aug","Sep",
					"Oct","Nov","Dec"
			};
			
		
			cmbYear = new JComboBox(years);
			cmbMonth = new JComboBox(months);
			cmbDay = new JComboBox();
		
			todaysDate = new JCheckBox("Use Today's Date");
			todaysDate.addActionListener(this);
			
		addComp(jpSearch, lblHeader,0,0,4,1,0,0);
		addComp(jpSearch, lblMessage,0,1,1,1,0,0);
		addComp(jpSearch, lblCourse,0,2,1,1,0,0);
		addComp(jpSearch, cmbCourses,0,3,1,1,1,0);
		addComp(jpSearch, lblModule,1,2,1,1,0,0);
		addComp(jpSearch, cmbModules,1,3,1,1,1,0);
		addComp(jpSearch, lblAssignment,2,2,1,1,0,0);
		addComp(jpSearch, cmbAssignments,2,3,1,1,0,0);
		addComp(jpSearch, btnEdit,3,2,1,1,0,0);
		addComp(jpSearch, btnDelete,3,3,1,1,0,0);
		
		
		addComp(jpDetails, lblAssignmentCode,0,1,1,1,0,0);
		addComp(jpDetails, lblCode,1,1,1,1,0,0);
		addComp(jpDetails, lblAssignmentName,0,2,1,1,0,0);
		addComp(jpDetails, tfName,1,2,1,1,1,0);
		addComp(jpDetails, lblAssignmentSummary,0,3,1,1,0,0);
		addComp(jpDetails, tfSummary,1,3,1,1,0,0);
		addComp(jpDetails, lblEditCourse,0,4,1,1,0,0);
		addComp(jpDetails, cmbEditCourses,1,4,1,1,0,0);
		addComp(jpDetails, lblEditModule,0,5,1,1,0,0);
		addComp(jpDetails, cmbEditModules,1,5,1,1,0,0);
		addComp(jpDetails, btnExit,0,8,1,1,0,0);
		addComp(jpDetails, btnReset,1,8,1,1,0,0);
		addComp(jpDetails, btnConfirmEdit,2,8,1,1,0,0);
		addComp(jpDetails, todaysDate,1,6,1,1,0,0);
		addComp(jpDetails, cmbYear,1,7,1,1,0,0);
		addComp(jpDetails, cmbMonth,2,7,1,1,0,0);
		addComp(jpDetails, cmbDay,3,7,1,1,0,0);
		
		loadCourses();
		loadEditCourses();
		disableEdit();
		
		cmbCourses.addActionListener(this);
		cmbModules.addActionListener(this);
		cmbEditCourses.addActionListener(this);
		btnEdit.addActionListener(this);
		btnDelete.addActionListener(this);
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnConfirmEdit.addActionListener(this);
		cmbMonth.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from buttons and combo boxes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
		{
			cmbModules.removeAllItems();
			if(cmbCourses.getSelectedIndex() > 0)
				loadModulesFromCourse();
		}
		else if(e.getSource() == cmbModules)
		{
			cmbAssignments.removeAllItems();
			if(cmbModules.getSelectedIndex() > 0)	
				loadAssignmentsFromModule();
		}
		else if(e.getSource() == cmbEditCourses)
		{
			cmbEditModules.removeAllItems();
			if(cmbEditCourses.getSelectedIndex() > 0)	
				loadEditModules();
		}
		else if(e.getSource() == btnEdit)
			loadEdit();		
		else if(e.getSource() == btnDelete)
			delete();
		else if(e.getSource() == btnExit)
			exit();
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to cancel?","Confirm cancel.", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        { 
	        	reset();
	        }		
		}
		else if(e.getSource() == btnConfirmEdit)
			edit();
		else if(e.getSource() == todaysDate)
		{
			if(todaysDate.isSelected())
			{
				cmbYear.setSelectedIndex(0);
				cmbMonth.setSelectedIndex(0);
				cmbDay.removeAllItems();
				cmbYear.setEnabled(false);
				cmbMonth.setEnabled(false);
				cmbDay.setEnabled(false);
			}
			else
			{
				cmbYear.setEnabled(true);
				cmbMonth.setEnabled(true);
				cmbDay.setEnabled(true);
			}
		}
		else if(e.getSource() == cmbMonth)
			loadDays();
		
	}
	
	/**
	 * loads all courses into combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}
	
	/**
	 * loads all courses into the edit combo box
	 */
	public void loadEditCourses()
	{
		cmbEditCourses.removeAllItems();
		cmbEditCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbEditCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}
	
	/**
	 * loads all modules into the edit combo box from the selected course
	 */
	public void loadEditModules()
	{
		cmbEditModules.addItem("...");
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getCourseCode().equals(cmbEditCourses.getSelectedItem().toString().substring(0,7)))
			{
				cmbEditModules.addItem( modules.get(i).getModuleCode()+ ": "+ modules.get(i).getModuleName());
			}
		}
	}
	
	/**
	 * loads all modules into the combo box from the selected course
	 */
	public void loadModulesFromCourse()
	{
		
		cmbModules.addItem("...");
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
			{
				cmbModules.addItem( modules.get(i).getModuleCode()+ ": "+ modules.get(i).getModuleName());
			}
		}
	}

	/**
	 * loads all assignments from a selected module into a combo box
	 */
	public void loadAssignmentsFromModule()
	{
		cmbAssignments.addItem("...");
		if(cmbModules.getItemCount() > 0)
			for(int i = 0; i < assignments.size(); i++)
				if(assignments.get(i).gemoduleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
					cmbAssignments.addItem(assignments.get(i).getAssignmentCode() + ": " + assignments.get(i).getAssignmentName());
			
	}
	
	/**
	 * enables the edit panel and loads the editable data
	 */
	public void loadEdit() {
		
		if(cmbAssignments.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to edit: " + cmbAssignments.getSelectedItem().toString() + "?","Confirm edit.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	for(int i = 0; i < assignments.size(); i++)           	
            		if(assignments.get(i).getAssignmentCode().equals(cmbAssignments.getSelectedItem().toString().substring(0,7)))
            		{
            			tfName.setText(assignments.get(i).getAssignmentName());
            			lblCode.setText(assignments.get(i).getAssignmentCode());
            			tfSummary.setText(assignments.get(i).getSummary());
            		}
            	for(Component c: jpDetails.getComponents())
            		c.setEnabled(true);
            	for(Component c: jpSearch.getComponents())
            		c.setEnabled(false);
            }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose an assignment to edit");
	}
	
	/**
	 * confirms delete and then deletes the information of an assignment along with all its results
	 */
	public void delete() 
	{
		if(cmbAssignments.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to delete: " + cmbAssignments.getSelectedItem().toString() + "?\nWarning this will delete all results for the assignment","Confirm delete.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {        
            	deleteResults();
            	int index = 0;
            	for(int i = 0; i < assignments.size(); i++)
            		if(assignments.get(i).getAssignmentCode().equals(cmbAssignments.getSelectedItem().toString().substring(0,7)))
            			index = i;
            	assignments.remove(index);
            	JOptionPane.showMessageDialog(container, "Assignment and results deleted successfully!");
            	JOptionPane.showMessageDialog(container, "Assignment edited successfully!");
	        	int dialogButton2 = JOptionPane.YES_NO_OPTION;
		        int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another?","Add another.", dialogButton2);
		        if(dialogResult2 == JOptionPane.YES_OPTION)
		        { 
		        	reset();
		        }
		        else
		        {
		        	dispose();
		        }
            }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose an assignment to edit");
	}
	
	/**
	 * disables the edit panel
	 */
	public void disableEdit()
	{
		for(Component c: jpDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);	
	}
	
	/**
	 * finds the index of the assignment in the list
	 * @return
	 */
	public int getAssignmentIndex()
	{
		int index = 0;
		for(int i = 0; i < assignments.size(); i++)
			if(assignments.get(i).getAssignmentCode().equals(lblCode.getText()))
				index = i;
		return index;
	}

	/**
	 * deletes the results for the selected assignment
	 */
	public void deleteResults()
	{
		 int i = 0;
	      while (results.size() > i) {
	    	  if(results.get(i).getAssignmentCode().equals(cmbAssignments.getSelectedItem().toString().substring(0,7)))
	    		  results.remove(i);
	    	  else
	    		  i++;
	      }
	
	}
	
	/**
	 * confirms exit then exits
	 */
	public void exit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm delete.", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        { 
        	dispose();
        }
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void reset()
	{	
        	for(Component c: jpSearch.getComponents())
        		c.setEnabled(true);
        	for(Component c: jpDetails.getComponents())
        		c.setEnabled(false);
        	lblCode.setText("");
        	tfName.setText("");
        	tfSummary.setText("");
        	cmbEditCourses.setSelectedIndex(0);
        	cmbCourses.setSelectedIndex(0);
        	btnExit.setEnabled(true);
        	cmbDay.removeAllItems();
        	cmbMonth.setSelectedIndex(0);
        	cmbYear.setSelectedIndex(0);
        	todaysDate.setSelected(false);
        
	}
	
	/**
	 * validates input information for editing
	 * then edits the selected assignment
	 */
	public void edit()
	{
		boolean val = true;
		String date = "";
		if(tfName.getText().length() < 3)
		{
			val = false;
			JOptionPane.showMessageDialog(container, "Name must be atleast 3 letters long.");
		}
		
		if(tfSummary.getText().length() < 15)
		{
			val = false;
			JOptionPane.showMessageDialog(container, "Summary must be atleast 15 letters long.");
		}
		
		if(cmbEditModules.getSelectedIndex() == 0)
		{
			val = false;
			JOptionPane.showMessageDialog(container, "You must choose a module.");
		}
		
		if(todaysDate.isSelected())
			date = LocalDateTime.now().getDayOfMonth() + "/" + LocalDateTime.now().getMonth().name().substring(0,3) + "/" + LocalDateTime.now().getYear();
		else if(cmbDay.getSelectedIndex() > 0)
			date = cmbDay.getSelectedItem() + "/" + cmbMonth.getSelectedItem().toString().toUpperCase() + "/" +cmbYear.getSelectedItem();
		else
		{
			val = false;
			JOptionPane.showMessageDialog(container, "You must choose a date");
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit: " + cmbAssignments.getSelectedItem().toString() + "?","Confirm edit.", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        { 
	        	int index = getAssignmentIndex();
	        	assignments.get(index).setAssignmentName(tfName.getText());
	        	assignments.get(index).setSummary(tfSummary.getText());
	        	assignments.get(index).setmoduleCode(cmbEditModules.getSelectedItem().toString().substring(0,7));
	        	assignments.get(index).setDateIssued(date);
	        	JOptionPane.showMessageDialog(container, "Assignment edited successfully!");
	        	int dialogButton2 = JOptionPane.YES_NO_OPTION;
		        int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another?","Add another.", dialogButton2);
		        if(dialogResult2 == JOptionPane.YES_OPTION)
		        { 
		        	reset();
		        }
		        else
		        {
		        	dispose();
		        }
	        }
		}
	}
	
	/**
	 * loads days from selected month
	 */
	public void loadDays()
	{
		int days = 0;
		switch(cmbMonth.getSelectedItem().toString())
		{
		case "Jan": 
			days = 31;
			break;
		case "Feb": 
			days = 28;
			break;
		case "Mar": 
			days = 31;
			break;
		case "Apr": 
			days = 30;
			break;
		case "May": 
			days = 31;
			break;
		case "Jun": 
			days = 30;
			break;
		case "Jul": 
			days = 31;
			break;
		case "Aug": 
			days = 31;
			break;
		case "Sep": 
			days = 30;
			break;
		case "Oct": 
			days = 31;
			break;
		case "Nov": 
			days = 30;
			break;
		case "Dec": 
			days = 31;
			break;
		}
		cmbDay.removeAllItems();
		for( int i = 0; i < days; i++)
			cmbDay.addItem(i+1);
	}

}
