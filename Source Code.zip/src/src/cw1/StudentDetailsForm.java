package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class StudentDetailsForm extends JDialog implements ActionListener{

	HashMap<String,Student> students = new HashMap<String,Student>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	
	private Container container;
	private JPanel jpSearch, jpDetails;
	private JTextField tfSearch;
	private JComboBox cmbStudents;
	private JLabel lblHeader, lblMessage, lblStudentCode, lblCode, lblStudentForName, lblForname, lblStudentSurname, lblSurname, lblStudentDisability, lblDisability, lblStudentPreferredName, lblPName;
	private JLabel lblStudentGender, lblGender, lblAssignmentResults;
	private JButton btnViewAssignments, btnDetails, btnExit, btnReset;
	
	/**
	 * loads in the relevant lists and maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param studentMap
	 * @param assignmentList
	 * @param resultList
	 */
	public StudentDetailsForm(HashMap studentMap, LinkedList assignmentList, LinkedList resultList)
	{
		students = studentMap;
		assignments = assignmentList;
		results = resultList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
		
		tfSearch = new JTextField();
		KeyListener keyListener = new KeyListener() {
		     public void keyPressed(KeyEvent keyEvent) {
		     }
		     public void keyReleased(KeyEvent keyEvent) {
		    	 loadStudents();
		     }
		     public void keyTyped(KeyEvent keyEvent) {    
		      }};
		tfSearch.addKeyListener(keyListener);
		
		cmbStudents = new JComboBox();
		
		lblHeader = new JLabel("Student Details", JLabel.CENTER);
		lblMessage = new JLabel("Search by surname or student code:");
		lblStudentCode = new JLabel("Student Code:", JLabel.RIGHT);
		lblCode = new JLabel("STUXXXX");
		lblStudentForName = new JLabel("Forname:", JLabel.RIGHT);
		lblForname = new JLabel("XXXXXXX");
		lblStudentSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblSurname = new JLabel("XXXXXXX");
		lblStudentDisability = new JLabel("Disability:", JLabel.RIGHT);
		lblDisability = new JLabel("XXXXXXX");
		lblStudentPreferredName = new JLabel("Preferred Name:", JLabel.RIGHT);
		lblPName = new JLabel("XXXXXXX");
		lblStudentGender = new JLabel("Gender:", JLabel.RIGHT);
		lblGender = new JLabel("XXXXXXX");
		lblAssignmentResults = new JLabel("Assignment Results:", JLabel.RIGHT);
		
		btnViewAssignments = new JButton("View Results");
		btnExit = new JButton("Exit");
		btnDetails = new JButton("View Details");
		btnReset = new JButton("Clear results");
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,0,0);
		
		addComp(jpSearch, lblHeader, 0,0,1,1,0,0);
		addComp(jpSearch, lblMessage, 0,1,1,1,0,0);
		addComp(jpSearch, tfSearch, 0,2,1,1,0,0);
		addComp(jpSearch, cmbStudents, 0,3,1,1,0,0);
		addComp(jpSearch, btnReset, 2,2,1,1,0,0);
		addComp(jpSearch, btnDetails, 2,3,1,1,0,0);
		
		addComp(jpDetails, lblStudentCode, 0,0,1,1,0,0);
		addComp(jpDetails, lblCode, 1,0,1,1,0,0);
		addComp(jpDetails, lblStudentForName, 0,1,1,1,0,0);
		addComp(jpDetails, lblForname, 1,1,1,1,0,0);
		addComp(jpDetails, lblStudentSurname, 0,2,1,1,0,0);
		addComp(jpDetails, lblSurname, 1,2,1,1,0,0);
		addComp(jpDetails, lblStudentDisability, 0,3,1,1,0,0);
		addComp(jpDetails, lblDisability, 1,3,1,1,0,0);
		addComp(jpDetails, lblStudentPreferredName, 0,4,1,1,0,0);
		addComp(jpDetails, lblPName, 1,4,1,1,0,0);
		addComp(jpDetails, lblStudentGender, 0,5,1,1,0,0);
		addComp(jpDetails, lblGender, 1,5,1,1,0,0);
		addComp(jpDetails, lblAssignmentResults, 0,6,1,1,0,0);
		addComp(jpDetails, btnViewAssignments, 1,6,1,1,0,0);
		addComp(jpDetails, btnExit, 0,7,2,1,0,0);
		
		
		
		
		
		
		btnViewAssignments.addActionListener(this);
		btnExit.addActionListener(this);
		btnDetails.addActionListener(this);
		btnReset.addActionListener(this);
		
		loadStudents();
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnReset)
			clear();
		else if(e.getSource() == btnDetails)
			loadDetails();
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
			int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
			if(dialogResult == JOptionPane.YES_OPTION)
				dispose();
        
		}
		else if(e.getSource() == btnViewAssignments)
		{
			if(lblCode.getText().equals("STUXXXX"))
				JOptionPane.showMessageDialog(container, "You must choose a student to view their assignments");
			else
			{
				StudentAssignmentResults sarF = new StudentAssignmentResults(lblCode.getText(), assignments, results);
				sarF.setSize(400,400);
				sarF.setModal(true);
				sarF.setVisible(true);
			}
			
		}
	}

	/**
	 * loads students from what is typed in the search bar (this loads both surname searched and code simultaneously
	 */
	public void loadStudents()
	{
		cmbStudents.removeAllItems();
		cmbStudents.addItem("...");
				
		Iterator it = students.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			try {
				if(tfSearch.getText().toString().toUpperCase().equals(students.get(me.getKey()).getStudentCode().substring(0, tfSearch.getText().length())) || tfSearch.getText().toString().toUpperCase().equals(students.get(me.getKey()).getSurName().substring(0, tfSearch.getText().length()).toUpperCase()))
					cmbStudents.addItem(students.get(me.getKey()).getStudentCode() + ": " + students.get(me.getKey()).getSurName() + ", " + students.get(me.getKey()).getForName());
				}
				catch(StringIndexOutOfBoundsException e){}	
		}
		
		if(cmbStudents.getItemCount() > 1 && tfSearch.getText().length() >= 1)		
			cmbStudents.setSelectedIndex(1);
	}
	
	/**
	 * loads slected students details into the form
	 */
	public void loadDetails()
	{
		if(cmbStudents.getSelectedIndex() > 0)
		{
			String id = cmbStudents.getSelectedItem().toString().substring(0,7);
			lblForname.setText(students.get(id).getForName());
			lblSurname.setText(students.get(id).getSurName());
			lblDisability.setText(students.get(id).getDisability());
			lblPName.setText(students.get(id).getPreferredName());
			lblGender.setText(students.get(id).getGender());
			lblCode.setText(students.get(id).getStudentCode());
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a student to view their details.");
	}
	
	
	
	/**
	 * clears all details
	 */
	public void clear()
	{
		lblForname.setText("");
		lblSurname.setText("");
		lblDisability.setText("");
		lblPName.setText("");
		lblGender.setText("");
		lblCode.setText("");
		tfSearch.setText("");
		cmbStudents.setSelectedIndex(0);
	}
	
	
	
	
	
}
