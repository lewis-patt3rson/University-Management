package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;

import javax.swing.*;

import cw1.Class;
import cw1.Module;

public class ModuleDetailsForm extends JDialog implements ActionListener{

	
	HashMap<String,Student> students = new HashMap<String,Student>();
	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	
	
	private Container container;
	private JTextField tfSearch;
	private JLabel lblHeader, lblMessage, lblModuleCode, lblModuleCodeAutoFill, lblModuleName, lblName, lblModuleLeader, lblLeader, lblModuleModerator, lblModerator, lblClasses, lblCourseCode, lblCourseCodeAutoFill, lblResults;
	private JComboBox cmbModules;
	private JButton btnDetails, btnReset, btnClassList, btnExit, btnResults;
	private JPanel jpSearch, jpDetails;
	
/**
 * loads in the relevant lists and maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
 * @param moduleList
 * @param classList
 * @param tutorMap
 * @param academicMap
 * @param courseList
 * @param resultList
 * @param assignmentList
 * @param studentMap
 */
	public ModuleDetailsForm(LinkedList moduleList, LinkedList classList, HashMap tutorMap, HashMap academicMap, LinkedList courseList, LinkedList resultList, LinkedList assignmentList, HashMap studentMap)
	{
		tutors = tutorMap;
		academics = academicMap;
		courses = courseList;
		modules = moduleList;
		classes = classList;
		assignments = assignmentList;
		results = resultList;
		students = studentMap;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
		
		lblCourseCode = new JLabel("Course Code:", JLabel.RIGHT);
		lblCourseCodeAutoFill = new JLabel("COUXXXX");
		lblHeader = new JLabel("Module Details", JLabel.CENTER);
		lblMessage = new JLabel("Search for a module: ");
		lblModuleCode = new JLabel("Module Code:", JLabel.RIGHT);
		lblModuleCodeAutoFill = new JLabel("MODXXXX");
		lblModuleName = new JLabel("Name:", JLabel.RIGHT);
		lblName = new JLabel("xxxxxxx");
		lblModuleLeader = new JLabel("Module Leader:", JLabel.RIGHT);
		lblLeader = new JLabel("xxxxxxx");
		lblModuleModerator = new JLabel("Module Moderator:", JLabel.RIGHT);
		lblModerator = new JLabel("xxxxxxx");
		lblClasses = new JLabel("Classes:", JLabel.RIGHT);
		lblResults = new JLabel("Results:", JLabel.RIGHT);
		
		
		
		tfSearch = new JTextField();
		KeyListener keyListener = new KeyListener() {
		     public void keyPressed(KeyEvent keyEvent) {
		     }
		     public void keyReleased(KeyEvent keyEvent) {
		      loadModules();
		     }
		     public void keyTyped(KeyEvent keyEvent) {    
		      }};
		tfSearch.addKeyListener(keyListener);
		
		
		cmbModules = new JComboBox();
		
		btnDetails = new JButton("Module Details");
		btnReset = new JButton("Reset Search");
		btnClassList = new JButton("Get Class List");
		btnExit = new JButton("Exit");
		btnResults = new JButton("Get Results");
		loadModules();
		cmbModules.setSelectedIndex(0);
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,1,1);
		
		addComp(jpSearch, lblHeader, 0,0,3,1,0,0);
		addComp(jpSearch, lblMessage, 0,1,1,1,0,0);
		addComp(jpSearch, tfSearch, 0,2,2,1,0,0);
		addComp(jpSearch, cmbModules, 0,3,2,1,1,1);
		addComp(jpSearch, btnDetails, 2,3,1,1,1,1);
		addComp(jpSearch, btnReset, 2,2,1,1,0,0);
		
		addComp(jpDetails, lblCourseCode, 0,0,1,1,1,1);
		addComp(jpDetails, lblCourseCodeAutoFill, 1,0,1,1,1,1);
		addComp(jpDetails, lblModuleCode, 0,1,1,1,1,1);
		addComp(jpDetails, lblModuleCodeAutoFill, 1,1,1,1,1,1);
		addComp(jpDetails, lblModuleName, 0,2,1,1,1,1);
		addComp(jpDetails, lblName, 1,2,2,1,1,1);
		addComp(jpDetails, lblModuleLeader, 0,3,1,1,1,1);
		addComp(jpDetails, lblLeader, 1,3,2,1,1,1);
		addComp(jpDetails, lblModuleModerator, 0,4,1,1,1,1);
		addComp(jpDetails, lblModerator, 1,4,2,1,1,1);
		addComp(jpDetails, lblClasses, 0,5,1,1,0,0);
		addComp(jpDetails, btnClassList, 1,5,1,1,0,0);
		addComp(jpDetails, lblResults, 0,6,1,1,0,0);
		addComp(jpDetails, btnResults, 1,6,1,1,0,0);
		addComp(jpDetails, btnExit, 2,7,1,1,1,1);
		
		btnDetails.addActionListener(this);
		btnReset.addActionListener(this);
		btnExit.addActionListener(this);
		btnResults.addActionListener(this);
		btnClassList.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnDetails)
		{
			loadDetails();
		}
		else if(e.getSource() == btnReset)
		{
			tfSearch.setText("");
			loadModules();
		}
		else if(e.getSource() == btnExit)
		{
			dispose();
		}
		else if(e.getSource() == btnClassList)
		{
			if(lblModuleCodeAutoFill.getText().equals("MODXXXX") == false)
			{
				ClassRegisterForm crF = new ClassRegisterForm(lblModuleCodeAutoFill.getText().toString(), classes);
				crF.setSize(400,400);
				crF.setModal(true);
				crF.setVisible(true);
			}
			else
				JOptionPane.showMessageDialog(container, "No module Selected.");
		}
		else if(e.getSource() == btnResults)
		{
			if(lblModuleCodeAutoFill.getText().equals("MODXXXX") == false)
			{
				ModuleResultsForm mrF = new ModuleResultsForm(lblModuleCodeAutoFill.getText(), students, assignments, results);
				mrF.setSize(400,400);
				mrF.setModal(true);
				mrF.setVisible(true);
			}
			else
				JOptionPane.showMessageDialog(container, "No module Selected.");
		}
	}
	
	/**
	 * loads modules that match what is searched
	 * e.g. if 'Net' was search 'Networking' would be added
	 */
	public void loadModules()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		for(int i = 0; i < modules.size(); i++)
			try {
			if(tfSearch.getText().toString().toUpperCase().equals(modules.get(i).getModuleCode().substring(0, tfSearch.getText().length())) || tfSearch.getText().toString().toUpperCase().equals(modules.get(i).getModuleName().substring(0, tfSearch.getText().length()).toUpperCase()))
				cmbModules.addItem(modules.get(i).getModuleCode() + ": " + modules.get(i).getModuleName());
			}
			catch(StringIndexOutOfBoundsException e){}
		if(cmbModules.getItemCount() > 1 && tfSearch.getText().length() >= 1)		
			cmbModules.setSelectedIndex(1);
	}
	
	/**
	 * loads module details onto the form
	 */
	public void loadDetails()
	{
		Module fillM = new Module();
		boolean found = false;
		for(int i = 0; i < modules.size(); i++)
			try {
				if(cmbModules.getSelectedItem().toString().substring(0, 7).equals(modules.get(i).getModuleCode())) 
				{
					fillM = modules.get(i);
				found = true;
				}
				}
				catch(StringIndexOutOfBoundsException e){}
		if(found)
		{
			lblModuleCodeAutoFill.setText(fillM.getModuleCode());
			lblName.setText(fillM.getModuleName());
			lblLeader.setText(fillM.getModuleLeader() + ": " + tutors.get(fillM.getModuleLeader()).getForname() + ", " + tutors.get(fillM.getModuleLeader()).getSurname());
			lblModerator.setText(fillM.getModuleModerator() + ": " + academics.get(fillM.getModuleModerator()).getForname() + ", " + academics.get(fillM.getModuleModerator()).getSurname());
			lblCourseCodeAutoFill.setText(fillM.getCourseCode());
		}
		else 
		JOptionPane.showMessageDialog(container, "No module selected/found.");
		
	}

}
