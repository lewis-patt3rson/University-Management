package cw1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Class implements Serializable{
	
	String classCode;
	String moduleCode;
	String className;
	String students;
	
	/**
	 * constructor that takes in all data for a class
	 * @param classCode
	 * @param moduleCode
	 * @param className
	 */
	public Class(String classCode, String moduleCode, String className) {
		
		this.classCode = classCode;
		this.moduleCode = moduleCode;
		this.className = className;
		this.students = "";
	}

	/**
	 * return class code
	 * @return
	 */
	public String getClassCode() {
		return classCode;
	}

	/**
	 * sets the class code from string input
	 * @param classCode
	 */
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	/**
	 * returns module code
	 * @return
	 */
	public String getModuleCode() {
		return moduleCode;
	}

	/**
	 * sets module code from string input
	 * @param moduleCode
	 */
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	/**
	 * returns class name
	 * @return
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * sets class name from string input
	 * @param className
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * adds a student to the class list, from a student code being input
	 * @param studentID
	 */
	public void addStudent(String studentID)
	{
		if(this.students.equals(""))
			this.students += studentID;
		else
			this.students += ("," + studentID);
	}
	
	/**
	 * removes a student from the class list, from a student code being input
	 * @param studentID
	 */
	public void removeStudent(String studentID)
	{
		String[] values = this.students.split(",");
		ArrayList list = new ArrayList(Arrays.asList(values));

		
		for(int i = 0; i < list.size(); i++)
			if(list.get(i).equals(studentID))
				list.remove(i);
		if(list.size() > 0)
		{
			this.students = "";
		for(int i = 0; i < list.size(); i++)
			if(this.students.equals(""))
				this.students += list.get(i);
			else
				this.students += ("," + list.get(i));
		}
		else
			this.students = "";
	}
	
	/**
	 * returns all students
	 * @return
	 */
	public String getStudents()
	{
		return this.students;
	}
}
