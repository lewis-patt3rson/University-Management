package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class StudentAssignmentResults extends JDialog{

	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	private Container container;
	
	/**
	 * loads in the relevant lists for the form and student code, creates and adds gui elements to container
	 * loads results for each assignment for the selected student and adds them to the gui
	 * @param studentCode
	 * @param assignmentList
	 * @param resultList
	 */
	public StudentAssignmentResults(String studentCode, LinkedList assignmentList, LinkedList resultList)
	{
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		assignments = assignmentList;
		results = resultList;
		double min = 100, max = 0, avg = 0, count = 0;
		for(int i = 0; i < results.size(); i++)
		{
			if(results.get(i).getStudentCode().equals(studentCode))
			{
				if(results.get(i).getResult() < min)
					min = results.get(i).getResult();
				if(results.get(i).getResult() > max)
					max = results.get(i).getResult();
				avg += results.get(i).getResult();
				count++;
			}
		}
		if(count > 0)
			avg = (avg/count);
		else
			min = 0;
		
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> stuResList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(stuResList);
	
		dlm.addElement("Results for student: " + studentCode);
		dlm.addElement("Summary - Max: " + max + ", Min: " + min + ", Average: " + avg);
		dlm.addElement("All Results:");
		for(int i = 0; i < results.size(); i++)
		{
			String resultDetails = "";
			if(results.get(i).getStudentCode().equals(studentCode))
			{		
				resultDetails = results.get(i).getAssignmentCode() + " - Score: " + results.get(i).getResult()  + ", Grade: " + getGrade(results.get(i).getResult());
				dlm.addElement(resultDetails);
				resultDetails = "Feedback: " + results.get(i).getFeedBack();
				dlm.addElement(resultDetails);
			}
			
		}
		if(count == 0)
			dlm.addElement("This student has no results.");
		addComp(listScroller,0,1,1,1,1,1);				
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * returns a grade dependant on the result of an assignment
	 * @param result
	 * @return
	 */
	public String getGrade(double result)
	{
		String grade = "";
		
		if(result >= 70)
			grade = "Distinction";
		else if(result >= 60)
			grade = "Merit";
		else if(result >= 40)
			grade = "Pass";
		else
			grade = "Fail";
		
		return grade;
	}
	
}
