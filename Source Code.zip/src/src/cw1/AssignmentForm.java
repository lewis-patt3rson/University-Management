package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.*;

public class AssignmentForm extends JDialog implements ActionListener {

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	
	
	private JLabel lblHeader, lblMessage, lblAssignmentName, lblAssignmentSummary, lblDateAssigned, lblAssignmentCode, lblCode;
	private JTextField tfName, tfSummary;
	private Container container;
	private JPanel jpSearch, jpDetails;
	private JComboBox cmbCourses, cmbModules, cmbYear, cmbMonth, cmbDay;
	private JButton btnConfirmCourse, btnExit, btnCancel, btnCreate;
	private JCheckBox todaysDate;

	/**
	 * loads in the relevant lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param modulesList
	 * @param courseList
	 * @param assignmentList
	 */
	AssignmentForm(LinkedList modulesList,LinkedList courseList, LinkedList assignmentList)
	{
		courses = courseList;
		modules = modulesList;
		assignments = assignmentList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Create Assignment", JLabel.CENTER);
		lblMessage = new JLabel("Choose a module to create an assignment for:");
		lblAssignmentName = new JLabel("Assignment Name:", JLabel.RIGHT);
		lblAssignmentSummary = new JLabel("Summary:", JLabel.RIGHT);
		lblDateAssigned = new JLabel("Date Assigned:",JLabel.RIGHT);
		lblAssignmentCode = new JLabel("Assignment Code:",JLabel.RIGHT);
		lblCode = new JLabel(getAssignmentCode());
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		
		
		todaysDate = new JCheckBox("Use Today's Date");
		todaysDate.addActionListener(this);
		
		btnConfirmCourse = new JButton("Confirm Course");
		btnExit = new JButton("Exit");
		btnCancel = new JButton("Cancel");
		btnCreate = new JButton("Create Assignment");
		
		String[] years = new String[]{
			"2000","2001","2002","2003","2004","2005",
			"2006","2007","2008","2009","2010","2011",
			"2012","2013","2014","2015","2016","2017",
			"2018","2019","2020",
		};
		
		String[] months = new String[] {
				"Jan", "Feb", "Mar",
				"Apr","May","Jun",
				"Jul","Aug","Sep",
				"Oct","Nov","Dec"
		};
		
	
		cmbYear = new JComboBox(years);
		cmbMonth = new JComboBox(months);
		cmbDay = new JComboBox();
		
		tfName = new JTextField();
		tfSummary = new JTextField();
		
		loadCourses();
		
		
		addComp(container, jpSearch, 0,0,1,1,0,0);
		addComp(container, jpDetails, 0,1,1,1,1,1);
		
		addComp(jpSearch, lblHeader, 0,0,1,1,0,0);
		addComp(jpSearch, lblMessage, 0,1,1,1,0,0);
		addComp(jpSearch, cmbCourses, 0,2,1,1,1,1);
		addComp(jpSearch, cmbModules, 1,2,1,1,1,1);
		addComp(jpSearch, btnConfirmCourse,2,2,1,1,0,0);
		
		addComp(jpDetails, lblAssignmentCode,0,0,1,1,1,0);
		addComp(jpDetails, lblCode,1,0,1,1,1,0);
		addComp(jpDetails, lblAssignmentName,0,1,1,1,1,0);
		addComp(jpDetails, tfName,1,1,1,1,1,0);
		addComp(jpDetails, lblAssignmentSummary,0,4,1,1,1,1);
		addComp(jpDetails, tfSummary,1,4,1,1,1,1);
		addComp(jpDetails, lblDateAssigned,0,2,1,1,0,0);
		addComp(jpDetails, todaysDate,1,2,1,1,0,0);
		addComp(jpDetails, cmbYear,1,3,1,1,0,0);
		addComp(jpDetails, cmbMonth,2,3,1,1,0,0);
		addComp(jpDetails, cmbDay,3,3,1,1,0,0);
		addComp(jpDetails, btnExit,2,5,1,1,0,0);
		addComp(jpDetails, btnCancel,0,5,1,1,0,0);
		addComp(jpDetails, btnCreate,1,5,1,1,0,0);
		
		
		for(Component c: jpDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
		loadDays();
		cmbCourses.addActionListener(this);
		btnConfirmCourse.addActionListener(this);
		cmbMonth.addActionListener(this);
		btnExit.addActionListener(this);
		btnCancel.addActionListener(this);
		btnCreate.addActionListener(this);
		
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events for each button and combo box index change
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
		{
			cmbModules.removeAllItems();
			if(cmbCourses.getSelectedIndex() >= 1)
			{
				loadModulesFromCourse(cmbCourses.getSelectedItem().toString().substring(0,7));
			}
		}
		else if(e.getSource() == btnConfirmCourse)
		{
			if(checkModulePicked())
			{
				int dialogButton = JOptionPane.YES_NO_OPTION;
	            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to create\n an assignment for module: " + cmbModules.getSelectedItem(),"Confirm creation.", dialogButton);
	            if(dialogResult == JOptionPane.YES_OPTION)
	            {
	            	loadCreate();
	            }
			}
		}
		else if(e.getSource() == todaysDate)
		{
			if(todaysDate.isSelected())
			{
				cmbYear.setSelectedIndex(0);
				cmbMonth.setSelectedIndex(0);
				cmbDay.removeAllItems();
				cmbYear.setEnabled(false);
				cmbMonth.setEnabled(false);
				cmbDay.setEnabled(false);
			}
			else
			{
				cmbYear.setEnabled(true);
				cmbMonth.setEnabled(true);
				cmbDay.setEnabled(true);
			}
		}
		else if(e.getSource() == cmbMonth)
		{
			loadDays();
		}
		else if(e.getSource() == btnCreate)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to create\n assignment: " + tfName.getText() + "?","Confirm create.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	createAssignment();
            }
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to exit? ","Confirm exit.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnCancel)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to cancel? ","Confirm cancel.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
	}
	
	/**
	 * loads all courses into the combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}
	
	/**
	 * loads modules into the combo box for the selected course 
	 * @param CourseID
	 */
	public void loadModulesFromCourse(String CourseID)
	{	
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getCourseCode().equals(CourseID))
			{
				cmbModules.addItem( modules.get(i).getModuleCode()+ ": "+ modules.get(i).getModuleName());
			}
		}
	}

	/**
	 * Makes sure a module is selected 
	 * @return
	 */
	public boolean checkModulePicked()
	{
		boolean val = true;
		
		if(cmbModules.getItemCount() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a module.");
			val = false;
		}
		else if(cmbModules.getSelectedIndex() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a module.");
			val = false;
		}
		
		return val;
	}

	/**
	 * loads the create panel of the form
	 */
	public void loadCreate()
	{
		for(Component c: jpSearch.getComponents())
			c.setEnabled(false);
		for(Component c: jpDetails.getComponents())
			c.setEnabled(true);
	}
	
	/**
	 * loads days into the combo box, depending on the selected month
	 */
	public void loadDays()
	{
		int days = 0;
		switch(cmbMonth.getSelectedItem().toString())
		{
		case "Jan": 
			days = 31;
			break;
		case "Feb": 
			days = 28;
			break;
		case "Mar": 
			days = 31;
			break;
		case "Apr": 
			days = 30;
			break;
		case "May": 
			days = 31;
			break;
		case "Jun": 
			days = 30;
			break;
		case "Jul": 
			days = 31;
			break;
		case "Aug": 
			days = 31;
			break;
		case "Sep": 
			days = 30;
			break;
		case "Oct": 
			days = 31;
			break;
		case "Nov": 
			days = 30;
			break;
		case "Dec": 
			days = 31;
			break;
		}
		cmbDay.removeAllItems();
		for( int i = 0; i < days; i++)
			cmbDay.addItem(i+1);
	}

	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		for(Component c: jpSearch.getComponents())
			c.setEnabled(true);
		for(Component c: jpDetails.getComponents())
			c.setEnabled(false);
		cmbYear.setSelectedIndex(0);
		cmbMonth.setSelectedIndex(0);
		cmbDay.removeAllItems();
		tfName.setText("");
		tfSummary.setText("");
		cmbModules.removeAllItems();
		cmbCourses.setSelectedIndex(0);
		btnExit.setEnabled(true);
		lblCode.setText(getAssignmentCode());
	}

	/**
	 * makes sure all information is valid and if so creates an assignment with the data
	 */
	public void createAssignment()
	{
		String summary = "", name = "", date = "";
		boolean val = true;
		
		if(tfName.getText().length() >= 3)
			name = tfName.getText();
		else
		{
			val = false;
			JOptionPane.showMessageDialog(container, "Name must be atleast 3 characters long");
		}
		
		if(tfSummary.getText().length() >= 15)
			summary = tfSummary.getText();
		else
		{
			val = false;
			JOptionPane.showMessageDialog(container, "Summary must be atleast 15 characters long");
		}
		
		if(todaysDate.isSelected())
			date = LocalDateTime.now().getDayOfMonth() + "/" + LocalDateTime.now().getMonth().name().substring(0,3) + "/" + LocalDateTime.now().getYear();
		else if(cmbDay.getSelectedIndex() > 0)
			date = cmbDay.getSelectedItem() + "/" + cmbMonth.getSelectedItem().toString().toUpperCase() + "/" +cmbYear.getSelectedItem();
		else
		{
			val = false;
			JOptionPane.showMessageDialog(container, "You must choose a date");
		}
		
		if(val)
		{
			Assignment newA = new Assignment(lblCode.getText().toString(), name, date, cmbModules.getSelectedItem().toString().substring(0, 7), tfSummary.getText().toString());		
			assignments.add(newA);
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Would you like to create another assignment?","Create another.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
            else
            {
            	dispose();
            }
		}
	}
	
	/**
	 * gets the last assignment code and adds 1 to it for the new code, if there are no assignments this is ASS1001
	 * @return
	 */
	public String getAssignmentCode()
	{
		String code = "";
		if(assignments.size() > 0)
		{
			code = assignments.getLast().getAssignmentCode();
			int idUpdate = Integer.parseInt(code.substring(3));
			code = "ASS" + (idUpdate +1);
		}
		else {
			code = "ASS1001";
		}
		return code;
	}
}
