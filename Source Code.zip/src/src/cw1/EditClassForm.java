package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.*;

public class EditClassForm extends JDialog implements ActionListener{

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private JComboBox cmbCourses, cmbModules, cmbClasses, cmbEditCourses, cmbEditModules;
	private JPanel jpSearch, jpDetails;
	private JButton btnDelete, btnEdit, btnExit, btnReset, btnConfirmEdit;
	private Container container;
	private JLabel lblHeader, lblMessage, lblCourse, lblModule, lblClass, lblClassCode, lblCode, lblClassName, lblEditCourse, lblEditModule;
	private JTextField tfName;
	
	/**
	 * loads in the relevant lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param classList
	 * @param moduleList
	 * @param courseList
	 */
	public EditClassForm(LinkedList classList, LinkedList moduleList, LinkedList courseList)
	{
		courses = courseList;
		modules = moduleList;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
	
		lblHeader = new JLabel("Class Detials", JLabel.CENTER);
		lblMessage = new JLabel("Choose a class to edit:");
		lblCourse = new JLabel("Course:");
		lblModule = new JLabel("Module:");
		lblClass = new JLabel("Class:");
		
		lblClassCode = new JLabel("Class Code:",JLabel.RIGHT);
		lblCode = new JLabel("CLAXXXX");
		lblClassName = new JLabel("Class Name:",JLabel.RIGHT);
		lblEditCourse = new JLabel("Course:",JLabel.RIGHT);
		lblEditModule = new JLabel("Module:",JLabel.RIGHT);
		
		btnDelete = new JButton("Delete");
		btnEdit = new JButton("Edit");
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnConfirmEdit = new JButton("Edit Details");
		
		tfName = new JTextField("");
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		cmbClasses = new JComboBox();
		cmbEditCourses = new JComboBox();
		cmbEditModules = new JComboBox();
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,0,0);
		
		addComp(jpSearch, lblHeader,0,0,4,1,0,0);
		addComp(jpSearch, lblMessage,0,1,1,1,1,0);
		addComp(jpSearch, lblCourse,0,2,1,1,0,0);
		addComp(jpSearch, lblModule,1,2,1,1,1,0);
		addComp(jpSearch, lblClass,2,2,1,1,1,0);
		addComp(jpSearch, cmbCourses,0,3,1,1,1,0);
		addComp(jpSearch, cmbModules,1,3,1,1,1,0);
		addComp(jpSearch, cmbClasses,2,3,1,1,1,0);
		addComp(jpSearch, btnEdit,3,2,1,1,0,0);
		addComp(jpSearch, btnDelete,3,3,1,1,0,0);
		
		addComp(jpDetails, lblClassCode, 0,0,1,1,0,0);
		addComp(jpDetails, lblCode, 1,0,1,1,0,0);
		addComp(jpDetails, lblClassName, 0,1,1,1,1,0);
		addComp(jpDetails, tfName, 1,1,1,1,0,0);
		addComp(jpDetails, lblEditCourse, 0,2,1,1,0,0);
		addComp(jpDetails, cmbEditCourses, 1,2,1,1,1,0);
		addComp(jpDetails, lblEditModule, 0,3,1,1,0,0);
		addComp(jpDetails, cmbEditModules, 1,3,1,1,1,0);
		addComp(jpDetails, btnExit, 0,4,1,1,1,0);
		addComp(jpDetails, btnReset, 1,4,1,1,1,0);
		addComp(jpDetails, btnConfirmEdit, 2,4,1,1,1,0);
		
		btnDelete.addActionListener(this);
		btnEdit.addActionListener(this);
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnConfirmEdit.addActionListener(this);
		cmbModules.addActionListener(this);
		cmbCourses.addActionListener(this);
		cmbEditCourses.addActionListener(this);
		
		for(Component c: jpDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
		loadCourses();
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }

	/**
	 * loads events from buttons and combo boxes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
			loadModules();
		else if(e.getSource() == cmbEditCourses)
			loadEditModules();
		else if(e.getSource() == cmbModules)
			loadClasses();
		else if(e.getSource() == btnDelete)
			delete();
		else if(e.getSource() == btnEdit)
			loadEdit();
		else if(e.getSource() == btnReset)
			resetForm();
		else if(e.getSource() == btnExit)
			exit();
		else if(e.getSource() == btnConfirmEdit)
			edit();
	}
	
	/**
	 * loads all courses into a combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0; i < courses.size(); i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " + courses.get(i).getCourseName());
	}
	
	/**
	 * loads all modules from selected course into a combo box
	 */
	public void loadModules()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		if(cmbCourses.getSelectedIndex() > 0)
		{
			for(int i = 0; i < modules.size(); i++)
			{
				if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
				{
					cmbModules.addItem(modules.get(i).getModuleCode() + ": " + modules.get(i).getModuleName());
				}
			}
		}
	}
	
	/**
	 * loads all classes from selected modules into a combo box
	 */
	public void loadClasses()
	{
		cmbClasses.removeAllItems();
		cmbClasses.addItem("...");
		if(cmbModules.getSelectedIndex() > 0)
		{
			for(int i = 0; i < classes.size(); i++)
			{
				if(classes.get(i).getModuleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
				{
					cmbClasses.addItem(classes.get(i).getClassCode() + ": " + classes.get(i).getClassName());
				}
			}
		}
	}
	
	/**
	 * loads all courses into the edit combo box
	 */
	public void loadEditCourses()
	{
		cmbEditCourses.removeAllItems();
		cmbEditCourses.addItem("...");
		for(int i =0; i < courses.size(); i++)
			cmbEditCourses.addItem(courses.get(i).getCourseCode() + ": " + courses.get(i).getCourseName());
	}
	
	/**
	 * loads all modules into the edit combo box from the selected course
	 */
	public void loadEditModules()
	{
		cmbEditModules.removeAllItems();
		cmbEditModules.addItem("...");
		if(cmbEditCourses.getSelectedIndex() > 0)
		{
			for(int i = 0; i < modules.size(); i++)
			{
				if(modules.get(i).getCourseCode().equals(cmbEditCourses.getSelectedItem().toString().substring(0,7)))
				{
					cmbEditModules.addItem(modules.get(i).getModuleCode() + ": " + modules.get(i).getModuleName());
				}
			}
		}
	}
	
	/**
	 * confirms they want to delete selected class and then deletes it
	 */
	public void delete()
	{
		if(cmbClasses.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to delete\nClass: " + cmbClasses.getSelectedItem().toString() + "?","Delete", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	int index = 0;
            	for(int i = 0; i < classes.size(); i++)
            		if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
            			index = i;
            	classes.remove(index);
            	JOptionPane.showMessageDialog(container, "Class Deleted!");
            	int dialogButton2 = JOptionPane.YES_NO_OPTION;
                int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another class?","Edit/delete another", dialogButton);
                if(dialogResult2 == JOptionPane.YES_OPTION)
                {
                	resetForm();
                }
                else
                {
                	dispose();
                }
            }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a class to delete");
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		cmbCourses.setSelectedIndex(0);
		cmbEditCourses.setSelectedIndex(0);
		lblCode.setText("CLAXXXX");
		tfName.setText("");
		for(Component c: jpDetails.getComponents())
			c.setEnabled(false);
		for(Component c: jpSearch.getComponents())
			c.setEnabled(true);
	}
	
	/**
	 * loads the edit panel on the form
	 */
	public void loadEdit()
	{
		if(cmbClasses.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit\nClass: " + cmbClasses.getSelectedItem().toString() + "?","Edit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	lblCode.setText(cmbClasses.getSelectedItem().toString().substring(0,7));
				tfName.setText(cmbClasses.getSelectedItem().toString().substring(9));
				loadEditCourses();
				loadEditModules();
				for(Component c: jpDetails.getComponents())
					c.setEnabled(true);
				for(Component c: jpSearch.getComponents())
					c.setEnabled(false);
            }
        }
		else
			JOptionPane.showMessageDialog(container, "You must choose a class to edit");
	}
	
	/**
	 * confirms exit and then exits
	 */
	public void exit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	dispose();
        }
	}

	/**
	 * confirms input validation and if valid, edits the selected class
	 */
	public void edit()
	{
		boolean val = true;
		
		if(tfName.getText().length() == 0)
		{
			val = false;
			JOptionPane.showMessageDialog(container, "Class must have a name");
		}
		
		if(cmbEditModules.getSelectedIndex() == 0)
		{
			val = false;
			JOptionPane.showMessageDialog(container, "You must choose a module");
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit" + cmbClasses.getSelectedItem().toString() + "?","Confirm edit", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	for(int i = 0; i < classes.size(); i++)
	        		if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
	        		{
	        			classes.get(i).setClassName(tfName.getText());
	        			classes.get(i).setModuleCode(cmbEditModules.getSelectedItem().toString().substring(0,7));
	        			JOptionPane.showMessageDialog(container, "Class edited successfully!");
	        		}
	        	int dialogButton2 = JOptionPane.YES_NO_OPTION;
		        int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another?","Edit/delete another", dialogButton2);
		        if(dialogResult2 == JOptionPane.YES_OPTION)		       
		        	resetForm();		       
		        else	     
		        	dispose();
		        
	        }
		}
	}
}

