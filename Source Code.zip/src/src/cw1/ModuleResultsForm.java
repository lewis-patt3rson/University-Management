package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.*;

public class ModuleResultsForm extends JDialog{

	HashMap<String,Student> students = new HashMap<String,Student>();
	
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	
	private Container container;
	private JLabel lblHeader, lblMessage;
	/**
	 * loads in the relevant lists, map and modulecode for the form, creates and adds gui elements to container
	 * loads the results from each assignment for the module and adds them to the gui
	 * @param moduleCode
	 * @param studentMap
	 * @param assignmentList
	 * @param resultList
	 */
	public ModuleResultsForm(String moduleCode, HashMap studentMap, LinkedList assignmentList, LinkedList resultList)
	{
		assignments = assignmentList;
		results = resultList;
		students = studentMap;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
	
		lblHeader = new JLabel("Results for module code: " + moduleCode);
		lblMessage = new JLabel("Max: 0, Min: 0, Avg: 0");
		double min = 100, max = 0, avg = 0;
		int count = 0;
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> modClassList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(modClassList);
		
		
		for(int i = 0; i < assignments.size(); i++)
			if(assignments.get(i).gemoduleCode().equals(moduleCode))
			{
				dlm.addElement("Assignment: " + assignments.get(i).getAssignmentCode());
				for(int j = 0; j < results.size(); j++)
					if(results.get(j).getAssignmentCode().equals(assignments.get(i).getAssignmentCode()))
					{
						dlm.addElement("Student: " + results.get(j).getStudentCode() + " - Result: " + results.get(j).getResult());
						if(results.get(j).getResult() < min)
							min = results.get(j).getResult();
						if(results.get(j).getResult() > max)
							max = results.get(j).getResult();
						avg += results.get(j).getResult();
						count++;
					}
			}
		avg = (avg/count);
		if(count == 0)
			dlm.addElement("There are no results for this module.");
		else
			lblMessage = new JLabel("Max: " + max + ", Min: " + min + ", Avg: "  + avg);
		
		addComp(lblHeader,0,1,1,1,1,1);
		addComp(lblMessage,0,2,1,1,1,1);
		addComp(listScroller,0,3,1,1,1,1);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
}
