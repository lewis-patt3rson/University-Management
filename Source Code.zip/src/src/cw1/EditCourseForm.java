package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.*;


public class EditCourseForm extends JDialog implements ActionListener{

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private Container container;
	private JLabel lblHeader, lblCourseCode, lblCourseCodeAutoFill, lblCourseName, lblMessage;
	private JTextField tfName;
	private JButton btnExit, btnCancel, btnEditCourse, btnEdit, btnDelete;
	private JComboBox cmbCourses;
	
    /**
     * loads in the relevant lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
     * @param courseList
     * @param moduleList
     * @param classList
     */
	public EditCourseForm(LinkedList courseList, LinkedList moduleList, LinkedList classList)
	{
		modules = moduleList;
		classes = classList;
		courses = courseList;
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Edit Course", JLabel.CENTER);
		lblMessage = new JLabel("Please choose a course to edit:");
		lblCourseCode = new JLabel("Course Code:", JLabel.RIGHT);
		lblCourseCodeAutoFill = new JLabel("COUXXXX", JLabel.LEFT);
		lblCourseName = new JLabel("Course Name:", JLabel.RIGHT);
		
		tfName = new JTextField();
		
		btnExit = new JButton("Exit");
		btnCancel = new JButton("Reset");
		btnEditCourse = new JButton("Confirm Edit");
		btnEdit = new JButton("Edit");
		btnDelete = new JButton("Delete");
		
		cmbCourses = new JComboBox();
		
		addComp(lblHeader,0,0,3,1,1,1);
		addComp(lblMessage,0,1,2,1,1,1);
		addComp(cmbCourses,0,2,2,1,1,1);
		addComp(btnEdit,2,1,1,1,1,1);
		addComp(btnDelete,2,2,1,1,1,1);
		addComp(lblCourseCode,0,3,1,1,1,1);
		addComp(lblCourseCodeAutoFill,1,3,1,1,1,1);
		addComp(lblCourseName,0,4,1,1,1,1);
		addComp(tfName,1,4,2,1,1,1);
		addComp(btnExit,0,5,1,1,1,1);
		addComp(btnCancel,1,5,1,1,1,1);
		addComp(btnEditCourse,2,5,1,1,1,1);
		
		disableEditable();
		loadCourses();
		
		btnEdit.addActionListener(this);
		btnDelete.addActionListener(this);
		btnExit.addActionListener(this);
		btnCancel.addActionListener(this);
		btnEditCourse.addActionListener(this);

		
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * loads events from buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnEdit)
		{
			if(confirm())
			{
				loadEdit();
			}
		}
		else if(e.getSource() == btnDelete)
		{
			if(confirm())
			{
				delete();
			}
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnCancel)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnEditCourse)
		{
			
		}
	}

	/**
	 * disable the edit panel
	 */
	public void disableEditable()
	{
		tfName.setEnabled(false);
		btnEditCourse.setEnabled(false);
		btnCancel.setEnabled(false);
	}
	
	/**
	 * enable the edit panel
	 */
	public void enableEditable()
	{
		tfName.setEnabled(true);
		btnEditCourse.setEnabled(true);
		btnCancel.setEnabled(true);
	}
	
	/**
	 * load courses into combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}
	
	/**
	 * confirms deleting
	 * @return
	 */
	public boolean confirm()
	{
		boolean val = false;
		if(cmbCourses.getSelectedIndex() >= 1)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit/delete\nCourse: " + cmbCourses.getSelectedItem().toString() + "?","Confirm edit/delete", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	val = true;
            }
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a course to edit/delete.");
		}
		return val;
	}
	
	/**
	 * loads the edit panel
	 */
	public void loadEdit()
	{
		cmbCourses.setEnabled(false);
		btnEdit.setEnabled(false);
		btnDelete.setEnabled(false);
		enableEditable();
		lblCourseCodeAutoFill.setText(cmbCourses.getSelectedItem().toString().substring(0,7));
		tfName.setText(cmbCourses.getSelectedItem().toString().substring(8));
	}
	
	/**
	 * deletes courses
	 */
	public void delete()
	{
		ArrayList<String> codes = new ArrayList<String>();
		Boolean val = true;
		int index =0;
		for(int i = 0 ; i < modules.size(); i++)
			if(modules.get(i).getModuleCode().equals(cmbCourses.getSelectedItem().toString().substring(0, 7)))
				val = false;
			
		if(!val)
		{
			JOptionPane.showMessageDialog(container, "You can not delete this course as\n there are modules for it/.");
		}
		else
		{
			for(int i = 0; i < courses.size(); i++) {
				if(courses.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0, 7)))
					index = i;
			}
			courses.remove(index);
			JOptionPane.showMessageDialog(container, "Course deleted successfully!");
			resetForm();
		}
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		disableEditable();
		cmbCourses.setEnabled(true);
		btnEdit.setEnabled(true);
		btnDelete.setEnabled(true);
		tfName.setText("");
		lblCourseCodeAutoFill.setText("COUXXXX");
		loadCourses();
	}
}
