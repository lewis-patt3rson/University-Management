package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.*;

public class ClassDetailsForm extends JDialog implements ActionListener{

	HashMap<String,Student> students = new HashMap<String,Student>();
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	
	private JComboBox cmbCourses, cmbModules, cmbClasses;
	private Container container;
	private JLabel lblHeader, lblMessage, lblCourse, lblModule, lblClass, lblClassCode, lblCode, lblClassName, lblName, lblRegister, lblClassSize, lblClassSizeFill;
	private JButton btnDetails, btnReset, btnRegister, btnExit;
	private JPanel jpSearch, jpDetails;
	
	/**
	 * loads in the relevant map and lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param studentMap
	 * @param classList
	 * @param moduleList
	 * @param courseList
	 */
	public ClassDetailsForm(HashMap studentMap, LinkedList classList, LinkedList moduleList, LinkedList courseList)
	{
		students = studentMap;
		courses = courseList;
		modules = moduleList;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Class Detials", JLabel.CENTER);
		lblMessage = new JLabel("Choose a class to display:");
		lblCourse = new JLabel("Course:");
		lblModule = new JLabel("Module:");
		lblClass = new JLabel("Class:");
		
		lblClassCode = new JLabel("Class code:", JLabel.RIGHT);
		lblCode = new JLabel("CLAXXXX");
		lblClassName = new JLabel("Name:", JLabel.RIGHT);
		lblName = new JLabel("XXXXXXX");
		lblRegister = new JLabel("Register:");
		lblClassSize = new JLabel("Students in class:");
		lblClassSizeFill = new JLabel("");
		
		btnReset = new JButton("Reset");
		btnDetails = new JButton("Show details");
		btnExit = new JButton("Exit");
		btnRegister = new JButton("View Register");
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		cmbClasses = new JComboBox();
		
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,0,0);
		
		addComp(jpSearch, lblHeader,0,0,4,1,0,0);
		addComp(jpSearch, lblMessage,0,1,1,1,1,0);
		addComp(jpSearch, lblCourse,0,2,1,1,0,0);
		addComp(jpSearch, lblModule,1,2,1,1,1,0);
		addComp(jpSearch, lblClass,2,2,1,1,1,0);
		addComp(jpSearch, cmbCourses,0,3,1,1,1,0);
		addComp(jpSearch, cmbModules,1,3,1,1,1,0);
		addComp(jpSearch, cmbClasses,2,3,1,1,1,0);
		addComp(jpSearch, btnReset,3,2,1,1,0,0);
		addComp(jpSearch, btnDetails,3,3,1,1,0,0);
		
		addComp(jpDetails, lblClassCode,0,0,1,1,0,0);
		addComp(jpDetails, lblCode,1,0,1,1,0,0);
		addComp(jpDetails, lblClassName,0,1,1,1,0,0);
		addComp(jpDetails, lblName,1,1,1,1,0,0);
		addComp(jpDetails, lblRegister,0,2,1,1,0,0);
		addComp(jpDetails, btnRegister,1,2,1,1,0,0);
		addComp(jpDetails, lblClassSize,0,3,1,1,0,0);
		addComp(jpDetails, lblClassSizeFill,1,3,1,1,0,0);
		addComp(jpDetails, btnExit,0,4,2,1,0,0);
		
		loadCourses();
		
		cmbCourses.addActionListener(this);
		cmbModules.addActionListener(this);
		btnReset.addActionListener(this);
		btnDetails.addActionListener(this);
		btnExit.addActionListener(this);
		btnRegister.addActionListener(this);
		
		/*
		ClassStudentsForm emf = new ClassStudentsForm(students, classes, "CLA1001");
		emf.setSize(800,800);
		emf.setModal(true);
		emf.setVisible(true);
		*/
	}

	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from button and combo box index changes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
			loadModules();
		else if(e.getSource() == cmbModules)
			loadClasses();
		else if(e.getSource() == btnReset)
			resetForm();
		else if(e.getSource() == btnDetails)
			loadDetails();
		else if(e.getSource() == btnExit)
			dispose();
		else if(e.getSource() == btnRegister)
			loadRegister();
	}
	
	/**
	 * loads courses into the combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0; i < courses.size(); i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " + courses.get(i).getCourseName());
	}
	
	/**
	 * loads modules from the selected course into the combo box
	 */
	public void loadModules()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		if(cmbCourses.getSelectedIndex() > 0)
		{
			for(int i = 0; i < modules.size(); i++)
			{
				if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
				{
					cmbModules.addItem(modules.get(i).getModuleCode() + ": " + modules.get(i).getModuleName());
				}
			}
		}
	}
	
	/**
	 * loads classes from the selected module into the combo box
	 */
	public void loadClasses()
	{
		cmbClasses.removeAllItems();
		cmbClasses.addItem("...");
		if(cmbModules.getSelectedIndex() > 0)
		{
			for(int i = 0; i < classes.size(); i++)
			{
				if(classes.get(i).getModuleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
				{
					cmbClasses.addItem(classes.get(i).getClassCode() + ": " + classes.get(i).getClassName());
				}
			}
		}
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		cmbCourses.setSelectedIndex(0);
		lblCode.setText("CLAXXXX");
		lblName.setText("XXXXXXX");
		lblClassSizeFill.setText("");
	}
	
	/**
	 * loads the details of the selected class into the form
	 */
	public void loadDetails()
	{
		if(cmbClasses.getSelectedIndex() > 0)
		{
			for(int i = 0; i < classes.size(); i++)
				if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
				{
					lblName.setText(classes.get(i).getClassName());
					lblCode.setText(classes.get(i).getClassCode());
					if(classes.get(i).getStudents().length() > 0)
					{
					String[] values = classes.get(i).getStudents().split(",");
					lblClassSizeFill.setText(""+values.length);
					}
					else
						lblClassSizeFill.setText("0");
				}
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a class.");
	}
	
	/**
	 * opens the register form for the selected class
	 */
	public void loadRegister()
	{
		if(!lblCode.getText().equals("CLAXXXX") && !lblClassSizeFill.getText().equals("0"))
		{
		ClassStudentsForm emf = new ClassStudentsForm(students, classes, cmbClasses.getSelectedItem().toString().substring(0,7));
		emf.setSize(800,800);
		emf.setModal(true);
		emf.setVisible(true);
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a class with students to view the register");
	}
}
