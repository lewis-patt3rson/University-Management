package cw1;

import java.io.Serializable;

public class Assignment implements Serializable {
	
	String assignmentCode;
	String assignmentName;
	String dateIssued;
	String moduleCode;
	String summary;
	
	/**
	 * constructor that takes in all academic data
	 * @param assignmentCode
	 * @param assignmentName
	 * @param dateIssued
	 * @param moduleCode
	 * @param summary
	 */
	public Assignment(String assignmentCode, String assignmentName, String dateIssued, String moduleCode, String summary)
	{
		this.assignmentCode = assignmentCode;
		this.assignmentName = assignmentName;
		this.dateIssued = dateIssued;
		this.moduleCode = moduleCode;
		this.summary = summary;
	}
	
	/**
	 * blank constructor
	 */
	public Assignment()
	{
		this.assignmentCode = "";
		this.assignmentName = "";
		this.dateIssued = "";
		this.moduleCode = "";
		this.summary = "";
	}

	/**
	 * returns summary
	 * @return
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * sets summary for string input
	 * @param summary
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * returns assignment code
	 * @return
	 */
	public String getAssignmentCode() {
		return assignmentCode;
	}

	/**
	 * sets assignment code from string input
	 * @param assignmentCode
	 */
	public void setAssignmentCode(String assignmentCode) {
		this.assignmentCode = assignmentCode;
	}

	/**
	 * returns assignment name
	 * @return
	 */
	public String getAssignmentName() {
		return assignmentName;
	}

	/**
	 * sets assignment name from string input
	 * @param assignmentName
	 */
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}

	/**
	 * returns date
	 * @return
	 */
	public String getDateIssued() {
		return dateIssued;
	}

	/**
	 * sets date from string input
	 * @param dateIssued
	 */
	public void setDateIssued(String dateIssued) {
		this.dateIssued = dateIssued;
	}

	/**
	 * returns module code
	 * @return
	 */
	public String gemoduleCode() {
		return moduleCode;
	}

	/**
	 * sets module code from string input
	 * @param moduleCode
	 */
	public void setmoduleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	
	
}
