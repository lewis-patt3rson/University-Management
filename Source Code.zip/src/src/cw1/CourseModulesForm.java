package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.LinkedList;

import javax.swing.*;

public class CourseModulesForm extends JDialog{

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private Container container;
	private JLabel lblHeader;
	
	/**
	 * loads in relevant information for the course chosen and its modules and classes
	 * loads each module and its info into the gui, along with the amount of classes that module has
	 * @param courseCode
	 * @param courseList
	 * @param moduleList
	 * @param classList
	 */
	public CourseModulesForm(String courseCode, LinkedList courseList, LinkedList moduleList, LinkedList classList)
	{
		courses = courseList;
		modules = moduleList;
		classes = classList;
		
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> modList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(modList);
	
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Modules for course: " + courseCode);
		
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getCourseCode().equals(courseCode)) {
				String moduleDetails = "";
				int classCount = 0;
				for(int j = 0; j < classes.size(); j++)
					if(classes.get(j).getModuleCode().equals(modules.get(i).getModuleCode()))
						classCount++;
				moduleDetails = modules.get(i).getModuleCode() + ": Name: " + modules.get(i).getModuleName() + "  -  Classes Held: " + classCount;
				dlm.addElement(moduleDetails);
			}	
		}
		
		addComp(lblHeader,0,0,1,1,0,0);
		addComp(listScroller,0,1,1,1,1,1);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	
}
