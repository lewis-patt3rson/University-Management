package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.*;

public class ClassRegisterForm extends JDialog {
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private JLabel lblHeader;
	private Container container;
	private JList modClassList;
	private JScrollPane listScroller;
	
	/**
	 * loads in details for the classes and the module selected
	 * displays all classes for the module and the amount of students in each
	 * adds them to the gui
	 * @param moduleCode
	 * @param classList
	 */
	public ClassRegisterForm(String moduleCode, LinkedList classList)
	{
		classes = classList;
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Classes for module: " + moduleCode);
		
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> modClassList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(modClassList);
		
		for(int i = 0; i < classes.size(); i++)
			if(classes.get(i).getModuleCode().equals(moduleCode)) {
				String classDetails = "";
				String[] values = classes.get(i).getStudents().split(",");
				classDetails = classes.get(i).getClassCode() + ": Name: " + classes.get(i).getClassName() + "  -  Students in class: " + values.length;
				dlm.addElement(classDetails);
			}	
		addComp(lblHeader,0,0,1,1,0,0);
		addComp(listScroller,0,1,1,1,1,1);				
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
}
