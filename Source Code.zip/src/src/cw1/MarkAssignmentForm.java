package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.*;

public class MarkAssignmentForm extends JDialog implements ActionListener{

	HashMap<String,Student> students = new HashMap<String,Student>();

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	LinkedList<Class> classes = new LinkedList<Class>();

	private Container container;
	private JPanel jpSearch, jpMark;
	private JLabel lblHeader, lblMessage, lblCourse, lblModule, lblAssignment, lblAssignmentCode, lblCode, lblAssignmentName, lblName, lblAssignmentDate, lblDate, lblAssignmentSummary, lblSummary, lblStudent, lblGrade, lblFeedback;
	private JComboBox cmbCourses, cmbModules, cmbAssignments, cmbStudents;
	private JButton btnReset, btnMarkAssignment, btnAddResult, btnDeleteResult, btnExit, btnCancelMark;
	private JTextField tfResult, tfFeedback;
	
	/**
	 * loads in the relevant lists and map for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param courseList
	 * @param moduleList
	 * @param classList
	 * @param assignmentList
	 * @param resultList
	 * @param studentMap
	 */
	public MarkAssignmentForm(LinkedList courseList,LinkedList moduleList,LinkedList classList, LinkedList assignmentList, LinkedList resultList, HashMap studentMap)
	{
		courses = courseList;
		modules = moduleList;
		assignments = assignmentList;
		results = resultList;
		students = studentMap;
		classes = classList;
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpMark = new JPanel();
		jpMark.setLayout(new GridBagLayout());
		jpMark.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Mark assignments", JLabel.CENTER);
		lblMessage = new JLabel("Choose an assignment to mark:");
		lblCourse = new JLabel("Course:");
		lblModule = new JLabel("Module:");
		lblAssignment = new JLabel("Assignment:");
		
		lblAssignmentCode = new JLabel("Assignment Code:", JLabel.RIGHT);
		lblCode = new JLabel("ASSXXXX");
		lblAssignmentName = new JLabel("Name:", JLabel.RIGHT);
		lblName = new JLabel("XXXXXXX");
		lblAssignmentDate = new JLabel("Date assigned:", JLabel.RIGHT);
		lblDate = new JLabel("XX/XX/XXXX");
		lblAssignmentSummary = new JLabel("Summary:", JLabel.RIGHT);
		lblSummary = new JLabel("XXXXXXX");
		lblStudent = new JLabel("Choose a student to mark");
		lblGrade = new JLabel("Result:", JLabel.RIGHT);
		lblFeedback = new JLabel("Feedback:", JLabel.CENTER);
		
		btnReset = new JButton("Reset");
		btnMarkAssignment = new JButton("Mark Assignment");
		btnAddResult = new JButton("Mark Assignment");
		btnDeleteResult = new JButton("Delete Result");
		btnExit = new JButton("Exit");
		btnCancelMark = new JButton("Choose new assignment");
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		cmbAssignments = new JComboBox();
		cmbStudents = new JComboBox();
		loadCourses();
		
		tfResult = new JTextField("");
		tfFeedback = new JTextField("");
		
		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpMark,0,1,1,1,0,0);
		
		addComp(jpSearch, lblHeader,0,0,4,1,0,0);
		addComp(jpSearch, lblMessage,0,1,1,1,0,0);
		addComp(jpSearch, lblCourse,0,2,1,1,0,0);
		addComp(jpSearch, lblModule,1,2,1,1,0,0);
		addComp(jpSearch, lblAssignment,2,2,1,1,0,0);
		addComp(jpSearch, cmbCourses,0,3,1,1,0,0);
		addComp(jpSearch, cmbModules,1,3,1,1,0,0);
		addComp(jpSearch, cmbAssignments,2,3,1,1,0,0);
		addComp(jpSearch, btnReset,3,2,1,1,0,0);
		addComp(jpSearch, btnMarkAssignment,3,3,1,1,0,0);
		
		addComp(jpMark, lblAssignmentCode,0,0,1,1,0,0);
		addComp(jpMark, lblCode,1,0,1,1,0,0);
		addComp(jpMark, lblAssignmentName,0,1,1,1,0,0);
		addComp(jpMark, lblName,1,1,1,1,0,0);
		addComp(jpMark, lblAssignmentDate,0,2,1,1,0,0);
		addComp(jpMark, lblDate,1,2,1,1,0,0);
		addComp(jpMark, lblAssignmentSummary,0,3,1,1,0,0);
		addComp(jpMark, lblSummary,1,3,1,1,0,0);
		addComp(jpMark, lblStudent,2,0,2,1,0,0);
		addComp(jpMark, cmbStudents,2,1,2,1,0,0);
		addComp(jpMark, lblGrade,2,2,1,1,0,0);
		addComp(jpMark, tfResult,3,2,1,1,0,0);
		addComp(jpMark, lblFeedback,2,3,2,1,0,0);
		addComp(jpMark, tfFeedback,2,4,2,1,0,0);
		addComp(jpMark, btnAddResult,3,5,1,1,0,0);
		addComp(jpMark, btnDeleteResult,2,5,1,1,0,0);
		addComp(jpMark, btnExit,0,5,1,1,0,0);
		addComp(jpMark, btnCancelMark,1,5,1,1,0,0);
		
		
		btnReset.addActionListener(this);
		btnMarkAssignment.addActionListener(this);
		cmbCourses.addActionListener(this);
		cmbModules.addActionListener(this);
		btnAddResult.addActionListener(this);
		btnDeleteResult.addActionListener(this);
		btnExit.addActionListener(this);
		btnCancelMark.addActionListener(this);
		
		for(Component c: jpMark.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
    }
	
	/**
	 * loads events from combo box and buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
			loadModulesFromCourse();
		else if(e.getSource() == cmbModules)
			loadAssignmentsFromModules();
		else if(e.getSource() == btnReset)
			cmbCourses.setSelectedIndex(0);
		else if(e.getSource() == btnMarkAssignment)
			loadMark();
		else if(e.getSource() == btnDeleteResult)
			deleteResult();
		else if(e.getSource() == btnExit)
			exit();
		else if(e.getSource() == btnCancelMark)
			resetForm();
		else if(e.getSource() == btnAddResult)
			addResult();
	}

	/**
	 * loads all courses into combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}
	
	/**
	 * confirms exit then exits
	 */
	public void exit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit.", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	dispose();
        }
	}
	
	/**
	 * loads all modules for selected course into combo box
	 */
	public void loadModulesFromCourse()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		if(cmbCourses.getSelectedIndex() > 0)
			for(int i = 0; i < modules.size(); i++)
				if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
					cmbModules.addItem( modules.get(i).getModuleCode()+ ": "+ modules.get(i).getModuleName());	
	}
	
	/**
	 * loads all assignments for selected modules into combo box
	 */
	public void loadAssignmentsFromModules()
	{
		cmbAssignments.removeAllItems();
		cmbAssignments.addItem("...");
		if(cmbModules.getSelectedIndex() > 0)
			for(int i =0; i < assignments.size(); i++)
				if(assignments.get(i).gemoduleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
					cmbAssignments.addItem(assignments.get(i).getAssignmentCode()  +": " + assignments.get(i).getAssignmentName());
	}

	/**
	 * loads the mark panel of the form
	 */
	public void loadMark()
	{
		if(cmbAssignments.getSelectedIndex() > 0)
		{
			for(Component c: jpSearch.getComponents())
				c.setEnabled(false);
			
			for(Component c: jpMark.getComponents())
				c.setEnabled(true);
			
			for(int i = 0; i < assignments.size(); i++)		
				if(assignments.get(i).getAssignmentCode().equals(cmbAssignments.getSelectedItem().toString().substring(0,7)))
				{
					lblCode.setText(assignments.get(i).getAssignmentCode());
					lblName.setText(assignments.get(i).getAssignmentName());
					lblDate.setText(assignments.get(i).getDateIssued());
					lblSummary.setText(assignments.get(i).getSummary());
					loadStudentsForAssignment();
				}
			
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose an assignment to mark.");
	}
	
	/**
	 * loads students in classes for the module
	 */
	public void loadStudentsForAssignment()
	{
		cmbStudents.removeAllItems();
		cmbStudents.addItem("...");
		for(int i = 0; i < classes.size(); i++)
		{
			if(classes.get(i).getModuleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
			{	
				String[] values = classes.get(i).getStudents().split(",");
				if(values != null)
				{
					loadStudents(values);
				}
			}
		}
	}
	
	/**
	 * loads students into a combo box
	 * @param stu
	 */
	public void loadStudents(String[] stu)
	{
		for(int i = 0; i < stu.length; i++)
			cmbStudents.addItem(students.get(stu[i]).getStudentCode() + ": " + students.get(stu[i]).getSurName() + ", " + students.get(stu[i]).getForName());
	}
	
	/**
	 * deletes a students result for an assignment, if they have one
	 */
	public void deleteResult()
	{
		if(cmbStudents.getSelectedIndex() > 0)
		{
			boolean hasResult = false;
			for(int i = 0; i < results.size(); i++)
			{
				if(results.get(i).getAssignmentCode().equals(lblCode.getText()) && results.get(i).getStudentCode().equals(cmbStudents.getSelectedItem().toString().substring(0,7)))
				{ 
					hasResult = true;
				}
			}
			
			
			if(!hasResult)
			{
				JOptionPane.showMessageDialog(container, "This student does not have a result");
			}
			else
			{
				int dialogButton = JOptionPane.YES_NO_OPTION;
	            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to delete the result for:\n" + cmbStudents.getSelectedItem().toString() + " for this assignment?","Confirm delete.", dialogButton);
	            if(dialogResult == JOptionPane.YES_OPTION)
	            {
	            	int i = 0;
	            	while (results.size() > i) {
	            		if(results.get(i).getAssignmentCode().equals(lblCode.getText()) && results.get(i).getStudentCode().equals(cmbStudents.getSelectedItem().toString().substring(0,7)))
	    				{
	            			results.remove(i);
	    				}
	            		else
	            			i++;
	            	}
	            	JOptionPane.showMessageDialog(container, "Results deleted successfully!");
	            }
			}
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a student, to delete their result!");
	}

	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		for(Component c: jpSearch.getComponents())
			c.setEnabled(true);
		
		for(Component c: jpMark.getComponents())
			c.setEnabled(false);
		
		btnExit.setEnabled(true);
		cmbCourses.setSelectedIndex(0);
		lblCode.setText("ASSXXXX");
		lblName.setText("XXXXXXX");
		lblDate.setText("XX/XX/XXXX");
		lblSummary.setText("XXXXXXX");
		cmbStudents.removeAllItems();
	}

	/**
	 * validates add input and then adds a result for a student 
	 */
	public void addResult()
	{
		boolean val = true;
		double result = 0.0;
		String feedback = "";
		
		if(tfFeedback.getText().length() < 3)
		{
			JOptionPane.showMessageDialog(container, "Feedback must be more than 3 letters long.");
			val = false;
		}
		else
			feedback = tfFeedback.getText();
		
		try {
            result = Double.parseDouble(tfResult.getText());
            if(result > 100.0 || result < 0)
            {
            	JOptionPane.showMessageDialog(container, "Result must be between 0 - 100!");
            	val = false;
            }       
        } catch (NumberFormatException e) {
        	JOptionPane.showMessageDialog(container, "You must enter a number!");
        }
		
		if(cmbStudents.getSelectedIndex() == 0)
		{
			JOptionPane.showMessageDialog(container, "You must choose a student!");
			val = false;
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to add this mark\nWarning this will overwrite any previous mark?","Confirm mark.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {			
				boolean hasResult = false;
				for(int i = 0; i < results.size(); i++)
				{
					if(results.get(i).getAssignmentCode().equals(lblCode.getText()) && results.get(i).getStudentCode().equals(cmbStudents.getSelectedItem().toString().substring(0,7)))
					{ 
						hasResult = true;
						results.get(i).setResult(result);
						results.get(i).setFeedback(feedback);
					}
				}
				if(!hasResult)
				{
					Results r1 = new Results(lblCode.getText(), cmbStudents.getSelectedItem().toString().substring(0,7), result, feedback);
					results.add(r1);
				}
				JOptionPane.showMessageDialog(container, "Result added successfully!");
				cmbStudents.setSelectedIndex(0);
				tfResult.setText("");
				tfFeedback.setText("");
            }
		}
	}
}
