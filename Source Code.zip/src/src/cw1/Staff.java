package cw1;

import java.io.Serializable;

public class Staff implements Serializable{

	private String title;
	private String forname;
	private String surname;
	private String position;
	private String officeLocation;
	private String expertise;
	private String employmentStatus;
	
	/**
	 * constructor which takes in all information 
	 * @param title
	 * @param forName
	 * @param surname
	 * @param position
	 * @param officeLocation
	 * @param expertise
	 * @param employmentStatus
	 */
	public Staff(String title, String forName, String surname, String position, String officeLocation, String expertise, String employmentStatus) 
	{
		this.title = title;
		this.forname = forName;
		this.surname = surname;
		this.position = position;
		this.officeLocation = officeLocation;
		this.expertise = expertise;
		this.employmentStatus = employmentStatus;
	}
	
	/**
	 * blank constructor
	 */
	public Staff() 
	{
		this.title = "";
		this.forname = "";
		this.surname = "";
		this.position = "";
		this.officeLocation = "";
		this.expertise = "";
		this.employmentStatus = "";
	}

	/**
	 * returns title
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * sets title from string input
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * returns forname
	 * @return
	 */
	public String getForname() {
		return forname;
	}

	/**
	 * sets forname from string input
	 * @param forname
	 */
	public void setForname(String forname) {
		this.forname = forname;
	}

	/**
	 * returns surname
	 * @return
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * sets surname from string input
	 * @param surname
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * returns position
	 * @return
	 */
	public String getPosition() {
		return position;
	}

	/**
	 * sets position from string input
	 * @param position
	 */
	public void setPosition(String position) {
		this.position = position;
	}

	/**
	 * returns office location
	 * @return
	 */
	public String getOfficeLocation() {
		return officeLocation;
	}

	/**
	 * sets office location from string input
	 * @param officeLocation
	 */
	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}

	/**
	 * returns expertise
	 * @return
	 */
	public String getExpertise() {
		return expertise;
	}

	/**
	 * sets expertise from string input
	 * @param expertise
	 */
	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}

	/**
	 * gets employment status
	 * @return
	 */
	public String getEmploymentStatus() {
		return employmentStatus;
	}

	/**
	 * sets employment status from string input
	 * @param employmentStatus
	 */
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	
	
	
}
