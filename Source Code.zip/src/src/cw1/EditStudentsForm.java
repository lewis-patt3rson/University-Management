package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class EditStudentsForm extends JDialog implements ActionListener{

	private Container container;
	private JLabel lblHeader, lblStudentCode, lblStudentForname,lblStudentSurname, lblDisabiltiy, lblPreferredName, lblGender, lblStudentCodeAutoFill, lblMessage ;
	private JTextField tfForname, tfSurname, tfDisability, tfPreferredName;
	private JComboBox cmbGender, cmbStudents;
	private JButton btnExit, btnReset, btnConfirmEdit, btnEdit, btnDelete;
	private JPanel jpSearchStudent, jpEditStudent;
	HashMap<String,Student> students = new HashMap<String,Student>();
	LinkedList<Results> results = new LinkedList<Results>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	/**
	 * loads in the relevant maps and list for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param studentMap
	 * @param resultList
	 * @param classList
	 */
	public EditStudentsForm(HashMap studentMap, LinkedList resultList, LinkedList classList)
	{
		students = studentMap;
		results = resultList;
		classes = classList;
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearchStudent = new JPanel();
		jpSearchStudent.setLayout(new GridBagLayout());
		jpSearchStudent.setBackground(new Color(250,128,114));
		
		jpEditStudent = new JPanel();
		jpEditStudent.setLayout(new GridBagLayout());
		jpEditStudent.setBackground(new Color(250,128,114));
		
		
		tfForname = new JTextField();
		tfSurname = new JTextField();
		tfDisability = new JTextField();
		tfPreferredName = new JTextField();
		
		
		
		
		lblHeader = new JLabel("Edit Students");
		lblMessage = new JLabel("Choose a student to edit:");
		lblStudentCode = new JLabel("Student Code:", JLabel.RIGHT);
		lblStudentCodeAutoFill = new JLabel("", JLabel.LEFT);
		lblStudentForname = new JLabel("Forname:", JLabel.RIGHT);
		lblStudentSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblDisabiltiy = new JLabel("Disability:", JLabel.RIGHT);
		lblPreferredName = new JLabel("Preferred Name:", JLabel.RIGHT);
		lblGender = new JLabel("Gender:", JLabel.RIGHT);
		
		String[] genders = new String[]{
				"...", "Male","Female","Other"
			};
		cmbGender = new JComboBox(genders);
		
		cmbStudents = new JComboBox();
		
		btnEdit = new JButton("Edit");
		btnDelete = new JButton("Delete");
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnConfirmEdit = new JButton("Edit Student");
		
		loadStudents();
		
		addComp(container, jpSearchStudent, 0,0,1,1,1,1);
		addComp(container, jpEditStudent, 0,1,1,1,1,1);
		
		addComp(jpSearchStudent, lblHeader, 0,0,3,1,1,1);
		addComp(jpSearchStudent, lblMessage, 0,1,1,1,1,1);
		addComp(jpSearchStudent, cmbStudents, 0,2,2,1,1,1);
		addComp(jpSearchStudent, btnEdit, 2,1,1,1,1,1);
		addComp(jpSearchStudent, btnDelete, 2,2,2,1,1,1);
		
		addComp(jpEditStudent,lblStudentCode,0,1,1,1,1,1);
		addComp(jpEditStudent,lblStudentCodeAutoFill,1,1,1,1,1,1);
		addComp(jpEditStudent,lblStudentForname,0,2,1,1,1,1);
		addComp(jpEditStudent,tfForname,1,2,2,1,1,1);
		addComp(jpEditStudent,lblStudentSurname,0,3,1,1,1,1);
		addComp(jpEditStudent,tfSurname,1,3,2,1,1,1);
		addComp(jpEditStudent,lblDisabiltiy,0,4,1,1,1,1);
		addComp(jpEditStudent,tfDisability,1,4,2,1,1,1);
		addComp(jpEditStudent,lblPreferredName,0,5,1,1,1,1);
		addComp(jpEditStudent,tfPreferredName,1,5,2,1,1,1);
		addComp(jpEditStudent,lblGender,0,6,1,1,1,1);
		addComp(jpEditStudent,cmbGender,1,6,1,1,1,1);
		addComp(jpEditStudent,btnExit,0,7,1,1,1,1);
		addComp(jpEditStudent,btnReset,1,7,1,1,1,1);
		addComp(jpEditStudent,btnConfirmEdit,2,7,1,1,1,1);
		
		for(Component c: jpEditStudent.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
		
		btnEdit.addActionListener(this);
		btnDelete.addActionListener(this);
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnConfirmEdit.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from buttons 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnEdit)
		{
			if(cmbStudents.getSelectedIndex() < 1)
			{
				JOptionPane.showMessageDialog(container, "You must choose a student to edit.");
			}
			else {
				loadEdit();
			}
		}
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to reset?","Confirm reset.", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	resetForm();
	        }
		}
		else if(e.getSource() == btnDelete)
		{
			delete();
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to exit?","Confirm exit.", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	dispose();
	        }
		}
		else if(e.getSource() == btnConfirmEdit)
		{
			edit();
		}
	}

	/**
	 * loads all students into the combo box
	 */
	public void loadStudents()
	{
		cmbStudents.removeAllItems();
		cmbStudents.addItem("...");
		Iterator it = students.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			cmbStudents.addItem(students.get(me.getKey()).getStudentCode() + ": " + students.get(me.getKey()).getForName().toString() + ", " +students.get(me.getKey()).getSurName().toString());
		}
	}
	
	/**
	 * loads the edit panel
	 */
	public void loadEdit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to edit: " + cmbStudents.getSelectedItem().toString() + "?","Confirm edit.", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	for(Component c: jpSearchStudent.getComponents())
    			c.setEnabled(false);
    		
    		for(Component c: jpEditStudent.getComponents())
    			c.setEnabled(true);
    		
    		Student loadS = new Student();
    		loadS = students.get(cmbStudents.getSelectedItem().toString().substring(0, 7));
    		lblStudentCodeAutoFill.setText(loadS.getStudentCode());
    		tfForname.setText(loadS.getForName());
    		tfSurname.setText(loadS.getSurName());
    		tfDisability.setText(loadS.getDisability());
    		tfPreferredName.setText(loadS.getPreferredName());
    		
    		switch(loadS.getGender())
    		{
    		case "Male": cmbGender.setSelectedIndex(1);break;
    		case "Female": cmbGender.setSelectedIndex(2);break;
    		case "Other": cmbGender.setSelectedIndex(3);break;
    		default: break;
    		}
        }
		
		
		
		
	}

	/**
	 * confirms delete and then deletes
	 */
	public void delete()
	{
		if(cmbStudents.getSelectedIndex() > 0)
		{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to delete: " + cmbStudents.getSelectedItem().toString() + "\nWarning: This will delete all results for this student?","Confirm delete.", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	deleteResults();
        	deleteStudentFromClasses();
        	students.remove(cmbStudents.getSelectedItem().toString().substring(0,7));
        	JOptionPane.showMessageDialog(container, "Student and student's results deleted successfully!");
        	int dialogButton2 = JOptionPane.YES_NO_OPTION;
            int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another student?","Edit/delete another", dialogButton2);
            if(dialogResult2 == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
            else
            {
            	dispose();
            }
        }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a student to delete.");
	}
	
	/**
	 * deletes all results
	 */
	public void deleteResults()
	{
		 int i = 0;
	      while (results.size() > i) {
	    	  if(results.get(i).getStudentCode().equals(cmbStudents.getSelectedItem().toString().substring(0,7)))
	    		  results.remove(i);
	    	  else
	    		  i++;
	      }
	
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		lblStudentCodeAutoFill.setText("STUXXXX");
		tfForname.setText("");
		tfSurname.setText("");
		tfDisability.setText("");
		tfPreferredName.setText("");
		cmbGender.setSelectedIndex(0);
		for(Component c: jpSearchStudent.getComponents())
			c.setEnabled(true);
		
		for(Component c: jpEditStudent.getComponents())
			c.setEnabled(false);
		cmbStudents.setSelectedIndex(0);
		btnExit.setEnabled(true);
	}

	/**
	 * validates input for edit and then edits
	 */
	public void edit()
	{
		boolean val = true;
		String forName = "", surName = "", disability = "", gender = "", preferredName = "";
		
		if(tfForname.getText().toString().length() < 3)
		{
			JOptionPane.showMessageDialog(container, "Student forname must be atleast 3 letters long.");
			val = false;
		}
		else
		{
			forName = tfForname.getText();
		}
		
		if(tfSurname.getText().toString().length() <= 3)
		{
			JOptionPane.showMessageDialog(container, "Student surname must be more than 3 letters long.");
			val = false;
		}
		else
		{
			surName = tfSurname.getText();
		}
		
		if(tfDisability.getText().toString().length() <= 3)
		{
			JOptionPane.showMessageDialog(container, "Disability must be more than 3 letters long.");
			val = false;
		}
		else
		{
			disability = tfDisability.getText();
		}
		
		if(tfPreferredName.getText().toString().length() < 3)
		{
			JOptionPane.showMessageDialog(container, "Student's preferred name must be atleast 3 letters long.");
			val = false;
		}
		else
		{
			preferredName = tfPreferredName.getText();
		}
		
		if(cmbGender.getSelectedIndex() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a gender.");
			val = false;
		}
		else
		{
			switch(cmbGender.getSelectedIndex())
			{
			case 1: gender = "Male"; break;
			case 2: gender = "Female"; break;
			case 3: gender = "Other"; break;
			default: break;
			}
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit: "+ tfForname.getText().toString() + ", "+ tfSurname.getText().toString() +" ?","Confirm New Student", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	String id = lblStudentCodeAutoFill.getText();
            	students.get(id).setForName(forName);
            	students.get(id).setSurName(surName);
            	students.get(id).setDisability(disability);
            	students.get(id).setPreferredName(preferredName);
            	students.get(id).setGender(gender);
            	JOptionPane.showMessageDialog(container, "Student edited successfully!");
            	
            	int dialogButton2 = JOptionPane.YES_NO_OPTION;
                int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to edit/delete another student?","Edit/delete another", dialogButton2);
                if(dialogResult2 == JOptionPane.YES_OPTION)
                {
                	resetForm();
                }
                else
                {
                	dispose();
                }
            }
		}
	}

	/**
	 * removes student from classes
	 */
	public void deleteStudentFromClasses()
	{
		for(int i = 0; i < classes.size(); i++)
			classes.get(i).removeStudent(cmbStudents.getSelectedItem().toString().substring(0,7));
		
	}
}
