package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.Map.Entry;

import javax.swing.*;

import cw1.Module;

public class EditStaffForm extends JDialog implements ActionListener {

	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	LinkedList<Module> modules = new LinkedList<Module>();
	
	Container container;
	private JPanel jpSearchStaff, jpStaffDetails;
	private JButton btnTutor, btnAcademic, btnEdit, btnDelete, btnExit, btnCancel, btnConfirmEdit;
	private JLabel lblHeader, lblMessage, lblForname, lblSurname, lblPosition, lblOfficeLocation, lblExpertise, lblEmploymentStatus, lblType, lblTitle;;
	private JComboBox cmbStaff, cmbEmploymentType, cmbTitle;
	private JTextField tfForname, tfSurname, tfPosition, tfOfficeLocation, tfExpertise;
	
	/**
	 * loads in the relevant list for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param tutorMap
	 * @param academicMap
	 * @param moduleList
	 */
	public EditStaffForm(HashMap tutorMap, HashMap academicMap, LinkedList moduleList)
	{
		tutors = tutorMap;
		academics = academicMap;
		modules = moduleList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearchStaff = new JPanel();
		jpSearchStaff.setLayout(new GridBagLayout());
		jpSearchStaff.setBackground(new Color(250,128,114));
		
		jpStaffDetails = new JPanel();
		jpStaffDetails.setLayout(new GridBagLayout());
		jpStaffDetails.setBackground(new Color(250,128,114));
		
		btnTutor = new JButton("Tutor");
		btnAcademic = new JButton("Academic");
		btnEdit = new JButton("Edit");
		btnDelete = new JButton("Delete");
		
		lblHeader = new JLabel("Edit Staff Member", JLabel.CENTER);
		lblMessage = new JLabel("Choose a type of staff member to edit:");
		
		cmbStaff = new JComboBox();
		
		addComp(jpSearchStaff, lblHeader,0,0,3,1,1,1);
		addComp(jpSearchStaff, lblMessage,0,1,3,1,1,1);
		addComp(jpSearchStaff, btnTutor,0,2,1,1,0,0);
		addComp(jpSearchStaff, btnAcademic,0,3,1,1,0,0);
		addComp(jpSearchStaff, cmbStaff,1,2,1,2,1,1);
		addComp(jpSearchStaff, btnEdit,2,2,1,1,1,1);
		addComp(jpSearchStaff, btnDelete,2,3,1,1,1,1);
		
		addComp(container, jpSearchStaff,0,0,1,1,1,1);
		addComp(container, jpStaffDetails,0,1,1,1,1,1);
		
		//Edit Panel
		lblForname = new JLabel("Forname:", JLabel.RIGHT);
		lblSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblPosition = new JLabel("Position:", JLabel.RIGHT);
		lblOfficeLocation = new JLabel("Office Location:", JLabel.RIGHT);
		lblExpertise = new JLabel("Expertise:", JLabel.RIGHT);
		lblEmploymentStatus = new JLabel("Employment Status:", JLabel.RIGHT);
		lblType = new JLabel("Type:", JLabel.RIGHT);
		lblHeader = new JLabel("Staff Member XXXXXXX Details:", JLabel.CENTER);
		lblTitle = new JLabel("Title:", JLabel.RIGHT);
		
		String[] employmentTypes = new String[]{
			"...","Full-Time","Part-Time"
		};
		String[] titles = new String[]{
				"...", "Dr", "Mr", "Mrs", "Miss", "Ms"
		};
		
		cmbEmploymentType = new JComboBox(employmentTypes);
		cmbTitle = new JComboBox(titles);
		
		tfForname = new JTextField();
		tfSurname = new JTextField();
		tfPosition = new JTextField();
		tfOfficeLocation = new JTextField();
		tfExpertise = new JTextField();

		btnExit = new JButton("Exit");
		btnCancel = new JButton("Cancel");
		btnConfirmEdit = new JButton("Save Edit");
		
		addComp(jpStaffDetails,lblHeader,0,0,3,1,1,1);
		addComp(jpStaffDetails,lblTitle,0,1,1,1,1,1);
		addComp(jpStaffDetails,cmbTitle,1,1,1,1,1,1);
		addComp(jpStaffDetails,lblForname,0,2,1,1,1,1);
		addComp(jpStaffDetails,tfForname,1,2,2,1,1,1);
		addComp(jpStaffDetails,lblSurname,0,3,1,1,1,1);
		addComp(jpStaffDetails,tfSurname,1,3,2,1,1,1);
		addComp(jpStaffDetails,lblPosition,0,4,1,1,1,1);
		addComp(jpStaffDetails,tfPosition,1,4,2,1,1,1);
		addComp(jpStaffDetails,lblOfficeLocation,0,5,1,1,1,1);
		addComp(jpStaffDetails,tfOfficeLocation,1,5,2,1,1,1);
		addComp(jpStaffDetails,lblExpertise,0,6,1,1,1,1);
		addComp(jpStaffDetails,tfExpertise,1,6,2,1,1,1);
		addComp(jpStaffDetails,lblEmploymentStatus,0,7,1,1,1,1);
		addComp(jpStaffDetails,cmbEmploymentType,1,7,2,1,1,1);
		addComp(jpStaffDetails,btnExit,0,8,1,1,1,1);
		addComp(jpStaffDetails,btnCancel,1,8,1,1,1,1);
		addComp(jpStaffDetails,btnConfirmEdit,2,8,1,1,1,1);
		
		for(Component c: jpStaffDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
		
		btnExit.addActionListener(this);
		btnCancel.addActionListener(this);
		btnConfirmEdit.addActionListener(this);
		btnTutor.addActionListener(this);
		btnAcademic.addActionListener(this);
		btnEdit.addActionListener(this);
		btnDelete.addActionListener(this);
		cmbStaff.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }

	/**
	 * loads events from button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnTutor)
		{
			fillTutors();
		}
		else if(e.getSource() == btnAcademic)
		{
			fillAcademics();
		}
		else if(e.getSource() == btnEdit)
		{
			if(cmbStaff.getSelectedIndex() >= 1)
			{
				int dialogButton = JOptionPane.YES_NO_OPTION;
	            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit: "+ cmbStaff.getSelectedItem().toString()+"?","Confirm Edit", dialogButton);
	            if(dialogResult == JOptionPane.YES_OPTION)
	            {
	            	loadEdit();
	            }
			}
			else {
				JOptionPane.showMessageDialog(container, "You must choose a staff member to edit.");
			}
		}
		else if(e.getSource() == btnDelete)
		{
			if(cmbStaff.getSelectedIndex() >= 1)
			{
				if(delete()) 
				{
					int dialogButton = JOptionPane.YES_NO_OPTION;
		            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to delete: "+ cmbStaff.getSelectedItem().toString()+"?","Confirm Delete", dialogButton);
		            if(dialogResult == JOptionPane.YES_OPTION)
		            {
		            	if(cmbStaff.getSelectedItem().toString().substring(0,3).equals("TUT"))
						{
							tutors.remove(cmbStaff.getSelectedItem().toString().substring(0,7));
							JOptionPane.showMessageDialog(container, "Successfully Deleted!");
						}
						else
						{
							academics.remove(cmbStaff.getSelectedItem().toString().substring(0,7));
							JOptionPane.showMessageDialog(container, "Successfully Deleted!"); 
						}
		            }
					
				}
				else 
				{
					JOptionPane.showMessageDialog(container, "You can not delete this member as they are\n a leader of a moderator of a module.");
				}
			}
			else 
			{
				JOptionPane.showMessageDialog(container, "You must choose a staff member to edit.");
			}
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm Exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnCancel)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm Reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnConfirmEdit)
		{
			editStaff();
		}
	}
	
	/**
	 * loads all tutors
	 */
	public void fillTutors()
	{
		cmbStaff.removeAllItems();
		cmbStaff.addItem("...");
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			cmbStaff.addItem(tutors.get(me.getKey()).getTutorCode().toString() + ": " + tutors.get(me.getKey()).getForname().toString() + ", " +tutors.get(me.getKey()).getSurname().toString());
		}
	}

	/**
	 * loads all academics
	 */
	public void fillAcademics()
	{
		cmbStaff.removeAllItems();
		cmbStaff.addItem("...");
		Iterator it = academics.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			cmbStaff.addItem(academics.get(me.getKey()).getAcademicCode().toString() + ": " + academics.get(me.getKey()).getForname().toString() + ", " +academics.get(me.getKey()).getSurname().toString());
		}
	}
	
	/**
	 * loads the edit panel
	 */
	public void loadEdit()
	{
		for(Component c: jpSearchStaff.getComponents())
			c.setEnabled(false);
		
		for(Component c: jpStaffDetails.getComponents())
			c.setEnabled(true);
		
		
		lblHeader.setText("Staff Member " + cmbStaff.getSelectedItem().toString().substring(0, 7) + " Details:");
		
		if(cmbStaff.getSelectedItem().toString().substring(0,3).equals("TUT"))
		{
			Tutor editT = new Tutor();
			editT = tutors.get(cmbStaff.getSelectedItem().toString().substring(0, 7));
			tfForname.setText(editT.getForname());
			tfSurname.setText(editT.getSurname());
			tfPosition.setText(editT.getPosition());
			tfOfficeLocation.setText(editT.getOfficeLocation());
			tfExpertise.setText(editT.getExpertise());
			
			switch(editT.getTitle()) {
			case "Dr":
				cmbTitle.setSelectedIndex(1); break;
			case "Mr":
				cmbTitle.setSelectedIndex(2); break;
			case "Mrs":
				cmbTitle.setSelectedIndex(3); break;
			case "Miss":
				cmbTitle.setSelectedIndex(4); break;
			case "Ms":
				cmbTitle.setSelectedIndex(5); break;
				default: cmbTitle.setSelectedIndex(0); break;
			}
			
			switch(editT.getEmploymentStatus()) {
			case "Full-Time":
				cmbEmploymentType.setSelectedIndex(1); break;
			case "Part-Time":
				cmbEmploymentType.setSelectedIndex(2); break;
				default: cmbEmploymentType.setSelectedIndex(0);
			}
			
			
		}
		else {
			Academic editA = new Academic();
			editA = academics.get(cmbStaff.getSelectedItem().toString().substring(0, 7));
			tfForname.setText(editA.getForname());
			tfSurname.setText(editA.getSurname());
			tfPosition.setText(editA.getPosition());
			tfOfficeLocation.setText(editA.getOfficeLocation());
			tfExpertise.setText(editA.getExpertise());
			
			switch(editA.getTitle()) {
			case "Dr":
				cmbTitle.setSelectedIndex(1); break;
			case "Mr":
				cmbTitle.setSelectedIndex(2); break;
			case "Mrs":
				cmbTitle.setSelectedIndex(3); break;
			case "Miss":
				cmbTitle.setSelectedIndex(4); break;
			case "Ms":
				cmbTitle.setSelectedIndex(5); break;
				default: cmbTitle.setSelectedIndex(0); break;
			}
			
			switch(editA.getEmploymentStatus()) {
			case "Full-Time":
				cmbEmploymentType.setSelectedIndex(1); break;
			case "Part-Time":
				cmbEmploymentType.setSelectedIndex(2); break;
				default: cmbEmploymentType.setSelectedIndex(0);
			}
			
			
		}
	
	}

	/**
	 * makes sure a the staff member is not a leader or moderator to delete
	 * @return
	 */
	public boolean delete()
	{
		boolean val = true;
		
		if(cmbStaff.getSelectedItem().toString().substring(0,3).equals("TUT"))
		{
			for(int i = 0; i < modules.size(); i++) 
			{
				if(modules.get(i).getModuleLeader().toString().equals(cmbStaff.getSelectedItem().toString().substring(0,7))) 
				{
					val = false;
				}
			}
		}
		else
		{
			for(int i = 0; i < modules.size(); i++) 
			{
				if(modules.get(i).getModuleModerator().toString().equals(cmbStaff.getSelectedItem().toString().substring(0,7))) 
				{
					val = false;
				}
			}

		}
		
		return val;
	}

	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		cmbTitle.setSelectedIndex(0);
		cmbStaff.removeAllItems();
		cmbEmploymentType.setSelectedIndex(0);
		tfForname.setText("");
		tfSurname.setText("");
		tfPosition.setText("");
		tfOfficeLocation.setText("");
		tfExpertise.setText("");
		lblHeader.setText("Staff Member XXXXXXX Details:");
		for(Component c: jpStaffDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(false);
		for(Component c: jpSearchStaff.getComponents())
			c.setEnabled(true);
	}

	/**
	 * makes sure all input is valid and if so edits the information
	 */
	public void editStaff()
	{
		Boolean val = true;
		
		String forname = "", surname = "", position = "", officeLocation = "", expertise = "", employmentType = "", title = "";
		
		//Forname
		if(tfForname.getText().length() >= 3)
		{
			forname = tfForname.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Fornames must be more than 3 letters long.");
			val = false;
		}
		
		//Surname
		if(tfSurname.getText().length() >= 3)
		{
			surname = tfSurname.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Surnames must be more than 3 letters long.");
			val = false;
		}
		
		//Position
		if(tfPosition.getText().length() >= 3)
		{
			position = tfPosition.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Position must be more than 3 letters long.");
			val = false;
		}
		
		//Office Location
		if(tfOfficeLocation.getText().length() >= 3)
		{
			officeLocation = tfOfficeLocation.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Office location must be more than 3 letters long.");
			val = false;
		}
		
		//Expertise
		if(tfExpertise.getText().length() >= 3)
		{
			expertise = tfExpertise.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Expertise must be more than 3 letters long.");
			val = false;
		}
		
		//Employment Type
		if(cmbEmploymentType.getSelectedIndex() >= 1)
		{
			employmentType = cmbEmploymentType.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose an employment type.");
			val = false;
		}
		
		
		//Title
		if(cmbTitle.getSelectedIndex() >= 1)
		{
			title = cmbTitle.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a title.");
			val = false;
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit: " + cmbStaff.getSelectedItem().toString() +"?","Confirm Exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	if(cmbStaff.getSelectedItem().toString().substring(0, 3).equals("TUT")) 
        		{
            		Tutor editT = new Tutor();
            		editT = tutors.get(cmbStaff.getSelectedItem().toString().substring(0, 7));
            		editT.setTitle(cmbTitle.getSelectedItem().toString());
        			editT.setForname(tfForname.getText());
        			editT.setSurname(tfSurname.getText());
        			editT.setPosition(tfPosition.getText());
        			editT.setOfficeLocation(tfOfficeLocation.getText());
        			editT.setExpertise(tfExpertise.getText());
        			editT.setEmploymentStatus(cmbEmploymentType.getSelectedItem().toString());
        			
        		}
            	else 
            	{
            		Academic editA = new Academic();
            		editA = academics.get(cmbStaff.getSelectedItem().toString().substring(0, 7));
            		editA.setTitle(cmbTitle.getSelectedItem().toString());
            		editA.setForname(tfForname.getText());
            		editA.setSurname(tfSurname.getText());
            		editA.setPosition(tfPosition.getText());
            		editA.setOfficeLocation(tfOfficeLocation.getText());
            		editA.setExpertise(tfExpertise.getText());
            		editA.setEmploymentStatus(cmbEmploymentType.getSelectedItem().toString());
            	}
            	JOptionPane.showMessageDialog(container, "Staff member successfully edited!");
            	dispose();
            }
		}
	}
}
