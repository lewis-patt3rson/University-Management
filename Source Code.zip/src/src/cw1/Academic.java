package cw1;

import java.io.Serializable;

public class Academic extends Staff implements Serializable{
	
	private String academicCode;
	
	/**
	 * blank constructor
	 */
	public Academic()
	{
		
	}
	
	/**
	 * Constructor which takes in all the detail for an academic
	 * @param academicCode
	 * @param academicTitle
	 * @param academicForname
	 * @param academicSurname
	 * @param position
	 * @param officeLocation
	 * @param expertise
	 * @param employmentStatus
	 */
	public Academic(String academicCode, String academicTitle, String academicForname, String academicSurname, String position, String officeLocation, String expertise, String employmentStatus)
	{
		super(academicTitle, academicForname, academicSurname, position, officeLocation, expertise, employmentStatus);
		this.academicCode = academicCode;
	}
	
	/**
	 * sets academic code from string input
	 * @param academicCode
	 */
	public void setAcademicCode(String academicCode)
	{
		this.academicCode = academicCode;
	}
	
	/**
	 * returns academic code
	 * @return
	 */
	public String getAcademicCode()
	{
		return this.academicCode;
	}
}
