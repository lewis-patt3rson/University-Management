package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;

import javax.swing.*;

public class CourseDetailsForm extends JDialog implements ActionListener {

	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private Container container;
	private JPanel jpSearchCourses, jpCourseDetails;
	private JLabel lblHeader, lblMessage, lblCourseCode, lblCode, lblCourseName, lblName, lblModules;
	private JComboBox cmbCourses;
	private JTextField tfSearch;
	private JButton btnReset, btnExit, btnModules;
	
	/**
	 * loads in the relevant lists for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param courseList
	 * @param moduleList
	 * @param classList
	 */
	CourseDetailsForm(LinkedList courseList, LinkedList moduleList, LinkedList classList)
	{
		courses = courseList;
		modules = moduleList;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearchCourses = new JPanel();
		jpSearchCourses.setLayout(new GridBagLayout());
		jpSearchCourses.setBackground(new Color(250,128,114));
		
		jpCourseDetails = new JPanel();
		jpCourseDetails.setLayout(new GridBagLayout());
		jpCourseDetails.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Course Details");
		lblMessage = new JLabel("Search for a course:");
		lblCourseCode = new JLabel("Course code:");
		lblCode = new JLabel("COUXXXX");
		lblCourseName = new JLabel("Course name:");
		lblName = new JLabel("xxxxxxx");
		lblModules = new JLabel("Modules:");
		
		
		tfSearch = new JTextField();
		KeyListener keyListener = new KeyListener() {
		     public void keyPressed(KeyEvent keyEvent) {
		     }
		     public void keyReleased(KeyEvent keyEvent) {
		      loadCourses();
		     }
		     public void keyTyped(KeyEvent keyEvent) {    
		      }};
		tfSearch.addKeyListener(keyListener);
		cmbCourses = new JComboBox();
		
		btnReset = new JButton("Reset Search");
		btnExit = new JButton("Exit");
		btnModules = new JButton("Module Information");
		
		
		cmbCourses.addActionListener(this);
		btnReset.addActionListener(this);
		btnExit.addActionListener(this);
		btnModules.addActionListener(this);
		
		addComp(container, jpSearchCourses, 0,0,1,1,1,1);
		addComp(container, jpCourseDetails, 0,1,1,1,1,1);
		
		addComp(jpSearchCourses, lblHeader,0,0,1,1,0,0);
		addComp(jpSearchCourses, lblMessage,0,1,1,1,0,0);
		addComp(jpSearchCourses, tfSearch,0,2,1,1,0,0);
		addComp(jpSearchCourses, btnReset,1,2,1,1,0,0);
		addComp(jpSearchCourses, cmbCourses,0,3,1,1,0,0);
		
		
		addComp(jpCourseDetails, lblCourseCode,0,0,1,1,1,1);
		addComp(jpCourseDetails, lblCode,1,0,1,1,1,1);
		addComp(jpCourseDetails, lblCourseName,0,1,1,1,1,1);
		addComp(jpCourseDetails, lblName,1,1,1,1,1,1);
		addComp(jpCourseDetails, lblModules,0,2,1,1,1,1);
		addComp(jpCourseDetails, btnModules,1,2,1,1,1,1);
		addComp(jpCourseDetails, btnExit,1,3,1,1,1,1);
		
		
		loadCourses();
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from buttons and combo boxes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnReset)
		{
			tfSearch.setText("");
			lblCode.setText("COUXXXX");
			lblName.setText("xxxxxxx");
			loadCourses();
		}
		else if(e.getSource() == cmbCourses)
		{
			loadDetails();
		}
		else if(e.getSource() == btnExit)
		{
			dispose();
		}
		else if(e.getSource() == btnModules)
		{
			if(cmbCourses.getSelectedIndex() > 0)
			{
				CourseModulesForm cmF = new CourseModulesForm(cmbCourses.getSelectedItem().toString().substring(0,7), courses, modules, classes);
				cmF.setSize(400,400);
				cmF.setModal(true);
				cmF.setVisible(true);
			}
			else
				JOptionPane.showMessageDialog(container, "You must choose a course to view modules");
		}
	}

	/**
	 * loads courses into combo box if they match what is searched
	 * e.g. Computer science and computing would load in if 'Comput' was in the search bar
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i = 0; i < courses.size(); i++)
			try {
			if(tfSearch.getText().toString().toUpperCase().equals(courses.get(i).getCourseCode().substring(0, tfSearch.getText().length())) || tfSearch.getText().toString().toUpperCase().equals(courses.get(i).getCourseName().substring(0, tfSearch.getText().length()).toUpperCase()))
				cmbCourses.addItem(courses.get(i).getCourseCode() + ": " + courses.get(i).getCourseName());
			}
			catch(StringIndexOutOfBoundsException e){}
		if(cmbCourses.getItemCount() > 1 && tfSearch.getText().length() >= 1)		
			cmbCourses.setSelectedIndex(1);
		else
		{
			lblCode.setText("COUXXXX");
			lblName.setText("XXXXXXX");
		}
	}
	
	/**
	 * loads the highlighted courses details into the labels
	 */
	public void loadDetails()
	{
		if(cmbCourses.getSelectedIndex() > 0)
		{
			lblCode.setText(cmbCourses.getSelectedItem().toString().substring(0,7));
			lblName.setText(cmbCourses.getSelectedItem().toString().substring(9));
		}
		
	}
	
	
	
}
