package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.Map.Entry;

import javax.swing.*;

import cw1.Class;
import cw1.Module;

public class EditModuleForm extends JDialog implements ActionListener {
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	LinkedList<Class> classes = new LinkedList<Class>();
	LinkedList<Results> results = new LinkedList<Results>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	
	

	private Container container;
	private JLabel lblHeader, lblModuleCode, lblModuleName, lblCourse, lblModuleLeader, lblModuleModerator, lblModuleCodeAutoFill, lblChooseCourse, lblChooseModule;
	private JTextField tfName;
	private JPanel jpSearchModule, jpModuleDetails;
	private JComboBox cmbCourses,cmbEditCourses, cmbTutors, cmbAcademics, cmbModules;
	private JButton btnEdit, btnDelete, btnExit, btnCancel, btnEditModule;
	
	/**
	 * loads in the relevant lists and maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param CourseList
	 * @param ModuleList
	 * @param classList
	 * @param tutorMap
	 * @param academicMap
	 * @param resultList
	 * @param assignmentList
	 */
	EditModuleForm(LinkedList CourseList, LinkedList ModuleList, LinkedList classList, HashMap tutorMap, HashMap academicMap, LinkedList resultList, LinkedList assignmentList)
	{
		//Declaring lists
		courses = CourseList;
		modules = ModuleList;
		tutors = tutorMap;
		academics = academicMap;
		classes = classList;
		results = resultList;
		assignments = assignmentList;
		
		///Background/Window
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		//Filling Combo boxes
		cmbCourses = new JComboBox();
		cmbTutors = new JComboBox();
		cmbAcademics = new JComboBox();
		cmbModules = new JComboBox();
		cmbEditCourses = new JComboBox();
		loadEditCourses();
		loadCourses();
		loadTutors();
		loadAcademics();
		
		//Labels
		lblHeader = new JLabel("Edit modules", JLabel.CENTER);
		lblModuleCode = new JLabel("Module Code:");
		lblModuleName = new JLabel("Name:");
		lblCourse = new JLabel("Course:");
		lblModuleLeader = new JLabel("Leader:");
		lblModuleModerator = new JLabel("Moderator:");
		lblModuleCodeAutoFill = new JLabel("MODXXXX");
		lblChooseCourse = new JLabel("Choose a course:");
		lblChooseModule = new JLabel("Choose a module:");
		
		//Buttons
		btnEdit = new JButton("Edit");
		btnDelete = new JButton("Delete");
		btnExit = new JButton("Exit");
		btnCancel = new JButton("Cancel Edit");
		btnEditModule = new JButton("Save Edit");
		
		
		//Text fields
		tfName = new JTextField();
		
		//Panels
		jpSearchModule = new JPanel();
		jpSearchModule.setLayout(new GridBagLayout());
		jpSearchModule.setBackground(new Color(250,128,114));
		jpModuleDetails = new JPanel();
		jpModuleDetails.setLayout(new GridBagLayout());
		jpModuleDetails.setBackground(new Color(250,128,114));
 
		
		
		//Adding to GUI
		addComp(container, jpSearchModule, 0,0,1,1,1,1);
		addComp(container, jpModuleDetails, 0,1,1,4,1,1);
		
		//Adding to search panel
		addComp(jpSearchModule, lblHeader,0,0,3,1,1,1);
		addComp(jpSearchModule, lblChooseCourse,0,1,1,1,1,1);
		addComp(jpSearchModule, cmbCourses,0,2,1,1,1,1);
		addComp(jpSearchModule, lblChooseModule,1,1,1,1,1,1);
		addComp(jpSearchModule, cmbModules,1,2,1,1,1,1);
		addComp(jpSearchModule, btnEdit,2,1,1,1,1,1);
		addComp(jpSearchModule, btnDelete,2,2,1,1,1,1);
		
		//Adding to edit panel
		addComp(jpModuleDetails, lblModuleCode,0,0,1,1,1,1);
		addComp(jpModuleDetails, lblModuleCodeAutoFill,1,0,1,1,1,1);
		addComp(jpModuleDetails, lblModuleName,0,1,1,1,1,1);
		addComp(jpModuleDetails, tfName,1,1,2,1,1,1);
		addComp(jpModuleDetails, lblCourse,0,2,1,1,1,1);
		addComp(jpModuleDetails, cmbEditCourses,1,2,2,1,1,1);
		addComp(jpModuleDetails, lblModuleLeader,0,3,1,1,1,1);
		addComp(jpModuleDetails, cmbTutors,1,3,2,1,1,1);
		addComp(jpModuleDetails, lblModuleModerator,0,4,1,1,1,1);
		addComp(jpModuleDetails, cmbAcademics,1,4,2,1,1,1);
		addComp(jpModuleDetails, btnExit,0,5,1,1,1,1);
		addComp(jpModuleDetails, btnCancel,1,5,1,1,1,1);
		addComp(jpModuleDetails, btnEditModule,2,5,1,1,1,1);
		for(Component c: jpModuleDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
		cmbCourses.addActionListener(this);
		btnEdit.addActionListener(this);
		btnDelete.addActionListener(this);
		btnCancel.addActionListener(this);
		btnExit.addActionListener(this);
		btnEditModule.addActionListener(this);
		
		
	}

	/**
	 * loads events from buttons and combo boxes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
		{
			cmbModules.removeAllItems();
			if(cmbCourses.getSelectedIndex() >= 1)
			{
				loadModulesFromCourse(getCourseCode());
			}
		}
		else if(e.getSource() == btnEdit)
		{
			if(checkModulePicked()) {
				int dialogButton = JOptionPane.YES_NO_OPTION;
	            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to edit\n module: " + cmbModules.getSelectedItem().toString() +"?","Confirm Edit.", dialogButton);
	            if(dialogResult == JOptionPane.YES_OPTION)
	            {
	            	for(Component c:jpSearchModule.getComponents()) 
	            		c.setEnabled(false);       
	            	loadEdit();
	            }
			}
		}
		else if(e.getSource() == btnDelete)
		{
			delete();
		}
		else if(e.getSource() == btnCancel)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to cancel the edit?","Confirm Cancel.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetSearchPanel();
            	resetEditPanel();
            	for(Component c: jpSearchModule.getComponents())
            		c.setEnabled(true);
            }
		}
		else if(e.getSource() == btnEditModule)
		{
			confirmEdit();
		}
		else if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit.", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }

	/**
	 * loads all courses into combo box
	 */
	public void loadCourses()
	{
			cmbCourses.addItem("...");
		for(int i = 0; i < courses.size(); i++)
			cmbCourses.addItem(courses.get(i).getCourseName());
	}

	/**
	 * loads all tutors into combo box
	 */
	public void loadTutors()
	{
		cmbTutors.addItem("...");
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			String tutorName = tutors.get(me.getKey()).getSurname() + ", " + tutors.get(me.getKey()).getForname();
			cmbTutors.addItem(tutorName);
		}

	}
	
	/**
	 * loads all academics into combo box
	 */
	public void loadAcademics()
	{
		cmbAcademics.addItem("...");
		Iterator it = academics.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			String academicName = academics.get(me.getKey()).getSurname() + ", " + academics.get(me.getKey()).getForname();
			cmbAcademics.addItem(academicName);
		}

	}
	
	/**
	 * gets the course code from the course in the combo box
	 * @return
	 */
	public String getCourseCode()
	{
		String courseCode = "";
		for(int i = 0; i < courses.size(); i++)
		{
			if(courses.get(i).getCourseName() == cmbCourses.getSelectedItem())
			{
				courseCode = courses.get(i).getCourseCode();
				break;
			}
		}
		return courseCode;
	}

	/**
	 * loads modules for selected course into combo box
	 * @param CourseID
	 */
	public void loadModulesFromCourse(String CourseID)
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getCourseCode().equals(CourseID))
			{
				cmbModules.addItem(modules.get(i).getModuleName());
			}
		}
	}
	
	/**
	 * checks if a module is picked
	 * @return
	 */
	public boolean checkModulePicked()
	{
		boolean val = true;
		
		if(cmbModules.getItemCount() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a module.");
			val = false;
		}
		else if(cmbModules.getSelectedIndex() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a module.");
			val = false;
		}
		
		return val;
	}

	/**
	 * returns the module from its name
	 * @param moduleName
	 * @return
	 */
	public Module getModule(String moduleName)
	{
		Module moduleCode = new Module();
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getModuleName().equals(moduleName))
				moduleCode = modules.get(i);
		}
		return moduleCode;
	}
	
	/**
	 * returns the module code from its name
	 * @param moduleName
	 * @return
	 */
	public String getModuleCode(String moduleName)
	{
		String moduleCode = "";
		for(int i = 0; i < modules.size(); i++)
		{
			if(modules.get(i).getModuleName().equals(moduleName))
				moduleCode = modules.get(i).getModuleCode();
		}
		return moduleCode;
	}
	
	/**
	 * load the edit panel
	 */
	public void loadEdit()
	{
		String courseName = "";
		Module newMod = new Module();
		newMod = getModule(cmbModules.getSelectedItem().toString());
		
		for(Component c: jpModuleDetails.getComponents())
			c.setEnabled(true);
		
		lblModuleCodeAutoFill.setText(newMod.getModuleCode());
		tfName.setText(newMod.getModuleName());
		loadEditCourses();
		for(int i = 0; i < courses.size(); i ++)
		{
			if(courses.get(i).getCourseCode() == newMod.getCourseCode())
				courseName = courses.get(i).getCourseCode();
		}
		
		
	}
	
	/**
	 * resets search panel
	 */
	public void resetSearchPanel()
	{
		cmbCourses.removeAllItems();
		loadCourses();
		cmbModules.removeAllItems();
	}

	/**
	 * loads courses into the edit combo box
	 */
	public void loadEditCourses()
	{
			cmbEditCourses.removeAllItems();
			cmbEditCourses.addItem("...");
		for(int i = 0; i < courses.size(); i++)
			cmbEditCourses.addItem(courses.get(i).getCourseName());
	}

	/**
	 * resets the edit panel as if it was opened
	 */
	public void resetEditPanel()
	{
		lblModuleCodeAutoFill.setText("MODXXXX");
		tfName.setText("");
		cmbEditCourses.removeAllItems();
		cmbTutors.removeAllItems();
		cmbAcademics.removeAllItems();
		for(Component c: jpModuleDetails.getComponents())
			c.setEnabled(false);
		btnExit.setEnabled(true);
	}

	
	/**
	 * finds the tutor code from the name
	 * @param id
	 * @return
	 */
	public String findTutorID(String id)
	{

		String forName = "", surName = "";
		surName = id.substring( 0, id.indexOf(","));
		forName = id.substring(id.indexOf(",") + 2);
		String tutorCode = "";
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(tutors.get(me.getKey()).getForname().equals(forName) && tutors.get(me.getKey()).getSurname().equals(surName))
			{
				tutorCode = tutors.get(me.getKey()).getTutorCode();
				break;
			}
		}
		
		
		return tutorCode;
	}
	
	/**
	 * finds the academic code from the id
	 * @param id
	 * @return
	 */
	public String findAcademicID(String id)
	{
		String forName = "", surName = "";
		surName = id.substring( 0, id.indexOf(","));
		forName = id.substring(id.indexOf(",") + 2);
		String academicCode = "";
		Iterator it = academics.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(academics.get(me.getKey()).getForname().equals(forName) && academics.get(me.getKey()).getSurname().equals(surName))
			{
				academicCode = academics.get(me.getKey()).getAcademicCode();
				break;
			}
		}
		
		
		return academicCode;
	}
	
	/**
	 * validates input for edit and then edits
	 */
	public void confirmEdit()
	{
		String courseCode = "", tutorName = "", academicName = "", moduleName = "", tutorID = "", academicID = "";
		
		boolean val = true;
		//Making sure a course is chosen
		if(cmbEditCourses.getSelectedIndex() >= 1)
		{
			for(int i =0; i < courses.size(); i++)
				if(courses.get(i).getCourseName().equals(cmbEditCourses.getSelectedItem().toString()))
					courseCode = courses.get(i).getCourseCode();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a course for the module to be added to.");
			val = false;
		}
		
		//Making sure a tutor is chosen as the leader
		if(cmbTutors.getSelectedIndex() >= 1)
		{
			tutorName = cmbTutors.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a tutor as the leader of the module.");
			val = false;
		}
		
		//Making sure an academic is chosen as the moderator
		if(cmbAcademics.getSelectedIndex() >= 1)
		{
			academicName = cmbAcademics.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose an academic as the module moderator.");
			val = false;
		}
		
		//Making sure the name is more than 3 letters/exists
		if(tfName.getText().length() >= 3 && val == true)
		{
			moduleName = tfName.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Module Names must be more than 3 characters");
			val = false;
		}
		
		if(val)
		{
			
			
			
			
			int index = 0;
			for(int i =0;i<modules.size();i++)
				if(modules.get(i).getModuleCode().equals(lblModuleCodeAutoFill.getText().toString()))
					index = i;
			
			int dialogButton2 = JOptionPane.YES_NO_OPTION;
            int dialogResult2 = JOptionPane.showConfirmDialog (null, "Are you sure you would like to edit this module?","Confirm addition.", dialogButton2);
            if(dialogResult2 == JOptionPane.YES_OPTION)
            {
            	//modules.set(index, newM);
            	tutorID = findTutorID(tutorName);
    			academicID = findAcademicID(academicName);
    			
            	modules.get(index).setCourseCode(courseCode);
            	modules.get(index).setModuleName(tfName.getText());
            	modules.get(index).setModuleModerator(academicID);
    			modules.get(index).setModuleLeader(tutorID);
            	JOptionPane.showMessageDialog(container, "Module Edited!");
            	JOptionPane.showMessageDialog(container, modules.get(index).getCourseCode());
            	
            	dispose();
            }         
		}
	}

	/**
	 * confirms delete then deletes
	 */
	public void delete()
	{
		if(checkModulePicked()) {
			
            	int dialogButton = JOptionPane.YES_NO_OPTION;
    	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to delete the\n module: " + cmbModules.getSelectedItem().toString() +"\nWarning this will delete all classes and assignments?","Confirm Delete.", dialogButton);
    	        if(dialogResult == JOptionPane.YES_OPTION)
    	        {
    	        	int index = 0;
    	            for(int i = 0; i < modules.size(); i++)
    	            {
    	            	if(modules.get(i).getModuleCode().equals(getModuleCode(cmbModules.getSelectedItem().toString())))
    	            	{
    	            		index = i;
    	            	}
    	            }	            
    	            
    	            for(int i = 0 ; i < assignments.size(); i++)
    	            	if(assignments.get(i).gemoduleCode().equals(getModuleCode(cmbModules.getSelectedItem().toString())))
    	            		deleteResults(assignments.get(i).getAssignmentCode());
    	            
    	            deleteClasses();
    	            deleteAssignments();
    	            modules.remove(index);
    	            JOptionPane.showMessageDialog(container, "Module deleted successfully.");
    	            dispose();
    	        }
            }
            
            
		
	}

	/**
	 * delete results for the assignments in the module
	 * @param assignmentCode
	 */
	public void deleteResults(String assignmentCode)
	{
		int i = 0;
		while (results.size() > i) {
			if(results.get(i).getAssignmentCode().equals(assignmentCode))
		    	results.remove(i);
		    else
		    	i++;
		}
	}
	
	/**
	 * deletes the classes for the module
	 */
	public void deleteClasses()
	{
		int i = 0;
		while (classes.size() > i) {
			if(classes.get(i).getModuleCode().equals(getModuleCode(cmbModules.getSelectedItem().toString())))
					classes.remove(i);
		    else
		    	i++;
		}
	}
	
	/**
	 * deletes assignments for the module
	 */
	public void deleteAssignments()
	{
		int i = 0;
		while (assignments.size() > i) {
			if(assignments.get(i).gemoduleCode().equals(getModuleCode(cmbModules.getSelectedItem().toString())))
				assignments.remove(i);
		    else
		    	i++;
		}
	}
	
}
