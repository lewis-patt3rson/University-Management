package cw1;

import java.io.Serializable;

public class Results implements Serializable{

	String assignmentCode;
	String studentCode;
	double result;
	String feedBack;
	
	/**
	 * blank constructor
	 */
	public Results()
	{
		assignmentCode = "";
		studentCode = "";
		result = 0.0;
		feedBack = "";
	}
	
	/**
	 * constructor that takes in all info
	 * @param assignmentCode
	 * @param studentCode
	 * @param result
	 * @param feedbackInput
	 */
	public Results(String assignmentCode, String studentCode, double result, String feedbackInput)
	{
		this.assignmentCode = assignmentCode;
		this.studentCode = studentCode;
		this.result = result;
		this.feedBack = feedbackInput;
	}

	/**
	 * returns assignmentCode
	 * @return
	 */
	public String getAssignmentCode() {
		return assignmentCode;
	}

	/**
	 * sets assignment code from string input
	 * @param assignmentCode
	 */
	public void setAssignmentCode(String assignmentCode) {
		this.assignmentCode = assignmentCode;
	}

	/**
	 * returns student code
	 * @return
	 */
	public String getStudentCode() {
		return studentCode;
	}

	/**
	 * sets student code from string input
	 * @param studentCode
	 */
	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}

	/**
	 * returns result
	 * @return
	 */
	public double getResult() {
		return result;
	}

	/**
	 * sets result from double input
	 * @param result
	 */
	public void setResult(double result) {
		this.result = result;
	}
	
	/**
	 * sets feedback from string input
	 * @param feedBack
	 */
	public void setFeedback(String feedBack)
	{
		this.feedBack = feedBack;
	}
	
	/**
	 * returns feedback
	 * @return
	 */
	public String getFeedBack()
	{
		return this.feedBack;
	}
}
