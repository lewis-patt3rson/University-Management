package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.Map.Entry;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

import cw1.Class;
import cw1.Module;

public class StaffDetailsForm extends JDialog implements ActionListener{
	
	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private Container container;
	private JPanel jpSearch, jpDetails;
	private JTextField tfSearch;
	private JLabel lblHeader, lblMessage, lblStaffTitle, lblTitle, lblStaffForname, lblForname, lblStaffSurname, lblSurname, lblStaffPosition, lblPosition, lblStaffOffice, lblOffice, lblStaffExpertise, lblExpertise;
	private JLabel lblStaffEmployment, lblEmployment, lblStaffCode, lblCode, lblModules;
	private JComboBox cmbStaff;
	private JButton btnReset, btnViewDetails, btnModules, btnExit;
	
	/**
	 * loads in the relevant lists and maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param tutorMap
	 * @param academicMap
	 * @param moduleList
	 * @param classList
	 */
	public StaffDetailsForm(HashMap tutorMap, HashMap academicMap, LinkedList moduleList, LinkedList classList)
	{
		tutors = tutorMap;
		academics = academicMap;
		modules = moduleList;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpDetails = new JPanel();
		jpDetails.setLayout(new GridBagLayout());
		jpDetails.setBackground(new Color(250,128,114));

		
		
		lblHeader = new JLabel("Staff Details", JLabel.CENTER);
		lblMessage = new JLabel("Search by staff code or staff surname: ");
		lblStaffCode = new JLabel("Staff Code:", JLabel.RIGHT);
		lblCode = new JLabel("XXXXXXX");
		lblStaffTitle = new JLabel("Title:", JLabel.RIGHT);
		lblTitle = new JLabel("XXX");
		lblStaffForname = new JLabel("Forname:", JLabel.RIGHT);
		lblForname = new JLabel("XXXXXXX");
		lblStaffSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblSurname = new JLabel("XXXXXXX");
		lblStaffPosition = new JLabel("Position:", JLabel.RIGHT);
		lblPosition = new JLabel("XXXXXXX");
		lblStaffOffice = new JLabel("Office location:", JLabel.RIGHT);
		lblOffice = new JLabel("XXXXXXX");
		lblStaffExpertise = new JLabel("Expertise:", JLabel.RIGHT);
		lblExpertise = new JLabel("XXXXXXX");
		lblStaffEmployment = new JLabel("Employment Type", JLabel.RIGHT);
		lblEmployment = new JLabel("XXXXXXX");
		lblModules = new JLabel("View modules:", JLabel.RIGHT);
		
		tfSearch = new JTextField();
		
		cmbStaff = new JComboBox();
		
		btnReset = new JButton("Reset");
		btnViewDetails = new JButton("View Details");
		btnModules = new JButton("Modules lead/moderated");
		btnExit = new JButton("Exit");
		
		KeyListener keyListener = new KeyListener() {
		     public void keyPressed(KeyEvent keyEvent) {
		     }
		     public void keyReleased(KeyEvent keyEvent) {
		      loadStaff();
		     }
		     public void keyTyped(KeyEvent keyEvent) {    
		      }};
		tfSearch.addKeyListener(keyListener);

		addComp(container, jpSearch,0,0,1,1,0,0);
		addComp(container, jpDetails,0,1,1,1,0,0);
		
		addComp(jpSearch, lblHeader,0,0,3,1,0,0);
		addComp(jpSearch, lblMessage,0,1,1,1,0,0);
		addComp(jpSearch, tfSearch,0,2,1,1,0,0);
		addComp(jpSearch, cmbStaff,1,2,1,1,0,0);
		addComp(jpSearch, btnReset,2,1,1,1,0,0);
		addComp(jpSearch, btnViewDetails,2,2,1,1,0,0);
		
		addComp(jpDetails, lblStaffCode,0,0,1,1,0,0);
		addComp(jpDetails, lblCode,1,0,1,1,0,0);
		addComp(jpDetails, lblStaffTitle,0,1,1,1,0,0);
		addComp(jpDetails, lblTitle,1,1,1,1,0,0);
		addComp(jpDetails, lblStaffForname,0,2,1,1,0,0);
		addComp(jpDetails, lblForname,1,2,1,1,0,0);
		addComp(jpDetails, lblStaffSurname,0,3,1,1,0,0);
		addComp(jpDetails, lblSurname,1,3,1,1,0,0);
		addComp(jpDetails, lblStaffPosition,0,4,1,1,0,0);
		addComp(jpDetails, lblPosition,1,4,1,1,0,0);
		addComp(jpDetails, lblStaffOffice,0,5,1,1,0,0);
		addComp(jpDetails, lblOffice,1,5,1,1,0,0);
		addComp(jpDetails, lblStaffExpertise,0,6,1,1,0,0);
		addComp(jpDetails, lblExpertise,1,6,1,1,0,0);
		addComp(jpDetails, lblStaffEmployment,0,7,1,1,0,0);
		addComp(jpDetails, lblEmployment,1,7,1,1,0,0);
		addComp(jpDetails, lblModules,0,8,1,1,0,0);
		addComp(jpDetails, btnModules,1,8,1,1,0,0);
		addComp(jpDetails, btnExit,0,9,2,1,0,0);
		
		
		
		tfSearch.addActionListener(this);
		btnReset.addActionListener(this);
		btnViewDetails.addActionListener(this);
		btnModules.addActionListener(this);
		btnExit.addActionListener(this);
		loadStaff();
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
        }
	
	/**
	 * loads events from button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnReset)
			resetForm();
		else if(e.getSource() == btnViewDetails)
			loadDetails();
		else if(e.getSource() == btnExit)
			exit();
		else if(e.getSource() == btnModules)
			loadModules();
	}


	/**
	 * loads staff from what is typed in the search bar (both staff surname and module code are searched at the same time and all staff regardless of type are added)
	 */
	public void loadStaff()
	{
		cmbStaff.removeAllItems();
		cmbStaff.addItem("...");
		Iterator it = tutors.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			try {
				if(tfSearch.getText().toString().length() > 0)
				{
					if(tutors.get(me.getKey()).getTutorCode().substring(0, tfSearch.getText().length()).equals(tfSearch.getText().toUpperCase()) || tutors.get(me.getKey()).getSurname().toUpperCase().substring(0,tfSearch.getText().length()).equals(tfSearch.getText().toUpperCase()))
					{
						cmbStaff.addItem(tutors.get(me.getKey()).getTutorCode().toString() + ": " + tutors.get(me.getKey()).getForname().toString() + ", " +tutors.get(me.getKey()).getSurname().toString());
					}
				}
				else
				{
					cmbStaff.addItem(tutors.get(me.getKey()).getTutorCode().toString() + ": " + tutors.get(me.getKey()).getForname().toString() + ", " +tutors.get(me.getKey()).getSurname().toString());
				}
			}
			catch(StringIndexOutOfBoundsException e){}	
			
			
		}
		
		Iterator jt = academics.entrySet().iterator();
		while(jt.hasNext())
		{		
			Map.Entry me = (Entry) jt.next();
			try {
			if(tfSearch.getText().toString().length() > 0)
			{
				if(academics.get(me.getKey()).getAcademicCode().substring(0, tfSearch.getText().length()).equals(tfSearch.getText().toUpperCase()) || academics.get(me.getKey()).getSurname().toUpperCase().substring(0,tfSearch.getText().length()).equals(tfSearch.getText().toUpperCase()))
				{
					cmbStaff.addItem(academics.get(me.getKey()).getAcademicCode().toString() + ": " + academics.get(me.getKey()).getForname().toString() + ", " +academics.get(me.getKey()).getSurname().toString());
				}
			}
			else
			{
				cmbStaff.addItem(academics.get(me.getKey()).getAcademicCode().toString() + ": " + academics.get(me.getKey()).getForname().toString() + ", " +academics.get(me.getKey()).getSurname().toString());
			}
			}
			catch(StringIndexOutOfBoundsException e){}	
			
		}
		
		
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		tfSearch.setText("");
		lblCode.setText("XXXXXXX");
		lblTitle.setText("XXX");
		lblForname.setText("XXXXXXX");
		lblSurname.setText("XXXXXXX");
		lblOffice.setText("XXXXXXX");
		lblPosition.setText("XXXXXXX");
		lblExpertise.setText("XXXXXXX");
		lblEmployment.setText("XXXXXXX");
		btnModules.setText("Modules lead/moderated");
		loadStaff();
	}

	/**
	 * loads details of selected staff member onto form
	 */
	public void loadDetails()
	{
		if(cmbStaff.getSelectedIndex() > 0)
		{
			if(cmbStaff.getSelectedItem().toString().substring(0,3).equals("TUT")) {
				String id = cmbStaff.getSelectedItem().toString().substring(0,7);
				lblCode.setText(tutors.get(id).getTutorCode());
				lblTitle.setText(tutors.get(id).getTitle());
				lblForname.setText(tutors.get(id).getForname());
				lblSurname.setText(tutors.get(id).getSurname());
				lblPosition.setText(tutors.get(id).getPosition());
				lblOffice.setText(tutors.get(id).getOfficeLocation());
				lblEmployment.setText(tutors.get(id).getEmploymentStatus());
				lblExpertise.setText(tutors.get(id).getExpertise());
				btnModules.setText("Modules Lead");
			}
			else
			{
				String id = cmbStaff.getSelectedItem().toString().substring(0,7);
				lblCode.setText(academics.get(id).getAcademicCode());
				lblTitle.setText(academics.get(id).getTitle());
				lblForname.setText(academics.get(id).getForname());
				lblSurname.setText(academics.get(id).getSurname());
				lblPosition.setText(academics.get(id).getPosition());
				lblOffice.setText(academics.get(id).getOfficeLocation());
				lblEmployment.setText(academics.get(id).getEmploymentStatus());
				lblExpertise.setText(academics.get(id).getExpertise());
				btnModules.setText("Modules moderated");
			}
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a staff member to view details.");
	}

	/**
	 * confirms exit and then exits
	 */
	public void exit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you would like to exit? ","Confirm exit.", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	dispose();
        }
	}

	/**
	 * loads the modules a staff member leads/moderates
	 */
	public void loadModules()
	{
		if(lblCode.getText().equals("XXXXXXX"))
		{
			JOptionPane.showMessageDialog(container, "You must choose a staff member to view their modules lead/moderated!");
		}
		else
		{
			StaffModuleForm smF = new StaffModuleForm(lblCode.getText(), tutors, academics, modules, classes);
			smF.setSize(600,500);
			smF.setModal(true);
			smF.setVisible(true);
		}
			
	}
}
