package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.Map.Entry;

import javax.swing.*;

public class AddStaffForm extends JDialog implements ActionListener{

	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	
	Container container;
	private JLabel lblForname, lblSurname, lblPosition, lblOfficeLocation, lblExpertise, lblEmploymentStatus, lblType, lblHeader, lblTitle;
	private JComboBox cmbEmploymentType, cmbStaffType, cmbTitle;
	private JTextField tfForname, tfSurname, tfPosition, tfOfficeLocation, tfExpertise;
	private JButton btnExit, btnReset, btnAdd;
	
	/**
	 * loads in the relevant maps for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param tutorMap
	 * @param academicMap
	 */
	public AddStaffForm(HashMap tutorMap, HashMap academicMap)
	{
		tutors = tutorMap;
		academics = academicMap;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblForname = new JLabel("Forname:", JLabel.RIGHT);
		lblSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblPosition = new JLabel("Position:", JLabel.RIGHT);
		lblOfficeLocation = new JLabel("Office Location:", JLabel.RIGHT);
		lblExpertise = new JLabel("Expertise:", JLabel.RIGHT);
		lblEmploymentStatus = new JLabel("Employment Status:", JLabel.RIGHT);
		lblType = new JLabel("Type:", JLabel.RIGHT);
		lblHeader = new JLabel("Add Staff Member:", JLabel.CENTER);
		lblTitle = new JLabel("Title:", JLabel.RIGHT);
		
		String[] employmentTypes = new String[]{
			"...","Full-Time","Part-Time"
		};
		String[] staffTypes = new String[]{
				"...","Tutor","Academic"
			};
		String[] titles = new String[]{
				"...", "Dr", "Mr", "Mrs", "Miss", "Ms"
		};
				
			
		cmbEmploymentType = new JComboBox(employmentTypes);
		cmbStaffType = new JComboBox(staffTypes);
		cmbTitle = new JComboBox(titles);
		
		tfForname = new JTextField();
		tfSurname = new JTextField();
		tfPosition = new JTextField();
		tfOfficeLocation = new JTextField();
		tfExpertise = new JTextField();
		
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnAdd = new JButton("Add Staff");
		
		addComp(lblHeader,0,0,3,1,1,1);
		addComp(lblForname,0,2,1,1,1,1);
		addComp(lblTitle,0,1,1,1,1,1);
		addComp(cmbTitle,1,1,1,1,1,1);
		addComp(tfForname,1,2,2,1,1,1);
		addComp(lblSurname,0,3,1,1,1,1);
		addComp(tfSurname,1,3,2,1,1,1);
		addComp(lblPosition,0,4,1,1,1,1);
		addComp(tfPosition,1,4,2,1,1,1);
		addComp(lblOfficeLocation,0,5,1,1,1,1);
		addComp(tfOfficeLocation,1,5,2,1,1,1);
		addComp(lblExpertise,0,6,1,1,1,1);
		addComp(tfExpertise,1,6,2,1,1,1);
		addComp(lblEmploymentStatus,0,7,1,1,1,1);
		addComp(cmbEmploymentType,1,7,2,1,1,1);
		addComp(lblType,0,8,1,1,1,1);
		addComp(cmbStaffType,1,8,2,1,1,1);
		addComp(btnExit,0,9,1,1,1,1);
		addComp(btnReset,1,9,1,1,1,1);
		addComp(btnAdd,2,9,1,1,1,1);
		
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnAdd.addActionListener(this);
		
		
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * loads events from each button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm Exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm Reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnAdd)
		{
			addStaffMember();
		}
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		tfForname.setText("");
		tfSurname.setText("");
		tfPosition.setText("");
		tfOfficeLocation.setText("");
		tfExpertise.setText("");
		cmbEmploymentType.setSelectedIndex(0); 
		cmbStaffType.setSelectedIndex(0);
		cmbTitle.setSelectedIndex(0);
	}
	
	/**
	 * makes sure the inputs for the staff are validated, then if so adds the relevant information 
	 * into either tutor or academic maps, dependant on which was chosen.
	 */
	public void addStaffMember()
	{
		Boolean val = true;
		
		String forname = "", surname = "", position = "", officeLocation = "", expertise = "", employmentType = "", staffType = "", title = "";
		
		//Forname
		if(tfForname.getText().length() >= 3)
		{
			forname = tfForname.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Fornames must be more than 3 letters long.");
			val = false;
		}
		
		//Surname
		if(tfSurname.getText().length() >= 3)
		{
			surname = tfSurname.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Surnames must be more than 3 letters long.");
			val = false;
		}
		
		//Position
		if(tfPosition.getText().length() >= 3)
		{
			position = tfPosition.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Position must be more than 3 letters long.");
			val = false;
		}
		
		//Office Location
		if(tfOfficeLocation.getText().length() >= 3)
		{
			officeLocation = tfOfficeLocation.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Office location must be more than 3 letters long.");
			val = false;
		}
		
		//Expertise
		if(tfExpertise.getText().length() >= 3)
		{
			expertise = tfExpertise.getText();
		}
		else {
			JOptionPane.showMessageDialog(container, "Expertise must be more than 3 letters long.");
			val = false;
		}
		
		//Employment Type
		if(cmbEmploymentType.getSelectedIndex() >= 1)
		{
			employmentType = cmbEmploymentType.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose an employment type.");
			val = false;
		}
		
		//Staff Type
		if(cmbStaffType.getSelectedIndex() >= 1)
		{
			staffType = cmbStaffType.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose an staff type.");
			val = false;
		}
		
		//Title
		if(cmbTitle.getSelectedIndex() >= 1)
		{
			title = cmbTitle.getSelectedItem().toString();
		}
		else {
			JOptionPane.showMessageDialog(container, "You must choose a title.");
			val = false;
		}
		

		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to add: " + tfForname.getText().toString() +"?","Confirm Exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	if(staffType.equals("Tutor")) 
        		{
        			Tutor newT = new Tutor(findLastTutor(), title, forname, surname, position, officeLocation, expertise, employmentType);
        			JOptionPane.showMessageDialog(container, "Staff member: " + newT.getTitle() + ". " + newT.getForname() + ", " + newT.getSurname() + " has been added.");
        			tutors.put(newT.getTutorCode(), newT);
        			
        		}
            	else if(staffType.equals("Academic"))
            	{
            		Academic newA = new Academic(findLastAcademic(), title, forname, surname, position, officeLocation, expertise, employmentType);
            		JOptionPane.showMessageDialog(container, "Staff member: " + newA.getTitle() + ". " + newA.getForname() + ", " + newA.getSurname() + " has been added.");
        			academics.put(newA.getAcademicCode(), newA);
            	}
            	
            	int dialogButton2 = JOptionPane.YES_NO_OPTION;
                int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to add another staff member?","Add another?", dialogButton);
                if(dialogResult2 == JOptionPane.YES_OPTION)
                {
                	resetForm();
                }
                else 
                {
                	dispose();
                }
            }
		}
		
	}

	/**
	 * Finds the last tutor id, if no tutors exist then this is TUT1001
	 * @return
	 */
 	public String findLastTutor()
	{
		String tutorID = "";
		Iterator it = tutors.entrySet().iterator();
		int index = 1001;
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(Integer.parseInt(tutors.get(me.getKey()).getTutorCode().substring(3)) > index)
				index = Integer.parseInt(tutors.get(me.getKey()).getTutorCode().substring(3));
		}
		tutorID = "TUT" + (index + 1);
		return tutorID;
	}
	
 	/**
 	 * Finds the last academic id, if no tutors exist then this is ACA1001
 	 * @return
 	 */
	public String findLastAcademic()
	{
		String academicID = "";
		Iterator it = academics.entrySet().iterator();
		int index = 1001;
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(Integer.parseInt(academics.get(me.getKey()).getAcademicCode().substring(3)) > index)
				index = Integer.parseInt(academics.get(me.getKey()).getAcademicCode().substring(3));
		}
		academicID = "ACA" + (index + 1);
		return academicID;
	}
}
