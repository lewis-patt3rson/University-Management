package cw1;

import java.io.Serializable;

public class Student implements Serializable{
    private String studentCode;
    private String forName;
    private String surName;
    private String disability;
    private String preferredName;
    private String gender;
    
	/**
	 * blank constructor
	 */
	public Student()
	{
		this.studentCode = "";
		this.forName = "";
		this.surName = "";
		this.disability = "";
		this.preferredName = "";
		this.gender = "";
		
	}
	
	/**
	 * constructor which takes in all the information
	 * @param sc
	 * @param fn
	 * @param sn
	 * @param dis
	 * @param pn
	 * @param gender
	 */
	public Student(String sc,String fn, String sn, String dis, String pn, String gender)
	{
		this.studentCode = sc;
		this.forName = fn;
		this.surName = sn;
		this.disability = dis;
		this.preferredName = pn;
		this.gender = gender;
		
	}

	/**
	 * returns student code
	 * @return
	 */
	public String getStudentCode() {
		return studentCode;
	}

	/**
	 * sets student code from string input
	 * @param studentCode
	 */
	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}

	/**
	 * returns forname
	 * @return
	 */
	public String getForName() {
		return forName;
	}

	/**
	 * sets forname from string input
	 * @param forName
	 */
	public void setForName(String forName) {
		this.forName = forName;
	}

	/**
	 * returns surname
	 * @return
	 */
	public String getSurName() {
		return surName;
	}

	/**
	 * sets surname from string input
	 * @param surName
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}

	/**
	 * returns disability
	 * @return
	 */
	public String getDisability() {
		return disability;
	}

	/**
	 * sets disability from string input
	 * @param disability
	 */
	public void setDisability(String disability) {
		this.disability = disability;
	}

	/**
	 * returns preferred name
	 * @return
	 */
	public String getPreferredName() {
		return preferredName;
	}

	/**
	 * sets preferred name from string input
	 * @param preferredName
	 */
	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	/**
	 * returns gender
	 * @return
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * sets gender from string input
	 * @param gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

}

	
	
	

