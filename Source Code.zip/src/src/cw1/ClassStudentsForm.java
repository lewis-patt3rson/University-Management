package cw1;

import java.awt.*;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class ClassStudentsForm extends JDialog {

	HashMap<String,Student> students = new HashMap<String,Student>();
	LinkedList<Class> classes = new LinkedList<Class>();
	
	private Container container;
	
	/**
	 * loads in information for the selected class and students in it
	 * loads the details of all students in the class and adds them to gui elements
	 * @param studentMap
	 * @param classList
	 * @param classCode
	 */
	public ClassStudentsForm(HashMap studentMap, LinkedList classList, String classCode)
	{
		students = studentMap;
		classes = classList;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		DefaultListModel<String> dlm = new DefaultListModel<String>();
	    JList<String> modClassList = new JList<>(dlm);
		JScrollPane listScroller = new JScrollPane(modClassList);
	
		ArrayList<String> studentArray = new ArrayList<String>();
		for(int i = 0; i < classes.size(); i++)
		{
			if(classes.get(i).getClassCode().equals(classCode))
			{
				String[] values = classes.get(i).getStudents().split(",");
				for(int j = 0; j < values.length; j++)
					studentArray.add(values[j]);
			}
		}
		
		dlm.addElement("Total students in class: " + studentArray.size());
		for(int i = 0; i < studentArray.size(); i++)
		{
			String studentDetails = "";
			studentDetails = students.get(studentArray.get(i)).getStudentCode() + ": Name: " +  students.get(studentArray.get(i)).getForName() + ", " +  students.get(studentArray.get(i)).getSurName();
			dlm.addElement(studentDetails);
		}
		
		addComp(listScroller,0,0,1,1,1,1);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
}
