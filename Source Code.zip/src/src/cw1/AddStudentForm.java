package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class AddStudentForm extends JDialog implements ActionListener{

	
	HashMap<String,Student> students = new HashMap<String,Student>();
	
	private Container container;
	private JLabel lblHeader, lblStudentCode, lblStudentForname,lblStudentSurname, lblDisabiltiy, lblPreferredName, lblGender, lblStudentCodeAutoFill;
	private JTextField tfForname, tfSurname, tfDisability, tfPreferredName;
	private JComboBox cmbGender;
	private JButton btnExit, btnReset, btnAddStudent;
	
	/**
	 * loads in the relevant map for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param studentMap
	 */
	public AddStudentForm(HashMap studentMap)
	{
		students = studentMap;
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Add Student", JLabel.CENTER);
		lblStudentCode = new JLabel("Student Code:", JLabel.RIGHT);
		lblStudentCodeAutoFill = new JLabel(getLastStudent(), JLabel.LEFT);
		lblStudentForname = new JLabel("Forname:", JLabel.RIGHT);
		lblStudentSurname = new JLabel("Surname:", JLabel.RIGHT);
		lblDisabiltiy = new JLabel("Disability:", JLabel.RIGHT);
		lblPreferredName = new JLabel("Preferred Name:", JLabel.RIGHT);
		lblGender = new JLabel("Gender:", JLabel.RIGHT);
		
		
		tfForname = new JTextField();
		tfSurname = new JTextField();
		tfDisability = new JTextField();
		tfPreferredName = new JTextField();
		
		
		String[] genders = new String[]{
			"...", "Male","Female","Other"
		};
		cmbGender = new JComboBox(genders);
		
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnAddStudent = new JButton("Add Student");
		
		addComp(lblHeader,0,0,3,1,1,1);
		addComp(lblStudentCode,0,1,1,1,1,1);
		addComp(lblStudentCodeAutoFill,1,1,1,1,1,1);
		addComp(lblStudentForname,0,2,1,1,1,1);
		addComp(tfForname,1,2,2,1,1,1);
		addComp(lblStudentSurname,0,3,1,1,1,1);
		addComp(tfSurname,1,3,2,1,1,1);
		addComp(lblDisabiltiy,0,4,1,1,1,1);
		addComp(tfDisability,1,4,2,1,1,1);
		addComp(lblPreferredName,0,5,1,1,1,1);
		addComp(tfPreferredName,1,5,2,1,1,1);
		addComp(lblGender,0,6,1,1,1,1);
		addComp(cmbGender,1,6,1,1,1,1);
		addComp(btnExit,0,7,1,1,1,1);
		addComp(btnReset,1,7,1,1,1,1);
		addComp(btnAddStudent,2,7,1,1,1,1);
		
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnAddStudent.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}

	/**
	 * loads events from each button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnAddStudent)
		{
			addStudent();
		}

	}
	
	/**
	 * gets last student id and adds one to it for the new student, if no students exist this is STU1001
	 * @return
	 */
	public String getLastStudent()
	{
		String id = "";
		
		Iterator it = students.entrySet().iterator();
		int index = 1001;
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			if(Integer.parseInt(students.get(me.getKey()).getStudentCode().substring(3)) > index)
				index = Integer.parseInt(students.get(me.getKey()).getStudentCode().substring(3));
		}
		id = "STU" + (index + 1);
		
		return id;
	}
	
	/**
	 * resets form like it was just opened
	 */
	public void resetForm()
	{
		lblStudentCodeAutoFill.setText(getLastStudent());
		tfForname.setText("");
		tfSurname.setText("");
		tfDisability.setText("");
		tfPreferredName.setText("");
		cmbGender.setSelectedIndex(0);
	}
	
	/**
	 * makes sure all input is validated and if so, adds the student to the map
	 * then offers the ability to add another or exit
	 */
	public void addStudent()
	{
		boolean val = true;
		String forName = "", surName = "", disability = "", gender = "", preferredName = "";
		
		if(tfForname.getText().toString().length() < 3)
		{
			JOptionPane.showMessageDialog(container, "Student forname must be atleast 3 letters long.");
			val = false;
		}
		else
		{
			forName = tfForname.getText();
		}
		
		if(tfSurname.getText().toString().length() <= 3)
		{
			JOptionPane.showMessageDialog(container, "Student surname must be more than 3 letters long.");
			val = false;
		}
		else
		{
			surName = tfSurname.getText();
		}
		
		if(tfDisability.getText().toString().length() <= 3)
		{
			JOptionPane.showMessageDialog(container, "Disability must be more than 3 letters long.");
			val = false;
		}
		else
		{
			disability = tfDisability.getText();
		}
		
		if(tfPreferredName.getText().toString().length() < 3)
		{
			JOptionPane.showMessageDialog(container, "Student's preferred name must be atleast 3 letters long.");
			val = false;
		}
		else
		{
			preferredName = tfPreferredName.getText();
		}
		
		if(cmbGender.getSelectedIndex() < 1)
		{
			JOptionPane.showMessageDialog(container, "You must choose a gender.");
			val = false;
		}
		else
		{
			switch(cmbGender.getSelectedIndex())
			{
			case 1: gender = "Male"; break;
			case 2: gender = "Female"; break;
			case 3: gender = "Other"; break;
			default: break;
			}
		}
		
		if(val)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to add: "+ tfForname.getText().toString() + ", "+ tfSurname.getText().toString() +" ?","Confirm New Student", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	Student newS = new Student(lblStudentCodeAutoFill.getText().toString(), forName, surName, disability, preferredName, gender);
            	students.put(lblStudentCodeAutoFill.getText().toString(), newS);
            	JOptionPane.showMessageDialog(container, "Student Successfully added!");
            	int dialogButton2 = JOptionPane.YES_NO_OPTION;
                int dialogResult2 = JOptionPane.showConfirmDialog (null, "Would you like to add another student?","Add another?", dialogButton);
                if(dialogResult2 == JOptionPane.YES_OPTION)
                {
                	resetForm();
                }
                else 
                {
                	dispose();
                }                
            }
		}
		
		
	}
	
	
	
	
	
	
	

}
