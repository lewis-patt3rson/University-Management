package cw1;

import java.io.Serializable;

public class Module implements Serializable{

	private String moduleCode; //Used to identify modules uniquely
	private String moduleName; //Name of the module
	private String courseCode; //The course the module is part of
	private String moduleLeader; //The leader of the module (Tutor Code)
	private String moduleModerator; //The moderator of the module (academic)
	
	/**
	 * constructor that takes in all info
	 * @param moduleCode
	 * @param moduleName
	 * @param courseCode
	 * @param moduleLeader
	 * @param moduleModerator
	 */
	public Module(String moduleCode, String moduleName, String courseCode, String moduleLeader,String moduleModerator) 
	{
		this.moduleCode = moduleCode;
		this.moduleName = moduleName;
		this.courseCode = courseCode;
		this.moduleLeader = moduleLeader;
		this.moduleModerator = moduleModerator;
	}
	
	/**
	 * blank constructor
	 */
	public Module()
	{
		this.moduleCode = "";
		this.moduleName = "";
		this.courseCode = "";
		this.moduleLeader = "";
		this.moduleModerator = "";
	}

	/**
	 * returns module code
	 * @return
	 */
	public String getModuleCode() {
		return moduleCode;
	}

	/**
	 * sets module code from string input
	 * @param moduleCode
	 */
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	/**
	 * returns module name
	 * @return
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * sets module name from string input
	 * @param moduleName
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * returns course code
	 * @return
	 */
	public String getCourseCode() {
		return courseCode;
	}

	/**
	 * sets course code from string input
	 * @param courseCode
	 */
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	/**
	 * returns module leader
	 * @return
	 */
	public String getModuleLeader() {
		return moduleLeader;
	}

	/**
	 * sets module leader from string input
	 * @param moduleLeader
	 */
	public void setModuleLeader(String moduleLeader) {
		this.moduleLeader = moduleLeader;
	}

	/**
	 * returns module moderator
	 * @return
	 */
	public String getModuleModerator() {
		return moduleModerator;
	}

	/**
	 * sets module moderator from string input
	 * @param moduleModerator
	 */
	public void setModuleModerator(String moduleModerator) {
		this.moduleModerator = moduleModerator;
	}
	
	
	
	
	
}
