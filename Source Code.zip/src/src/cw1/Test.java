package cw1;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import java.util.*;

import javax.swing.*;

public class Test extends JFrame implements ActionListener {
	
	private JMenuBar jmb;
	//Menu Tabs
	private JMenu jmCourses, jmModules, jmStaff, jmStudents,jmAssignments, jmSystem, jmClasses;
	
	//Menu Items
	private JMenuItem jmiAddCourses, jmiEditCourses, jmiCourseDetails, jmiAddModules, jmiEditModules, jmiModuleDetails, jmiAddRemoveStudent;
	private JMenuItem jmiAddClasses, jmiEditClasses, jmiClassDetails, jmiAddStaffMember, jmiEditStaffMember, jmiStaffDetails;
	private JMenuItem jmiAddStudents, jmiEditStudents, jmiStudentDetails, jmiExit;
	private JMenuItem jmiAddAssignments, jmiEditAssignments, jmiMarkAssignment;
	private Container container;
	
	
	//Maps
	HashMap<String,Student> students = new HashMap<String,Student>();
	HashMap<String, Tutor> tutors = new HashMap<String, Tutor>();
	HashMap<String, Academic> academics = new HashMap<String, Academic>();
	
	//Lists
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();
	LinkedList<Assignment> assignments = new LinkedList<Assignment>();
	LinkedList<Results> results = new LinkedList<Results>();
	
	//Files
	File studentFile = new File("Students.dat");
	File courseFile = new File("Courses.dat");
	File tutorFile = new File("Tutors.dat");
	File academicFile = new File("Academics.dat");
	File moduleFile = new File("Modules.dat");
	File classFile = new File("Classes.dat");
	File assignmentFile = new File("Assignments.dat");
	File resultsFile = new File("Results.dat");
	
	/**
	 * Public test imports files on start up and exports on exit.
	 * It adds Menu tabs, Menu Items and their action Listeners to the main screen
	 * 
	 */
	public Test()
	{
		/**
		 * Exports files on the window closing.
		 */
		  addWindowListener(new java.awt.event.WindowAdapter() 
		  {
	            public void windowClosing(java.awt.event.WindowEvent e) 
	            {
	                exportFiles();
	            }
	       }
		  );
		
		importFiles();
	
		//Background/Window//
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(255,255,255));
		
		//Menu//
		//Menu Tabs
		jmb = new JMenuBar();
		jmCourses = new JMenu("Courses");
		jmModules = new JMenu("Modules");
		jmClasses = new JMenu("Classes");
		jmStaff = new JMenu("Staff");
		jmStudents = new JMenu("Students");
		jmAssignments = new JMenu("Assignments");
		jmSystem = new JMenu("System");
		
		//Menu Tab Items
		jmiAddCourses = new JMenuItem("Add Course");
		jmiEditCourses = new JMenuItem("Edit Course");
		jmiCourseDetails = new JMenuItem("Course Details");
		jmiAddModules = new JMenuItem("Add Module");
		jmiEditModules = new JMenuItem("Edit Modules");
		jmiModuleDetails = new JMenuItem("Module Details");
		jmiAddRemoveStudent = new JMenuItem("Add/Remove Students from classes");
		jmiAddClasses = new JMenuItem("Add Class");
		jmiEditClasses = new JMenuItem("Edit Class");
		jmiClassDetails = new JMenuItem("Class Details");
		jmiAddStaffMember = new JMenuItem("Add Staff Member");
		jmiEditStaffMember = new JMenuItem("Edit Staff Member");
		jmiStaffDetails = new JMenuItem("Staff Details");
		jmiAddStudents = new JMenuItem("Add Student");
		jmiEditStudents = new JMenuItem("Edit Student");
		jmiStudentDetails = new JMenuItem("Student Details");
		jmiAddAssignments = new JMenuItem("Create Assignments");
		jmiEditAssignments = new JMenuItem("Edit Assignments");
		jmiMarkAssignment = new JMenuItem("Mark Assignments");
		jmiExit = new JMenuItem("Exit");
		
		//Adding items to tabs
		jmModules.add(jmiAddModules);
		jmModules.add(jmiEditModules);
		jmModules.add(jmiModuleDetails);
		jmCourses.add(jmiAddCourses);
		jmCourses.add(jmiEditCourses);
		jmCourses.add(jmiCourseDetails);
		jmClasses.add(jmiAddClasses);
		jmClasses.add(jmiEditClasses);
		jmClasses.add(jmiClassDetails);
		jmClasses.add(jmiAddRemoveStudent);
		jmStaff.add(jmiAddStaffMember);
		jmStaff.add(jmiEditStaffMember);
		jmStaff.add(jmiStaffDetails);
		jmStudents.add(jmiAddStudents);
		jmStudents.add(jmiEditStudents);
		jmStudents.add(jmiStudentDetails);
		jmAssignments.add(jmiAddAssignments);
		jmAssignments.add(jmiEditAssignments);
		jmAssignments.add(jmiMarkAssignment);
		jmSystem.add(jmiExit);
		
		//Adding tabs to the menu
		jmb.add(jmCourses);
		jmb.add(jmModules);
		jmb.add(jmClasses);
		jmb.add(jmStaff);
		jmb.add(jmStudents);
		jmb.add(jmAssignments);
		jmb.add(jmSystem);
		
		setJMenuBar(jmb);
		
		
		//Action Listeners//
		jmiAddModules.addActionListener(this);
		jmiEditModules.addActionListener(this);
		jmiModuleDetails.addActionListener(this);
		jmiAddCourses.addActionListener(this);
		jmiEditCourses.addActionListener(this);
		jmiCourseDetails.addActionListener(this);
		jmiAddClasses.addActionListener(this);
		jmiEditClasses.addActionListener(this);
		jmiClassDetails.addActionListener(this);
		jmiAddRemoveStudent.addActionListener(this);
		jmiAddStaffMember.addActionListener(this);
		jmiEditStaffMember.addActionListener(this);
		jmiStaffDetails.addActionListener(this);
		jmiAddStudents.addActionListener(this);
		jmiEditStudents.addActionListener(this);
		jmiStudentDetails.addActionListener(this);
		jmiAddAssignments.addActionListener(this);
		jmiEditAssignments.addActionListener(this);
		jmiMarkAssignment.addActionListener(this);
		jmiExit.addActionListener(this);

		ImageIcon im = new ImageIcon("CW1_Logo.jpeg");
		JLabel lblIm = new JLabel(im);
		container.add(lblIm);
	}			
	
	/**
	 * This is the main method which loads the main window.
	 * @param args
	 */
	public static void main(String[] args)
	{
		Test t = new Test();
		t.setSize(440,357);
		t.setVisible(true);
		
	}

	/**
	 * If a menu item is pressed, the action listener will load the appropriate form from it
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jmiExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm Exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	exportFiles();
            	System.exit(0);
            }
		}
		else if(e.getSource() == jmiAddCourses)
		{
			AddCourseForm cf = new AddCourseForm(courses);
			cf.setSize(400,400);
			cf.setModal(true);
			cf.setVisible(true);
		}
		else if(e.getSource() == jmiEditCourses)
		{
			EditCourseForm cf = new EditCourseForm(courses, modules, classes);
			cf.setSize(400,400);
			cf.setModal(true);
			cf.setVisible(true);
		}
		else if(e.getSource() == jmiCourseDetails)
		{
			CourseDetailsForm cdF = new CourseDetailsForm(courses,modules,classes);
			cdF.setSize(400,400);
			cdF.setModal(true);
			cdF.setVisible(true);
		}
		else if(e.getSource() == jmiAddModules)
		{
			ModuleForm mf = new ModuleForm(courses,modules, tutors, academics);
			mf.setSize(800,800);
			mf.setModal(true);
			mf.setVisible(true);
		}
		else if(e.getSource() == jmiEditModules)
		{
			EditModuleForm emf = new EditModuleForm(courses,modules,classes, tutors, academics, results, assignments);
			emf.setSize(800,800);
			emf.setModal(true);
			emf.setVisible(true);
		}
		else if(e.getSource() == jmiModuleDetails)
		{
			ModuleDetailsForm mdf = new ModuleDetailsForm(modules, classes, tutors, academics, courses, results, assignments, students);
			mdf.setSize(800,800);
			mdf.setModal(true);
			mdf.setVisible(true);
		}
		else if(e.getSource() == jmiAddClasses)
		{
			AddClassForm acF = new AddClassForm(classes, modules, courses);
			acF.setSize(500,300);
			acF.setModal(true);
			acF.setVisible(true);
		}
		else if(e.getSource() == jmiClassDetails)
		{
			ClassDetailsForm cdF = new ClassDetailsForm(students, classes, modules, courses);
			cdF.setSize(900,300);
			cdF.setModal(true);
			cdF.setVisible(true);
		}
		else if(e.getSource() == jmiEditClasses)
		{
			EditClassForm edF = new EditClassForm(classes, modules, courses);
			edF.setSize(600,400);
			edF.setModal(true);
			edF.setVisible(true);
		}
		else if(e.getSource() == jmiAddStaffMember)
		{
			AddStaffForm asf = new AddStaffForm(tutors, academics);
			asf.setSize(800,800);
			asf.setModal(true);
			asf.setVisible(true);
		}
		else if(e.getSource() == jmiEditStaffMember)
		{
			EditStaffForm esF = new EditStaffForm(tutors, academics, modules);
			esF.setSize(800,800);
			esF.setModal(true);
			esF.setVisible(true);
		}
		else if(e.getSource() == jmiStaffDetails)
		{
			StaffDetailsForm sdF = new StaffDetailsForm(tutors, academics, modules, classes);
			sdF.setSize(600,500);
			sdF.setModal(true);
			sdF.setVisible(true);
		}
		else if(e.getSource() == jmiAddStudents)
		{
			AddStudentForm asF = new AddStudentForm(students);
			asF.setSize(800,800);
			asF.setModal(true);
			asF.setVisible(true);
		}
		else if(e.getSource() == jmiEditStudents)
		{
			EditStudentsForm esF = new EditStudentsForm(students, results, classes);
			esF.setSize(800,800);
			esF.setModal(true);
			esF.setVisible(true);
		}
		else if(e.getSource() == jmiAddAssignments)
		{
			AssignmentForm aaf = new AssignmentForm(modules, courses, assignments);
			aaf.setSize(800,800);
			aaf.setModal(true);
			aaf.setVisible(true);
		}
		else if(e.getSource() == jmiEditAssignments)
		{
			EditAssignmentForm eaf = new EditAssignmentForm(modules, courses, assignments, results);
			eaf.setSize(800,800);
			eaf.setModal(true);
			eaf.setVisible(true);
		}
		else if(e.getSource() == jmiMarkAssignment)
		{
			MarkAssignmentForm maF = new MarkAssignmentForm(courses, modules, classes, assignments, results, students);
			maF.setSize(800,800);
			maF.setModal(true);
			maF.setVisible(true);
		}
		else if(e.getSource() == jmiStudentDetails)
		{
			StudentDetailsForm sdF = new StudentDetailsForm(students, assignments, results);
			sdF.setSize(400,400);
			sdF.setModal(true);
			sdF.setVisible(true);
		}
		else if(e.getSource() == jmiAddRemoveStudent)
		{
			AddRemoveStudentForm arsF = new AddRemoveStudentForm(courses, modules, classes, students);
			arsF.setSize(800,700);
			arsF.setModal(true);
			arsF.setVisible(true);
		}
	}
	
	/**
	 * Imports .dat files and assigns them to the the appropriate lists/maps to be used in the programme
	 */
	public void importFiles()
	{
		//Reading in student file
		try
		{
			FileInputStream fis = new FileInputStream(studentFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			students = (HashMap<String, Student>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}
		
		//Reading in tutor file
		try
		{
			FileInputStream fis = new FileInputStream(tutorFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			tutors = (HashMap<String, Tutor>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}
		
		//Reading in academics file
		try
		{
			FileInputStream fis = new FileInputStream(academicFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			academics = (HashMap<String, Academic>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}
		
		
		//Reading in courses file
		try
		{
			FileInputStream fis = new FileInputStream(courseFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			courses = (LinkedList<Course>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}	
		
		//Reading in modules file
		try
		{
			FileInputStream fis = new FileInputStream(moduleFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			modules = (LinkedList<Module>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}	
		
		//Reading in class file
		try
		{
			FileInputStream fis = new FileInputStream(classFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			classes = (LinkedList<Class>) ois.readObject();
			ois.close();
			fis.close();
		}
	    catch (ClassNotFoundException cEx)
		{
	    	JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}	
		
		//Reading in assignment file
		try
		{
			FileInputStream fis = new FileInputStream(assignmentFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			assignments = (LinkedList<Assignment>) ois.readObject();
			ois.close();
			fis.close();
		}
	    catch (ClassNotFoundException cEx)
		{
	    	JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}	
		
		//Reading in results file
				try
				{
					FileInputStream fis = new FileInputStream(resultsFile);
					ObjectInputStream ois = new ObjectInputStream(fis);
					results = (LinkedList<Results>) ois.readObject();
					ois.close();
					fis.close();
				}
			    catch (ClassNotFoundException cEx)
				{
			    	JOptionPane.showMessageDialog(null, "The contents could not be read");
				}
				catch (FileNotFoundException fEx)
				{
					JOptionPane.showMessageDialog(null, "No file found");
				}
				catch (IOException ioEx)
				{
					JOptionPane.showMessageDialog(null, "Could not read from file");
				}	
	}
	
	/**
	 * Exports list/map data on exit in the form of .dat files which are serialised 
	 */
	public void exportFiles()
	{
		//Exporting Student File
		try 
		{
			FileOutputStream fos = new FileOutputStream(studentFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(students);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No student.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write students to file");
		}
		
		//Exporting Tutor File
		try 
		{
			FileOutputStream fos = new FileOutputStream(tutorFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(tutors);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No tutor.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write tutors to file");
		}
		
		//Exporting academics File
		try 
		{
			FileOutputStream fos = new FileOutputStream(academicFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(academics);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No academic.dat found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write academics to file");
		}
		
		//Exporting course File
		try 
		{
			FileOutputStream fos = new FileOutputStream(courseFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(courses);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No course.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write courses to file");
		}
		
		//Exporting module File
		try 
		{
			FileOutputStream fos = new FileOutputStream(moduleFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(modules);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No module.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write modules to file");
		}
		
		//Exporting class File
		try 
		{
			FileOutputStream fos = new FileOutputStream(classFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(classes);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No class.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write classes to file");
		}
		
		//Exporting assignment File
		try 
		{
			FileOutputStream fos = new FileOutputStream(assignmentFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(assignments);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No assignment.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write assignments to file");
		}
		
		//Exporting result File
		try 
		{
			FileOutputStream fos = new FileOutputStream(resultsFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(results);
			oos.close();
			fos.close();
		}
		catch(FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No results.dat file found");
		}
		catch(IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write results to file");
		}
	}

	
}
