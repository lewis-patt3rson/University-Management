package cw1;

import java.io.Serializable;

public class Tutor extends Staff implements Serializable{

	private String tutorCode;
	
	/**
	 * blank constructor
	 */
	public Tutor()
	{
		
	}
	
	/**
	 * constructor that loads all info
	 * @param tutorCode
	 * @param tutorTitle
	 * @param tutorForname
	 * @param tutorSurname
	 * @param position
	 * @param officeLocation
	 * @param expertise
	 * @param employmentStatus
	 */
	public Tutor(String tutorCode, String tutorTitle, String tutorForname, String tutorSurname, String position, String officeLocation, String expertise, String employmentStatus)
	{
		super(tutorTitle, tutorForname, tutorSurname, position, officeLocation, expertise, employmentStatus);
		this.tutorCode = tutorCode;
	}
	
	/**
	 * sets tutor code from string input
	 * @param tCode
	 */
	public void setTutorCode(String tCode)
	{
		this.tutorCode = tCode;
	}
	
	/**
	 * returns tutor code
	 * @return
	 */
	public String getTutorCode()
	{
		return this.tutorCode;
	}
	
	
	
}
