package cw1;

import java.io.Serializable;

public class Course implements Serializable{
	
	String courseCode;
	String courseName;
	
	/**
	 * constructor which takes in all course info
	 * @param cc
	 * @param cn
	 */
	public Course(String cc, String cn)
	{
		this.courseCode = cc;
		this.courseName = cn;
	}
	
	/**
	 * blank constructor 
	 */
	public Course()
	{
		this.courseCode = "";
		this.courseName = "";
	}
	
	/**
	 * returns course code
	 * @return
	 */
	public String getCourseCode() {
		return courseCode;
	}
	
	/**
	 * sets course code from string input
	 * @param courseCode
	 */
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	
	/**
	 * returns course name
	 * @return
	 */
	public String getCourseName() {
		return courseName;
	}
	
	/**
	 * sets course name from string input
	 * @param courseName
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	
}
