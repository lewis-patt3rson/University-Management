package cw1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.*;

public class AddCourseForm extends JDialog implements ActionListener{

	LinkedList<Course> courses = new LinkedList<Course>();
	private Container container;
	private JLabel lblHeader, lblCourseCode, lblCourseCodeAutoFill, lblCourseName;
	private JTextField tfName;
	private JButton btnExit, btnReset, btnAddCourse;
	
	/**
	 * loads in the relevant list for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param courseList
	 */
	public AddCourseForm(LinkedList courseList)
	{
		courses = courseList;

		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Add Course", JLabel.CENTER);
		lblCourseCode = new JLabel("Course Code:", JLabel.RIGHT);
		lblCourseCodeAutoFill = new JLabel("COUXXXX", JLabel.LEFT);
		lblCourseName = new JLabel("Course Name:", JLabel.RIGHT);
		
		tfName = new JTextField();
		
		btnExit = new JButton("Exit");
		btnReset = new JButton("Reset");
		btnAddCourse = new JButton("Add Course");
		
		addComp(lblHeader,0,0,3,1,1,1);
		addComp(lblCourseCode,0,1,1,1,1,1);
		addComp(lblCourseCodeAutoFill,1,1,1,1,1,1);
		addComp(lblCourseName,0,2,1,1,1,1);
		addComp(tfName,1,2,2,1,1,1);
		addComp(btnExit,0,3,1,1,1,1);
		addComp(btnReset,1,3,1,1,1,1);
		addComp(btnAddCourse,2,3,1,1,1,1);
		
		int code = Integer.parseInt(courses.getLast().getCourseCode().substring(3)) + 1;
		lblCourseCodeAutoFill.setText("COU" + code);
		
		
		btnExit.addActionListener(this);
		btnReset.addActionListener(this);
		btnAddCourse.addActionListener(this);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	/**
	 * loads actions from each button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btnExit)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	dispose();
            }
		}
		else if(e.getSource() == btnReset)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm Reset", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
		}
		else if(e.getSource() == btnAddCourse)
		{
			addCourse();
		}
	}

	/**
	 * First makes sure the input data is relevant and if so adds the course to the list and offers the user to add another or exit
	 */
	public void addCourse() 
	{
		if(tfName.getText().length() < 3) 
		{
			JOptionPane.showMessageDialog(container, "Course name must be more than 3 letters long.");
		}
		else
		{
			String id = "", name = "";
			id = lblCourseCodeAutoFill.getText();
			name = tfName.getText();
			Course newC = new Course(id,name);
			courses.add(newC);
			JOptionPane.showMessageDialog(container, "Course successfully added!");
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "Would you like to add another course?","Add another?", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	resetForm();
            }
            else 
            {
            	dispose();
            }

		}
		
		
	}
	
	/**
	 * Resets the form to default as if it was just opened
	 */
	public void resetForm()
	{
		int code = Integer.parseInt(courses.getLast().getCourseCode().substring(3)) + 1;
		lblCourseCodeAutoFill.setText("COU" + code);
		tfName.setText("");
	}
	
}
