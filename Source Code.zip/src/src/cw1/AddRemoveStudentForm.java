package cw1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class AddRemoveStudentForm extends JDialog implements ActionListener{

	HashMap<String,Student> students = new HashMap<String,Student>();
	
	LinkedList<Course> courses = new LinkedList<Course>();
	LinkedList<Module> modules = new LinkedList<Module>();
	LinkedList<Class> classes = new LinkedList<Class>();

	private Container container;
	private JPanel jpSearch, jpAdd, jpRemove, jpButtons;
	private JLabel lblHeader, lblMessage, lblCourses, lblModules, lblClasses, lblStudentsInClass, lblStudentsNotInClass;
	private JComboBox cmbCourses, cmbModules, cmbClasses, cmbStudentsInClass, cmbStudentsNotInClass;
	private JButton btnReset, btnAdd, btnRemove, btnRemoveFromClass, btnAddToClass, btnExit, btnResetForm;
	
	/**
	 * loads in the relevant lists and map for the form, creates and adds gui elements to container and adds action listeners to relevant elements
	 * @param courseList
	 * @param moduleList
	 * @param classList
	 * @param studentMap
	 */
	public AddRemoveStudentForm(LinkedList courseList, LinkedList moduleList, LinkedList classList, HashMap studentMap)
	{
		courses = courseList;
		modules = moduleList;
		classes = classList;
		students = studentMap;
		
		
		container = getContentPane();
		container.setLayout(new GridBagLayout());
		container.setBackground(new Color(250,128,114));
		
		jpSearch = new JPanel();
		jpSearch.setLayout(new GridBagLayout());
		jpSearch.setBackground(new Color(250,128,114));
		
		jpAdd = new JPanel();
		jpAdd.setLayout(new GridBagLayout());
		jpAdd.setBackground(new Color(250,128,114));
		
		jpRemove = new JPanel();
		jpRemove.setLayout(new GridBagLayout());
		jpRemove.setBackground(new Color(250,128,114));
		
		jpButtons = new JPanel();
		jpButtons.setLayout(new GridBagLayout());
		jpButtons.setBackground(new Color(250,128,114));
		
		lblHeader = new JLabel("Add/Remove Students from classes");
		lblMessage = new JLabel("Choose a class:");
		lblCourses = new JLabel("Courses:");
		lblModules = new JLabel("Modules:");
		lblClasses = new JLabel("Classes:");
		lblStudentsInClass = new JLabel("Students in class:");
		lblStudentsNotInClass = new JLabel("Students not in class:");
		
		cmbCourses = new JComboBox();
		cmbModules = new JComboBox();
		cmbClasses = new JComboBox();
		cmbStudentsInClass = new JComboBox();
		cmbStudentsNotInClass = new JComboBox();
		
		btnReset = new JButton("Reset");
		btnRemove = new JButton("Remove Students");
		btnAdd = new JButton("Add Students");
		btnRemoveFromClass = new JButton("Remove Selected Student");
		btnAddToClass = new JButton("Add Selected Student");
		btnResetForm = new JButton("Choose new class");
		btnExit = new JButton("Exit");
		
		addComp(container, jpSearch,0,0,2,1,0,0);
		addComp(container, jpAdd,1,1,1,1,1,0);
		addComp(container, jpRemove,0,1,1,1,1,0);
		addComp(container, jpButtons,0,2,2,1,1,0);
		
		addComp(jpSearch, lblHeader, 0,0,4,1,0,0);
		addComp(jpSearch, lblMessage, 0,1,1,1,0,0);
		addComp(jpSearch, lblCourses, 0,2,1,1,0,0);
		addComp(jpSearch, cmbCourses, 0,3,1,1,0,0);
		addComp(jpSearch, lblModules, 1,2,1,1,0,0);
		addComp(jpSearch, cmbModules, 1,3,1,1,0,0);
		addComp(jpSearch, lblClasses, 2,2,1,1,0,0);
		addComp(jpSearch, cmbClasses, 2,3,1,1,0,0);
		addComp(jpSearch, btnReset, 4,2,1,1,0,0);
		addComp(jpSearch, btnRemove, 3,3,1,1,0,0);
		addComp(jpSearch, btnAdd, 4,3,1,1,0,0);
		
		addComp(jpRemove, lblStudentsInClass, 0,0,1,1,0,0);
		addComp(jpRemove, cmbStudentsInClass, 0,1,1,1,0,0);
		addComp(jpRemove, btnRemoveFromClass, 0,2,1,1,0,0);
		
		addComp(jpAdd, lblStudentsNotInClass, 0,0,1,1,0,0);
		addComp(jpAdd, cmbStudentsNotInClass, 0,1,1,1,0,0);
		addComp(jpAdd, btnAddToClass, 0,2,1,1,0,0);
		
		addComp(jpButtons, btnExit, 0,0,1,1,0,0);
		addComp(jpButtons, btnResetForm, 1,0,1,1,0,0);
		
		for(Component c: jpAdd.getComponents())
			c.setEnabled(false);
		for(Component c: jpRemove.getComponents())
			c.setEnabled(false);
		
		btnReset.addActionListener(this);
		btnRemove.addActionListener(this);
		btnAdd.addActionListener(this);
		loadCourses();
		cmbCourses.addActionListener(this);
		cmbModules.addActionListener(this);
		btnRemoveFromClass.addActionListener(this);
		btnAddToClass.addActionListener(this);
		btnResetForm.addActionListener(this);
		btnExit.addActionListener(this);
		btnResetForm.setEnabled(false);
	}
	
	/**
	 * AddComp takes in a component and positions it on the screen using the gridbag layout with the following parameters detailing its location on the grid, the length/height of it on the grid and the individual weight it has on the grid
	 * @param con
	 * @param c
	 * @param gridx
	 * @param gridy
	 * @param width
	 * @param height
	 * @param weightX
	 * @param weightY
	 */
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        //gc.anchor = GridBagConstraints.CENTER;
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
    }
	
	/**
	 * loads events from button and changing indexes of combo boxes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == cmbCourses)
			loadModulesFromCourse();
		else if(e.getSource() == cmbModules)
			loadClassesFromModules();
		else if(e.getSource() == btnReset)
			cmbCourses.setSelectedIndex(0);
		else if(e.getSource() == btnRemove)
			loadRemove();
		else if(e.getSource() == btnRemoveFromClass)
			removeStudent();
		else if(e.getSource() == btnAdd)
			loadAdd();
		else if(e.getSource() == btnAddToClass)
			addStudent();
		else if(e.getSource() == btnResetForm)
			resetForm();
		else if(e.getSource() == btnExit)
			exit();
		
	}

	/**
	 * loads all courses into the combo box
	 */
	public void loadCourses()
	{
		cmbCourses.removeAllItems();
		cmbCourses.addItem("...");
		for(int i =0;i<courses.size();i++)
			cmbCourses.addItem(courses.get(i).getCourseCode() + ": " +  courses.get(i).getCourseName());
	}

	/**
	 * when a course is selected, modules for the course are added into the module combo box
	 */
	public void loadModulesFromCourse()
	{
		cmbModules.removeAllItems();
		cmbModules.addItem("...");
		if(cmbCourses.getSelectedIndex() > 0)
			for(int i = 0; i < modules.size(); i++)
				if(modules.get(i).getCourseCode().equals(cmbCourses.getSelectedItem().toString().substring(0,7)))
					cmbModules.addItem( modules.get(i).getModuleCode()+ ": "+ modules.get(i).getModuleName());	
	}

	/**
	 * when a module is selected, classes for the course are added into the class combo box
	 */
	public void loadClassesFromModules()
	{
		cmbClasses.removeAllItems();
		cmbClasses.addItem("...");
		if(cmbModules.getSelectedIndex() > 0)
			for(int i =0; i < classes.size(); i++)
				if(classes.get(i).getModuleCode().equals(cmbModules.getSelectedItem().toString().substring(0,7)))
					cmbClasses.addItem(classes.get(i).getClassCode()  +": " + classes.get(i).getClassName());
	}

	/**
	 * enables the remove panel on the form and disables the others
	 */
	public void loadRemove()
	{
		if(cmbClasses.getSelectedIndex() > 0)
		{
			for(Component c: jpAdd.getComponents())
				c.setEnabled(false);
			for(Component c: jpRemove.getComponents())
				c.setEnabled(true);
			for(Component c: jpSearch.getComponents())
				c.setEnabled(false);
			
			btnResetForm.setEnabled(true);
			loadStudentsFromClass();
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a class");
		
	}
	
	/**
	 * students from the selected class are loaded into the in class combo box
	 */
	public void loadStudentsFromClass()
	{
		cmbStudentsInClass.removeAllItems();
		cmbStudentsInClass.addItem("...");
		
		
		String stu = "";
		for(int i = 0; i < classes.size(); i++)
			if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
				stu = classes.get(i).getStudents();
		if(!stu.equals(""))
		{
		String[] values = stu.split(",");
		for(int i = 0; i < values.length; i++)
			cmbStudentsInClass.addItem(students.get(values[i]).getStudentCode() + ": " + students.get(values[i]).getSurName() + ", " + students.get(values[i]).getForName());
		}
	}

	/**
	 * the selected student is removed from the class
	 */
	public void removeStudent()
	{
		if(cmbStudentsInClass.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to remove student: \n "+cmbStudentsInClass.getSelectedItem().toString()+"?","Confirm remove", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	for(int i = 0; i < classes.size(); i++)
	    			if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
	    				classes.get(i).removeStudent(cmbStudentsInClass.getSelectedItem().toString().substring(0,7));
	        	
	        	JOptionPane.showMessageDialog(container, "Student removed!");
	        	loadStudentsFromClass();
	        }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a student to remove!");
	}

	/**
	 * loads the add panel of the form and disables the others
	 */
	public void loadAdd()
	{
		if(cmbClasses.getSelectedIndex() > 0)
		{
			for(Component c: jpAdd.getComponents())
				c.setEnabled(true);
			for(Component c: jpRemove.getComponents())
				c.setEnabled(false);
			for(Component c: jpSearch.getComponents())
				c.setEnabled(false);

			btnResetForm.setEnabled(true);
			loadStudentsNotInClass();
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a class");
		
	}
	
	/**
	 * students that are not in the selected class are loaded into the not in class combo box 
	 */
	public void loadStudentsNotInClass()
	{
		cmbStudentsNotInClass.removeAllItems();
		cmbStudentsNotInClass.addItem("...");
		String stu = "";
		for(int i = 0; i < classes.size(); i++)
			if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
				stu = classes.get(i).getStudents();
		String[] values = stu.split(",");
		Iterator it = students.entrySet().iterator();
		while(it.hasNext())
		{		
			boolean inClass = false;
			Map.Entry me = (Entry) it.next();
			for(int i = 0; i < values.length; i++)
				if(students.get(me.getKey()).getStudentCode().equals(values[i]))
					inClass = true;
					
			if(!inClass)
			{
				cmbStudentsNotInClass.addItem(students.get(me.getKey()).getStudentCode() + ": " + students.get(me.getKey()).getSurName()  + ", "+ students.get(me.getKey()).getForName());
			}
		}
		
	}
	
	/**
	 * selected student that is not in the class is added to the class
	 */
	public void addStudent()
	{
		if(cmbStudentsNotInClass.getSelectedIndex() > 0)
		{
			int dialogButton = JOptionPane.YES_NO_OPTION;
	        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to add student: \n "+cmbStudentsNotInClass.getSelectedItem().toString()+"?","Confirm add", dialogButton);
	        if(dialogResult == JOptionPane.YES_OPTION)
	        {
	        	for(int i = 0; i < classes.size(); i++)
	    			if(classes.get(i).getClassCode().equals(cmbClasses.getSelectedItem().toString().substring(0,7)))
	    				classes.get(i).addStudent(cmbStudentsNotInClass.getSelectedItem().toString().substring(0,7));
	        	JOptionPane.showMessageDialog(container, "Student added!");
	        	loadStudentsNotInClass();
	        }
		}
		else
			JOptionPane.showMessageDialog(container, "You must choose a student to add!");
	}
	
	/**
	 * confirms exit and then exits
	 */
	public void exit()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to exit?","Confirm exit", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	dispose();
        }
	}
	
	/**
	 * resets form as if it was just opened
	 */
	public void resetForm()
	{
		int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to reset?","Confirm reset", dialogButton);
        if(dialogResult == JOptionPane.YES_OPTION)
        {
        	for(Component c: jpAdd.getComponents())
				c.setEnabled(false);
			for(Component c: jpRemove.getComponents())
				c.setEnabled(false);
			for(Component c: jpSearch.getComponents())
				c.setEnabled(true);
			cmbStudentsInClass.removeAllItems();
			cmbStudentsNotInClass.removeAllItems();
			cmbCourses.setSelectedIndex(0);
			btnResetForm.setEnabled(false);
        }
	}
	
}
